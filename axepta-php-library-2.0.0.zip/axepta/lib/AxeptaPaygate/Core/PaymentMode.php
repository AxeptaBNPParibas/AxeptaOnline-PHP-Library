<?php

namespace AxeptaPaygate\Core;

// BBB: use PHP enums
class PaymentMode
{
    const DEMO = 'DEMO';
    const TEST = 'TEST';
    const PRODUCTION = 'PRODUCTION';
}
