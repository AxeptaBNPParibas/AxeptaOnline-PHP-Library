<?php

namespace AxeptaPaygate\Core;

use AxeptaPaygate\Exception\ConfigurationException;

class Configuration implements \ArrayAccess
{
    private $_data;
    // The Configuration can behave in two specific ways when there's an attempt
    // to access a non-existing offset:
    //   1. _dryRun == false: simply throws an exception
    //   2. _dryRun == true: returns the SENTINEL_VALUE and populates
    //                                the _missingKeys array
    private $_dryRun;
    private $_missingKeys = [];
    private const SENTINEL_VALUE = '__SENTINEL_VALUE__';

    public function __construct(array $data, bool $dryRun = false)
    {
        // We use strtoupper() to standardize the casing and provide consistent comparison.
        foreach (['amount.currency', 'iso2CountryCode', 'trigram'] as $key) {
            if (isset($data[$key])) {
                $data[$key] = strtoupper($data[$key]);
            }
        }

        // If the user does not provide payTypes when paymentRenderingMode is HPP,
        // give it a default value (all payTypes supported by the library are set)
        if (!isset($data['allowedPaymentMethods']) && isset($data['paymentRenderingMode']) && $data['paymentRenderingMode'] == PaymentRenderingMode::HPP) {
            $data['allowedPaymentMethods'] = AxeptaPaygate::getSupportedPayTypes();
            // $data['allowedPaymentMethods'] = []; // TODO:
        }

        $this->_data = $data;
        $this->_dryRun = $dryRun;
    }

    public function offsetExists($offset): bool
    {
        return array_key_exists($offset, $this->_data);
    }

    #[\ReturnTypeWillChange]
    public function offsetGet($offset)
    {
        if (!$this->offsetExists($offset)) {
            if ($this->_dryRun) {
                $this->_missingKeys[] = $offset;

                return self::SENTINEL_VALUE;
            } else {
                $message = "Configuration offset '$offset' is not set";
                throw new ConfigurationException($message);
            }
        }

        return $this->_data[$offset];
    }

    public function offsetSet($offset, $value): void
    {
        $this->_data[$offset] = $value;
    }

    public function offsetUnset($offset): void
    {
        unset($this->_data[$offset]);
    }

    public function get(string $offset, $default = null)
    {
        if (!$this->offsetExists($offset)) {
            // TODO: handle missingOptionalKeys?
            // $this->_missingOptionalKeys[] = $offset;
            return $default;
        }

        return $this->_data[$offset];
    }

    public function has(string $offset): bool
    {
        return array_key_exists($offset, $this->_data);
    }

    public function isDryRun(): bool
    {
        return $this->_dryRun;
    }

    public function getMissingKeys(): array
    {
        // NB: array_unique() is used to remove duplicates
        return array_unique($this->_missingKeys);
    }
}
