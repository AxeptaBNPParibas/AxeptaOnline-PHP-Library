<?php

namespace AxeptaPaygate\Core;

// BBB: use PHP enums
class CaptureMode
{
    const AUTO = 'AUTO';
    const MANUAL = 'MANUAL';
}
