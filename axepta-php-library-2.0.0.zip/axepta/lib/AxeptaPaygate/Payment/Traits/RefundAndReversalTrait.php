<?php

namespace AxeptaPaygate\Payment\Traits;

use AxeptaPaygate\Api\OAuth2Api;
use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\OperationType;
use AxeptaPaygate\ParamsValidator;

trait RefundAndReversalTrait
{
    public static function buildOrNull()
    {
        $cfg = AxeptaPaygate::getConfiguration();

        $apiUrl = OAuth2Api::getBaseurl() . '/payments';

        switch ($cfg['operationType']) {
            case OperationType::PAYMENT_REFUND:
                $urlSuffix = '/' . $cfg['paymentId'] . '/refunds';
                // no break
            case OperationType::PAYMENT_REVERSAL:
                if (!isset($urlSuffix)) {
                    $urlSuffix = '/' . $cfg['paymentId'] . '/reversals';
                }
                $apiUrl .= $urlSuffix;

                self::_assertPaymentRenderingModeNotSet();

                $paramKeys = [
                    '$.transId',
                    '$.amount.currency',
                    '$.amount.value',
                    '$.refNr',
                ];

                $params = ParamsValidator::validateParams($paramKeys);

                return [
                    'request' => OAuth2Api::buildJsonRequest($cfg['api_access_token'], $apiUrl, 'POST', $params),
                    'params' => $params,
                ];

            default:
                return null;
        }
    }
}
