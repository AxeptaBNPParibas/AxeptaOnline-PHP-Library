<?php

namespace AxeptaPaygate\Exception;

class ParamsValidationException extends AxeptaPaygateException
{
}
