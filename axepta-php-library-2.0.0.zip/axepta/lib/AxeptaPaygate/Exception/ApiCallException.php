<?php

namespace AxeptaPaygate\Exception;

class ApiCallException extends AxeptaPaygateException
{
}
