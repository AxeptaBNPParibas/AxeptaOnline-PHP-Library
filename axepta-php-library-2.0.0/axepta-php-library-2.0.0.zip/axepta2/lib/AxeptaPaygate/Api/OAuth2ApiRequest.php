<?php

namespace AxeptaPaygate\Api;

use AxeptaPaygate\Exception\ApiCallException;

class OAuth2ApiRequest
{
    private $url;
    private $method;
    private $headers;
    private $data;

    public function __construct(string $url, string $method = 'GET', array $headers = [], string $data = '')
    {
        $this->url = $url;
        $this->method = $method;
        $this->headers = $headers;
        $this->data = $data;
    }

    public function call()
    {
        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => $this->url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $this->method,
            CURLOPT_HTTPHEADER => $this->headers,
        ]);

        if (!empty($this->data)) {
            curl_setopt($curl, CURLOPT_POSTFIELDS, $this->data);
        }

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            throw new ApiCallException($err);
        }

        return $response;
    }

    public function getUrl(): string
    {
        return $this->url;
    }

    public function getMethod(): string
    {
        return $this->method;
    }

    public function getHeaders(): array
    {
        return $this->headers;
    }

    public function getData(): string
    {
        return $this->data;
    }
}
