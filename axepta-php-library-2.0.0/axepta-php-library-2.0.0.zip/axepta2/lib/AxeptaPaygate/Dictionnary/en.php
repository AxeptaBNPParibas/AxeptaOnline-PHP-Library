<?php

return [
    'states' => [
        '0' => [
            'message' => 'OK',
            'description' => 'Successful transaction. Action code can contain information.',
        ],
        '2' => [
            'message' => 'Error',
            'description' => 'Transaction failed',
        ],
        '4' => [
            'message' => 'Fatal',
            'description' => 'Transaction failed due to an error which might affect following transactions too.',
        ],
        '6' => [
            'message' => 'Continue',
            'description' => 'The processing of the transaction is not finished yet: upon completion of the processing, the Paygate will send a notification message containing the final status.',
        ],
        '7' => [
            'message' => 'EMV',
            'description' => 'Intermediate states in the EMV 3DS sequence',
        ],
    ],
    'modules' => [
        '000' => [
            'message' => '',
            'description' => '',
        ],
        '001' => [
            'message' => 'Crypto (Decrypt, Encrypt)',
            'description' => 'A problem with encryption or decryption occurred.',
        ],
        '010' => [
            'message' => 'Parameter missing',
            'description' => 'A mandatory parameter was missing.',
        ],
        '011' => [
            'message' => 'Parameter format error',
            'description' => 'A parameter contained a value which was not formatted correctly.',
        ],
        '012' => [
            'message' => 'Parameter value invalid',
            'description' => 'A parameter contained an invalid value.',
        ],
        '013' => [
            'message' => 'Parameter too short',
            'description' => 'A parameter contained a value which was too short.',
        ],
        '014' => [
            'message' => 'Parameter too long',
            'description' => 'A parameter contained a value which is too long.',
        ],
        '015' => [
            'message' => 'Parameter Value missing',
            'description' => 'A mandatory parameter did not contain any value.',
        ],
        '016' => [
            'message' => 'Parameter value unknown',
            'description' => 'A mandatory parameter contained an unknown value.',
        ],
        '017' => [
            'message' => 'Parameter already existing',
            'description' => 'A parameter contained a value which has already been used.',
        ],
        '018' => [
            'message' => 'Parameter Value expired',
            'description' => 'A parameter contained a value which is expired.',
        ],
        '030' => [
            'message' => 'Datenbank',
            'description' => 'The database query caused a problem.',
        ],
        '040' => [
            'message' => 'Locking',
            'description' => 'The locking of the TerminalID which is mandatory for the processing of a payment was not possible.',
        ],
        '050' => [
            'message' => 'merchant',
            'description' => 'The configuration within the PayGate caused an error.',
        ],
        '060' => [
            'message' => 'Payment',
            'description' => 'Payment couldn\'t be processed.',
        ],
        '100' => [
            'message' => 'Credit card processing ',
            'description' => 'Credit card processing caused a problem.',
        ],
        '101' => [
            'message' => 'Fallback- and Paygate International processing',
            'description' => 'The processing of a fallback transaction or of domestic schemes caused a problem.',
        ],
        '103' => [
            'message' => 'VbV/MCSC-porcessing',
            'description' => 'The processing of a Verified by Visa- or MasterCard SecureCode-transaction caused a problem.',
        ],
        '105' => [
            'message' => 'Credit card processing ',
            'description' => 'Credit card processing caused a problem.',
        ],
        '106' => [
            'message' => 'Credit card processing ',
            'description' => 'Credit card processing caused a problem.',
        ],
        '107' => [
            'message' => 'Credit and debit card processing',
            'description' => 'The processing of a Dankort transaction caused a problem.',
        ],
        '108' => [
            'message' => 'Credit and debit card processing',
            'description' => 'The processing of a  transaction via CIAL/CIC caused a problem.',
        ],
        '109' => [
            'message' => 'Credit and debit card processing',
            'description' => 'The processing of a  transaction via Deutsche Card Services caused a problem.',
        ],
        '110' => [
            'message' => 'EDD general',
            'description' => 'The processing of electronic direct debits caused a problem.',
        ],
        '111' => [
            'message' => 'EDD',
            'description' => 'The processing of German electronic direct debits caused a problem.',
        ],
        '112' => [
            'message' => 'EDD',
            'description' => 'The processing of electronic direct debits caused a problem.',
        ],
        '113' => [
            'message' => 'EDD Sperrliste',
            'description' => 'Electronic direct debits against the blacklist caused a problem.',
        ],
        '114' => [
            'message' => 'Bitnet',
            'description' => 'The processing of a Bitnet transaction caused a problem.',
        ],
        '115' => [
            'message' => 'iDEAL',
            'description' => 'The processing of an iDEAL transaction caused a problem.',
        ],
        '116' => [
            'message' => 'giropay',
            'description' => 'The processing of a giropay transaction caused a problem.',
        ],
        '117' => [
            'message' => 'EDD',
            'description' => 'The processing of a direct debit payment via EVO caused a problem.',
        ],
        '118' => [
            'message' => 'Credit and debit card processing',
            'description' => 'The credit card processing via Wirecard caused a problem.',
        ],
        '119' => [
            'message' => 'Alipay',
            'description' => 'The processing of an Alipay transaction caused a problem.',
        ],
        '120' => [
            'message' => '3DSecure general',
            'description' => 'The authentication via Verified by Visa or MasterCard SecureCode caused a problem.',
        ],
        '121' => [
            'message' => 'Credit and debit card processing',
            'description' => 'The credit card processing via Elavon US caused a problem.',
        ],
        '122' => [
            'message' => 'SmartDebit',
            'description' => 'The processing of direct debits via SmartDebit caused a problem.',
        ],
        '123' => [
            'message' => 'Payolution',
            'description' => 'The processing of a Payolution transaction caused a problem.',
        ],
        '125' => [
            'message' => 'easyCredit',
            'description' => 'The processing of an easyCredit transaction caused a problem.',
        ],
        '126' => [
            'message' => 'BNPP',
            'description' => 'The processing of an BNPP transaction caused a problem.',
        ],
        '130' => [
            'message' => 'CashTicket',
            'description' => 'The processing via CashTicket caused a problem.',
        ],
        '131' => [
            'message' => 'PSC',
            'description' => 'The processing via Paysafecard caused a problem.',
        ],
        '132' => [
            'message' => 'FashionCheque',
            'description' => 'The processing of a FashionCheque transaction caused a problem.',
        ],
        '135' => [
            'message' => 'PPRO Ukash',
            'description' => 'The processing of a Ukash transaction via PPRO caused a problem.',
        ],
        '136' => [
            'message' => 'PPRO SEPA',
            'description' => 'The processing of a SEPA transaction via PPRO caused a problem.',
        ],
        '137' => [
            'message' => 'PPRO CIMB Clicks',
            'description' => 'The processing of a CIMB Clicks transaction via PPRO caused a problem.',
        ],
        '140' => [
            'message' => 'CashnGo API',
            'description' => 'The processing via Cash and Go caused a problem.',
        ],
        '141' => [
            'message' => 'AndroidPay',
            'description' => 'The processing of a Android Pay transaction caused a problem.',
        ],
        '150' => [
            'message' => 'PayPal',
            'description' => 'The processing via PayPal  caused a problem.',
        ],
        '151' => [
            'message' => 'BillSafe',
            'description' => 'The processing via BillSafe caused a problem.',
        ],
        '152' => [
            'message' => 'Billpay',
            'description' => 'The processing via Billpay caused a problem.',
        ],
        '153' => [
            'message' => 'CBA',
            'description' => 'The processing via Checkout by Amazon caused a problem.',
        ],
        '154' => [
            'message' => 'Yapital',
            'description' => 'The processing via Yapital caused a problem.',
        ],
        '155' => [
            'message' => 'Trustly',
            'description' => 'The processing via Trustly caused a problem.',
        ],
        '156' => [
            'message' => 'PayByBill',
            'description' => 'The processing via PayByBill caused a problem.',
        ],
        '157' => [
            'message' => 'Barzahlen',
            'description' => 'The processing via Barzahlen caused a problem.',
        ],
        '158' => [
            'message' => 'PagBraCC',
            'description' => 'The processing via PagBrasil caused a problem.',
        ],
        '159' => [
            'message' => 'iPay',
            'description' => 'The processing via iPay caused a problem.',
        ],
        '160' => [
            'message' => 'Paymorrow',
            'description' => 'The processing via Paymorrow caused a problem.',
        ],
        '161' => [
            'message' => 'PagBraBB',
            'description' => 'The processing via PagBrasil Boleto caused a problem.',
        ],
        '162' => [
            'message' => 'PagBraOTF',
            'description' => 'The processing via PagBrasil BankTransfer caused a problem.',
        ],
        '163' => [
            'message' => 'RiskIdent',
            'description' => 'The processing of RiskIdent caused a problem.',
        ],
        '164' => [
            'message' => 'Iovation',
            'description' => 'The processing of Iovation caused a problem.',
        ],
        '165' => [
            'message' => 'MobPayDB',
            'description' => 'The processing of a MobilePayDB caused a problem.',
        ],
        '166' => [
            'message' => 'PayUIndWC',
            'description' => 'The processing of a PayUIndWC transaction caused a problem.',
        ],
        '167' => [
            'message' => 'PayUIndCC',
            'description' => 'The processing of a PayUIndCC transaction caused a problem.',
        ],
        '168' => [
            'message' => 'Asiapay',
            'description' => 'The processing of an Asiapay transaction caused a problem.',
        ],
        '169' => [
            'message' => 'ApplePay',
            'description' => 'The processing of an ApplePay transaction caused a problem.',
        ],
        '170' => [
            'message' => 'PayUCC',
            'description' => 'The processing of a PayUCC transaction caused a problem.',
        ],
        '171' => [
            'message' => 'PayUWC',
            'description' => 'The processing of a PayUWC transaction caused a problem.',
        ],
        '172' => [
            'message' => 'PayUAfrCC',
            'description' => 'The processing of a PayU AfrCC transaction caused a problem.',
        ],
        '173' => [
            'message' => 'PayUAfrWC',
            'description' => 'The processing of a PayU AfrWC transaction caused a problem.',
        ],
        '174' => [
            'message' => 'Total',
            'description' => 'The processing of a Total transaction caused a problem.',
        ],
        '175' => [
            'message' => 'FEXCO',
            'description' => 'The processing of a FEXCO transaction caused a problem.',
        ],
        '176' => [
            'message' => 'eNett',
            'description' => 'The processing of a eNett transaction caused a problem.',
        ],
        '177' => [
            'message' => 'Swish',
            'description' => 'The processing of a Swish transaction caused a problem.',
        ],
        '178' => [
            'message' => 'IFSF',
            'description' => 'Die Verarbeitung einer IFSF Transaktion verursacht das Problem.',
        ],
        '180' => [
            'message' => 'ClicknBuy',
            'description' => 'The processing via click and buy caused a problem.',
        ],
        '181' => [
            'message' => 'Schufa',
            'description' => 'The processing via Schufa caused a problem.',
        ],
        '182' => [
            'message' => 'Boniversum',
            'description' => 'The processing of a Boniversum transaction caused a problem.',
        ],
        '183' => [
            'message' => 'PPRO Indonesia ATM',
            'description' => 'The processing of a Indonesia ATM transaction via PPRO caused a problem.',
        ],
        '184' => [
            'message' => 'PPRO MyClear FPX',
            'description' => 'The processing of a MyClear FPX transaktion via PPRO caused a problem.',
        ],
        '185' => [
            'message' => 'Paycontrol',
            'description' => 'The processing via PayControl caused a problem.',
        ],
        '186' => [
            'message' => 'PayProtect',
            'description' => 'The processing via PayProtect caused a problem.',
        ],
        '187' => [
            'message' => 'Klarna',
            'description' => 'The processing via klarna caused a problem.',
        ],
        '188' => [
            'message' => 'Deltavista',
            'description' => 'The processing via Deltavista caused a problem.',
        ],
        '189' => [
            'message' => 'RatePay',
            'description' => 'The processing via RatePay caused a problem.',
        ],
        '191' => [
            'message' => 'Mpass',
            'description' => 'The processing via mpass caused a problem.',
        ],
        '192' => [
            'message' => 'Sofort',
            'description' => 'The processing via Payment Network caused a problem.',
        ],
        '193' => [
            'message' => 'EPS',
            'description' => 'The processing via EPS caused a problem.',
        ],
        '194' => [
            'message' => 'Credit and debit card processing',
            'description' => 'The processing of a credit or debit card caused a problem.',
        ],
        '195' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '196' => [
            'message' => 'eScore',
            'description' => 'The processing via eScore caused a problem.',
        ],
        '197' => [
            'message' => 'Bürgel',
            'description' => 'The processing via Bürgel caused a problem.',
        ],
        '198' => [
            'message' => 'PayU',
            'description' => 'The processing via PayU caused a problem.',
        ],
        '199' => [
            'message' => 'InterCard',
            'description' => 'The processing via InterCard caused a problem.',
        ],
        '200' => [
            'message' => 'Credit and debit card processing',
            'description' => 'The processing of a credit or debit card caused a problem.',
        ],
        '201' => [
            'message' => 'Credit and debit card processing',
            'description' => 'The processing of a credit or debit card caused a problem.',
        ],
        '202' => [
            'message' => 'PPRO PAYSBUY Cash',
            'description' => 'The processing of a PAYSBUY Cash Transaktion via PPRO caused a problem.',
        ],
        '203' => [
            'message' => 'PPRO RHB Bank',
            'description' => 'The processing of a RHB Bank Transaktion via PPRO caused a problem.',
        ],
        '204' => [
            'message' => 'PPRO 7-Eleven',
            'description' => 'The processing of a 7-Eleven Transaktion via PPRO caused a problem.',
        ],
        '205' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '206' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '207' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '208' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '209' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '210' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '211' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '212' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '213' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '214' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '215' => [
            'message' => 'Snap',
            'description' => 'The processing of a Snap transaction caused a problem.',
        ],
        '216' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '217' => [
            'message' => 'Vme',
            'description' => 'The processing of a V.me transaction caused a problem.',
        ],
        '218' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '219' => [
            'message' => 'Credit card processing ',
            'description' => 'The processing of a credit card caused a problem.',
        ],
        '220' => [
            'message' => 'PayFac',
            'description' => 'The processing of a PayFac transaction caused a problem.',
        ],
        '221' => [
            'message' => 'PPRO BitPay',
            'description' => 'The processing of a BitPay transaction via PPRO caused a problem.',
        ],
        '222' => [
            'message' => 'PPRO Dragonpay',
            'description' => 'The processing of a Dragonpay transaction via PPRO caused a problem.',
        ],
        '223' => [
            'message' => 'PPRO Maybank2u',
            'description' => 'The processing of a Maybank2u transaction via PPRO caused a problem.',
        ],
        '225' => [
            'message' => 'PPRO AstroPay',
            'description' => 'The processing of a AstroPay transaction via PPRO caused a problem.',
        ],
        '226' => [
            'message' => 'PPRO Raberil',
            'description' => 'The processing of a Raberil transaction via PPRO caused a problem.',
        ],
        '227' => [
            'message' => 'PPRO Raberil Payout',
            'description' => 'The processing of a Raberil Payout transaction via PPRO caused a problem.',
        ],
        '228' => [
            'message' => 'PPRO Bank Transfer',
            'description' => 'The processing of a Bank Transfer transaction via PPRO caused a problem.',
        ],
        '230' => [
            'message' => 'PPRO iDEAL',
            'description' => 'The processing of a iDEAL transaction via PPRO caused a problem.',
        ],
        '231' => [
            'message' => 'PPRO Przelewy24',
            'description' => 'The processing of a Przelewy24 transaction via PPRO caused a problem.',
        ],
        '232' => [
            'message' => 'PPRO PostFinance',
            'description' => 'The processing of a PostFinance transaction via PPRO caused a problem.',
        ],
        '233' => [
            'message' => 'PPRO giropay',
            'description' => 'The processing of a giropay transaction via PPRO caused a problem.',
        ],
        '234' => [
            'message' => 'PPRO Sofortüberweisung',
            'description' => 'The processing of a Sofortüberweisung transaction via PPRO caused a problem.',
        ],
        '235' => [
            'message' => 'PPRO paysafecard',
            'description' => 'The processing of a Paysafecard transaction via PPRO caused a problem.',
        ],
        '236' => [
            'message' => 'PPRO Cash-Ticket',
            'description' => 'The processing of a Cash-Ticket transaction via PPRO caused a problem.',
        ],
        '237' => [
            'message' => 'PPRO EPS',
            'description' => 'The processing of a EPS transaction via PPRO caused a problem.',
        ],
        '238' => [
            'message' => 'Clearhaus',
            'description' => 'The processing of a Clearhouse transaction caused a problem.',
        ],
        '239' => [
            'message' => 'PPRO Credit Card',
            'description' => 'The processing of a credit card via PPRO caused a problem.',
        ],
        '240' => [
            'message' => 'PPRO Teleingreso',
            'description' => 'The processing of a Teleingreso via PPRO caused a problem.',
        ],
        '241' => [
            'message' => 'PPRO Skrill',
            'description' => 'The processing of a Skrill transaction via PPRO caused a problem.',
        ],
        '242' => [
            'message' => 'PPRO IDD',
            'description' => 'The processing of a IDD transaction via PPRO caused a problem.',
        ],
        '243' => [
            'message' => 'PPRO FasterPay',
            'description' => 'The processing of a FasterPay transaction via PPRO caused a problem.',
        ],
        '244' => [
            'message' => 'PPRO POLI',
            'description' => 'The processing of a PoLi transaction via PPRO caused a problem.',
        ],
        '245' => [
            'message' => 'PPRO QIWI',
            'description' => 'The processing of a QIWI transaction via PPRO caused a problem.',
        ],
        '246' => [
            'message' => 'PPRO TrustPay',
            'description' => 'The processing of a Trustpay transaction via PPRO caused a problem.',
        ],
        '247' => [
            'message' => 'PPRO ELV',
            'description' => 'The processing of a ELV transaction (German direct debits) via PPRO caused a problem.',
        ],
        '248' => [
            'message' => 'PPRO SafetyPay',
            'description' => 'The processing of a SafetyPay transaction via PPRO caused a problem.',
        ],
        '249' => [
            'message' => 'PPRO Alipay',
            'description' => 'The processing of an Alipay transaction via PPRO caused a problem.',
        ],
        '250' => [
            'message' => 'Debtor management',
            'description' => 'The processing of the debtor management caused a problem.',
        ],
        '251' => [
            'message' => 'Banksys',
            'description' => 'The processing of a Banksys transaktion caused a problem.',
        ],
        '252' => [
            'message' => 'Amazon APA',
            'description' => 'The processing of an Amazon APA transaction caused a problem.',
        ],
        '253' => [
            'message' => 'BIG',
            'description' => 'The processing of a BIG transaction caused a problem.',
        ],
        '254' => [
            'message' => 'Be2bill',
            'description' => 'The processing of a Be2bill transaction caused a problem.',
        ],
        '255' => [
            'message' => 'Credorax',
            'description' => 'The processing of a Credorax transaction caused a problem.',
        ],
        '256' => [
            'message' => 'Limonetik',
            'description' => 'The processing of a Limonetik transaction caused a problem.',
        ],
        '257' => [
            'message' => 'PPRO Multibanco',
            'description' => 'The processing of a Multibanco transaction via PPRO caused a problem.',
        ],
        '258' => [
            'message' => 'PPRO Finland Online Bank Transfer',
            'description' => 'The processing of a Finland Online Bank Transfer transaction via PPRO caused a problem.',
        ],
        '259' => [
            'message' => 'PPRO Bancontact',
            'description' => 'The processing of a Bancontact transaction via PPRO caused a problem.',
        ],
        '260' => [
            'message' => 'PaymentWizard',
            'description' => 'The processing via PaymentWizard caused a problem.',
        ],
        '261' => [
            'message' => 'PPRO MyBank',
            'description' => 'The processing of a MyBank transaction via PPRO caused a problem.',
        ],
        '262' => [
            'message' => 'RedSys',
            'description' => 'The processing of a credit card transaction caused a problem.',
        ],
        '263' => [
            'message' => 'AMEXCAPN',
            'description' => 'The processing of a AMEX CAPN transaction caused a problem.',
        ],
        '264' => [
            'message' => 'KlarnaCheckout',
            'description' => 'The processing of a Klarna Checkout transaction caused a problem.',
        ],
        '265' => [
            'message' => 'POSTPAY',
            'description' => 'The processing of a POSTPAY transaction caused a problem.',
        ],
        '266' => [
            'message' => 'iPAYst',
            'description' => 'The processing of a iPAYst transaction caused a problem.',
        ],
        '267' => [
            'message' => 'PayULU',
            'description' => 'The processing of a PayULU transaction caused a problem.',
        ],
        '268' => [
            'message' => 'PayUALU',
            'description' => 'The processing of a PayUALU transaction caused a problem.',
        ],
        '269' => [
            'message' => 'SIA',
            'description' => 'The processing of a SIA transaction caused a problem.',
        ],
        '270' => [
            'message' => 'RedCard',
            'description' => 'The processing of a credit card transaction caused a problem.',
        ],
        '271' => [
            'message' => 'Heartland',
            'description' => 'The processing of a Heartland transaction caused a problem.',
        ],
        '272' => [
            'message' => 'CB2A',
            'description' => 'The processing of a CB2A transaction caused a problem.',
        ],
        '273' => [
            'message' => 'Paydirekt',
            'description' => 'The processing of a Paydirect transaction caused a problem.',
        ],
        '274' => [
            'message' => 'PayULatACC',
            'description' => 'The processing of a PayU LatAm transaction caused a problem.',
        ],
        '275' => [
            'message' => 'PayULatAWC',
            'description' => 'The processing of a PayU LatAm transaction caused a problem.',
        ],
        '276' => [
            'message' => 'Chinapay',
            'description' => 'The processing of a Chinapay transaction caused a problem.',
        ],
        '277' => [
            'message' => 'Testcard',
            'description' => 'The processing of a testcard transaction caused a problem.',
        ],
        '278' => [
            'message' => 'KoreaCC',
            'description' => 'The processing of a KoreaCC transaction caused a problem.',
        ],
        '279' => [
            'message' => 'CardComplete',
            'description' => 'The processing of a CardComplete transaction caused a problem.',
        ],
        '280' => [
            'message' => 'ChasePNS',
            'description' => 'The processing of a ChasePNS transaction caused a problem.',
        ],
        '281' => [
            'message' => 'RBI',
            'description' => 'The processing of a RBI transaction caused a problem.',
        ],
        '282' => [
            'message' => 'MasaPay',
            'description' => 'The processing of a MasaPay transaction caused a problem.',
        ],
        '283' => [
            'message' => 'SafeCharge',
            'description' => 'The processing of a SafeCharge transaction caused a problem.',
        ],
        '284' => [
            'message' => 'PPRO Boleto Bancario',
            'description' => 'The processing of a Boleto Bancario transaction via PPRO caused a problem.',
        ],
        '285' => [
            'message' => 'PPRO China UnionPay',
            'description' => 'The processing of a China UnionPay transaction via PPRO caused a problem.',
        ],
        '286' => [
            'message' => 'PPRO WeChat Pay',
            'description' => 'The processing of a WeChat Pay transaction via PPRO caused a problem.',
        ],
        '287' => [
            'message' => 'PPRO Zimpler',
            'description' => 'The processing of a Zimpler transaction via PPRO caused a problem.',
        ],
        '288' => [
            'message' => 'IFSF',
            'description' => 'The processing of a IFSF transaction caused a problem.',
        ],
        '289' => [
            'message' => 'KlarnaPayment',
            'description' => 'The processing of a Klarna Payment transaction caused a problem.',
        ],
        '290' => [
            'message' => 'girocard',
            'description' => 'The processing of a POS giropay transaction caused a problem.',
        ],
        '300' => [
            'message' => 'POS',
            'description' => 'The processing of a POS transaction caused a problem.',
        ],
        '305' => [
            'message' => 'POSCC',
            'description' => 'The processing of a credit or debit card transaction via POS terminal caused a problem.',
        ],
        '311' => [
            'message' => 'POSELV',
            'description' => 'The processing of a ELV transaction (German direct debits) via POS terminal caused a problem.',
        ],
        '316' => [
            'message' => 'POSGIROPAY',
            'description' => 'The processing of a giropay transaction via POS terminal caused a problem.',
        ],
        '360' => [
            'message' => 'POSGK',
            'description' => 'The processing of a payment card transaction via POS terminal caused a problem.',
        ],
    ],
    'parameters' => [
        '0000' => [
            'message' => 'Unspecified',
            'description' => 'Unspecified problem which needs to be analysed manually, please contact Computop support.',
        ],
        '0001' => [
            'message' => 'Payid',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0002' => [
            'message' => 'transId',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0003' => [
            'message' => 'MerchantID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0004' => [
            'message' => 'ReqID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0005' => [
            'message' => 'Amount',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0006' => [
            'message' => 'Currency',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0007' => [
            'message' => 'Data',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0008' => [
            'message' => 'Len',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0009' => [
            'message' => 'Capture',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0010' => [
            'message' => 'Response',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0011' => [
            'message' => 'Orderdesc',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0012' => [
            'message' => 'Orderdesc2',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0013' => [
            'message' => 'CHDesc',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0014' => [
            'message' => 'Plain',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0015' => [
            'message' => 'CCNr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0016' => [
            'message' => 'CCNr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0017' => [
            'message' => 'CCExpiry',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0018' => [
            'message' => 'CCBrand',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0019' => [
            'message' => 'CCCVC',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0020' => [
            'message' => 'INVALID PARAM: URLSUCCESS',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0021' => [
            'message' => 'INVALID PARAM: URLFAILURE',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0022' => [
            'message' => 'INVALID PARAM: URLNOTIFY',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0023' => [
            'message' => 'Accowner',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0024' => [
            'message' => 'AccNr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0025' => [
            'message' => 'AccBank',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0026' => [
            'message' => 'AccIBAN',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0027' => [
            'message' => 'AccIBANList',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0028' => [
            'message' => 'PARes',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0029' => [
            'message' => 'MobileNo',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0030' => [
            'message' => 'MobileNet',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0031' => [
            'message' => 'insStatus',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0032' => [
            'message' => 'RefNr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0033' => [
            'message' => 'Zone',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0034' => [
            'message' => 'TransURL',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0035' => [
            'message' => 'Textfeld1',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0036' => [
            'message' => 'Textfeld2',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0037' => [
            'message' => 'Firstname',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0038' => [
            'message' => 'gender',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0039' => [
            'message' => 'birthdate',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0040' => [
            'message' => 'No Response',
            'description' => 'Backend systems (e.g. acquiring, card schemes or payment schemes API) was not responding.',
        ],
        '0041' => [
            'message' => 'Startdate',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0042' => [
            'message' => 'Enddate',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0043' => [
            'message' => 'MerchantIDExt',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0044' => [
            'message' => 'MAC',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0045' => [
            'message' => 'Merchant Busy',
            'description' => 'Overload of the merchant account.',
        ],
        '0046' => [
            'message' => 'No TID available',
            'description' => 'No terminal ID available for incoming transaction.',
        ],
        '0047' => [
            'message' => 'Missing TID',
            'description' => 'The necessary TerminalID was missing.',
        ],
        '0048' => [
            'message' => 'Missing VuNr',
            'description' => 'The merchant number with the acquiring bank was missing.',
        ],
        '0049' => [
            'message' => 'expirationTime',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0050' => [
            'message' => 'System Error',
            'description' => 'The Paygate or backend systems transmitted a system error.',
        ],
        '0051' => [
            'message' => 'Timeout / Request timed out',
            'description' => 'Processing error due to timeout.',
        ],
        '0052' => [
            'message' => 'Communication Error',
            'description' => 'Processing error due to communication problems.',
        ],
        '0053' => [
            'message' => 'Cancel by User',
            'description' => 'Processing aborted by user.',
        ],
        '0054' => [
            'message' => 'Reversal',
            'description' => 'The reversal of a transaction caused an error.',
        ],
        '0055' => [
            'message' => 'Unknown',
            'description' => 'Unknown problem which needs to be analysed manually, please contact Computop support.',
        ],
        '0056' => [
            'message' => 'Timeout',
            'description' => 'The individual timeout between Paygate and merchant system was exceeded (NVAG).',
        ],
        '0057' => [
            'message' => 'Credit agencies',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0058' => [
            'message' => 'IssuerID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0059' => [
            'message' => 'Account',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0060' => [
            'message' => 'Not active',
            'description' => 'The transmitted transaction type was not activated for the merchant account, please contact Computop support.',
        ],
        '0061' => [
            'message' => 'Not found',
            'description' => 'The payment could not be found due to an erraneous PAYID.',
        ],
        '0062' => [
            'message' => 'Other transaction active',
            'description' => 'Another transaction step was pending and therefore blocking the requested transaction.',
        ],
        '0063' => [
            'message' => 'Not allowed',
            'description' => 'The transaction was not allowed.',
        ],
        '0064' => [
            'message' => 'splitting active',
            'description' => 'For enhanced transaction management only: the Paygate was carrying out an authorisation after a partial capture and could therefore not process the requested transaction.',
        ],
        '0065' => [
            'message' => 'capture active',
            'description' => 'For enhanced transaction management only: the Paygate was carrying out an a capture transaction and could therefore not process the requested transaction.',
        ],
        '0066' => [
            'message' => 'credit active',
            'description' => 'For enhanced transaction management only: the Paygate was carrying out an a credit (refund) transaction and could therefore not process the requested transaction.',
        ],
        '0067' => [
            'message' => 'Overcapture',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0068' => [
            'message' => 'Already Authorized',
            'description' => 'The payment has already been authorised.',
        ],
        '0069' => [
            'message' => 'Nothing captured',
            'description' => 'The capture was not processed due to a lacking prior authorisation.',
        ],
        '0070' => [
            'message' => 'MinValue',
            'description' => 'The capture was not processed due to an amount lower than the minimum value (for individual minvalues, please contact our support).',
        ],
        '0071' => [
            'message' => 'Disabled',
            'description' => 'The requested function was deactivated, e.g. captures during the test phase.',
        ],
        '0072' => [
            'message' => 'Already captured',
            'description' => 'The capture has already been carried out and could not be repeated.',
        ],
        '0073' => [
            'message' => 'Aborted',
            'description' => 'The transaction was aborted.',
        ],
        '0074' => [
            'message' => 'Amount override',
            'description' => 'The capture amount was higher than the admitted amount which was linked to the prior authorisation.',
        ],
        '0075' => [
            'message' => 'Nothing authorized',
            'description' => 'Authorisation missing.',
        ],
        '0076' => [
            'message' => 'Capture abort impossible',
            'description' => 'The capture was being processed (Capture_Request, Capture_Waiting) and therefore could not be aborted.',
        ],
        '0077' => [
            'message' => 'No valid paymethod found',
            'description' => 'The requested payment type was not activated for the merchant account, please contact Computop support.',
        ],
        '0078' => [
            'message' => 'Paymethod invalid',
            'description' => 'The requested payment type was not supported for the payment method.',
        ],
        '0079' => [
            'message' => 'ValidationURL',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0080' => [
            'message' => 'Paymethod not supported',
            'description' => 'The requested payment type was not supported for the payment method.',
        ],
        '0081' => [
            'message' => 'Action not supported',
            'description' => 'The payment method did not support the requested paytype (e.g. Capture for GeldKarte)',
        ],
        '0082' => [
            'message' => 'Invalid paymethod',
            'description' => 'The requested payment type was not supported for the payment method.',
        ],
        '0083' => [
            'message' => 'System error',
            'description' => 'System error.',
        ],
        '0084' => [
            'message' => 'MobileNo invalid',
            'description' => 'The mobile number was invalid.',
        ],
        '0085' => [
            'message' => 'Channel',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0086' => [
            'message' => 'SellingPoint',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0087' => [
            'message' => 'Service',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0088' => [
            'message' => 'AccBankCity',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0089' => [
            'message' => 'BankCode',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0090' => [
            'message' => '3DSecure SetValue failed',
            'description' => 'Initialization of the Merchant Plugin for Verified by Visa and MasterCard SecureCode has failed.',
        ],
        '0091' => [
            'message' => 'Not enrolled',
            'description' => 'Customer’s credit card number was not activated for Verified by Visa or MasterCard SecureCode.',
        ],
        '0092' => [
            'message' => 'No PaResponse',
            'description' => 'Parameter PAResponse was not transmitted to Direct3D.aspx.',
        ],
        '0093' => [
            'message' => 'No JavaScript',
            'description' => 'Customer’s bcolumnser did not support JavaScript which is necessary for Verified by Visa and SecureCode.',
        ],
        '0094' => [
            'message' => 'Expiry date run out',
            'description' => 'Card expired.',
        ],
        '0095' => [
            'message' => 'Unable to authenticate',
            'description' => 'Card is ineligible for 3D Secure',
        ],
        '0096' => [
            'message' => 'Non-Participation',
            'description' => 'Customer’s credit card number was not activated for Verified by Visa or MasterCard SecureCode.',
        ],
        '0097' => [
            'message' => 'Verification error',
            'description' => 'during VerifyEnrollment an error has occurred',
        ],
        '0098' => [
            'message' => 'PaymentAuthenication error',
            'description' => 'during authentication an error has occurred',
        ],
        '0099' => [
            'message' => 'XID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0100' => [
            'message' => 'Declined',
            'description' => 'The issuing bank refused the payment.',
        ],
        '0101' => [
            'message' => 'Disabled',
            'description' => 'The transaction type was disabled and could not be processed.',
        ],
        '0102' => [
            'message' => 'Invalid card number',
            'description' => 'Invalid card number.',
        ],
        '0103' => [
            'message' => 'Call issuer',
            'description' => 'Issuer refused payment, please call the issuer.',
        ],
        '0104' => [
            'message' => 'declined by BlackList ',
            'description' => 'The transmitted credit or debit card was listed in the merchant blacklist and was therefore rejected.',
        ],
        '0105' => [
            'message' => 'Amex AVS no match',
            'description' => 'Transmitted data did not match American Express data (address verification).',
        ],
        '0106' => [
            'message' => 'CardNumber',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0107' => [
            'message' => 'VerificationCode',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0108' => [
            'message' => 'OperatorID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0110' => [
            'message' => 'Expired',
            'description' => 'Card expired.',
        ],
        '0111' => [
            'message' => 'Brand not supported',
            'description' => 'Selected credit card brand was not supported.',
        ],
        '0112' => [
            'message' => 'AuthLabel',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0113' => [
            'message' => 'AuthToken',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0114' => [
            'message' => 'ExpiryDate',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0115' => [
            'message' => 'AuthCode',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0116' => [
            'message' => 'Total',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0117' => [
            'message' => 'InvoiceList',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0118' => [
            'message' => 'Revocation of Authorization Order',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0119' => [
            'message' => 'Revocation of All Authorization Order',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0120' => [
            'message' => 'Pick up card',
            'description' => 'Pick up the used invalid card (POS).',
        ],
        '0121' => [
            'message' => 'Issuer not reachable',
            'description' => 'Issuing bank was temporarily unavailable.',
        ],
        '0122' => [
            'message' => 'CCBin',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0130' => [
            'message' => 'PCNR mismatch',
            'description' => 'The transmitted pseudo card number was invalid.',
        ],
        '0131' => [
            'message' => 'PBAN MISMATCH',
            'description' => 'The transmitted PBAN was invalid.',
        ],
        '0132' => [
            'message' => 'Term',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0133' => [
            'message' => 'Employment',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0134' => [
            'message' => 'MonthlyNetIncome',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0135' => [
            'message' => 'PackingStation',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0136' => [
            'message' => 'PlaceOfBirth',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0137' => [
            'message' => 'CustomerStatus',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0138' => [
            'message' => 'CustomerSince',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0139' => [
            'message' => 'CustomerLoggedIn',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0140 ' => [
            'message' => 'Person Mismatch',
            'description' => 'The requested person differed in the parameters birthdate or address (Schufa interface only).',
        ],
        '0141' => [
            'message' => 'NumberArticles',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0142' => [
            'message' => 'NumberOrders',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0143' => [
            'message' => 'NegativePaymentInfo',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0144' => [
            'message' => 'RiskArticles',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0145' => [
            'message' => 'Date',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0146' => [
            'message' => 'Order',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0147' => [
            'message' => 'CustomerRisk',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0161' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the IP-check within Securepay (limit per hour).',
        ],
        '0162' => [
            'message' => 'DECLINED BY FRAUD ',
            'description' => 'Payment rejected due to the settings of the card -check within Securepay (limit per hour).',
        ],
        '0163' => [
            'message' => 'DECLINED BY FRAUD ',
            'description' => 'Payment rejected due to the settings of the amount-check combined with the IP-check within Securepay (limit per hour).',
        ],
        '0164' => [
            'message' => 'DECLINED BY FRAUD ',
            'description' => 'Payment rejected due to the settings of the amount-check combined with the card-check within Securepay (limit per hour).',
        ],
        '0165' => [
            'message' => 'DECLINED BY FRAUD ',
            'description' => 'Payment rejected due to the settings of the parameter-check (identical reference number and/or transId) within Securepay (limit per hour).',
        ],
        '0166' => [
            'message' => 'DECLINED BY FRAUD ',
            'description' => 'Payment rejected due to the settings of the card/IP-check check within Securepay (limit per hour).',
        ],
        '0167' => [
            'message' => 'DECLINED BY FRAUD ',
            'description' => 'Payment rejected due to the settings of the  DeviceID-Check within Securepay (limit per hour).',
        ],
        '0168' => [
            'message' => 'DECLINED BY FRAUD ',
            'description' => 'Payment rejected due to the settings of the  DeviceID/Card-Check within Securepay (limit per hour).',
        ],
        '0169' => [
            'message' => 'DECLINED BY FRAUD ',
            'description' => 'Payment rejected due to the settings of the  DeviceID/IP-Check within Securepay (limit per hour).',
        ],
        '0170 ' => [
            'message' => 'Declined by Whitelist',
            'description' => 'Card/BIN was not part of whitelist and therefore rejected.',
        ],
        '0190' => [
            'message' => 'Zone mismatch',
            'description' => 'The transmitted shipping country did not match the issuing country of the credit card.',
        ],
        '0191' => [
            'message' => 'IP Zone mismatch',
            'description' => 'The customer was using an IP-address which was not part of your individual country list.',
        ],
        '0192' => [
            'message' => 'IP CCOrigin mismatch',
            'description' => 'The customer was using an IP-address which did not match the credit card\'s issuing country.',
        ],
        '0193' => [
            'message' => 'IP Tracking Error',
            'description' => 'Error while analysing the customer\'s IP-address.',
        ],
        '0194' => [
            'message' => 'IP IBAN ORIGIN MISMATCH',
            'description' => 'The country of the IP-address does not match the country of the IBAN.',
        ],
        '0200' => [
            'message' => 'Authentication failed',
            'description' => 'Authentication via Verified by Visa and/or MasterCard SecureCode failed.',
        ],
        '0201' => [
            'message' => 'signature failed',
            'description' => 'Authentication via Verified by Visa and/or MasterCard SecureCode failed.',
        ],
        '0202' => [
            'message' => 'Bypass processing disabled',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0203' => [
            'message' => 'Brand does not support 3D Secure',
            'description' => 'Card brand not participating in 3D secure.',
        ],
        '0301' => [
            'message' => 'Missing Response',
            'description' => 'Banking data centre\'s response was incomplete.',
        ],
        '0302' => [
            'message' => 'Declined, authorization via telephone possible',
            'description' => 'Payment rejected.',
        ],
        '0303' => [
            'message' => 'Invalid VU number',
            'description' => 'System error within the banking data centre.',
        ],
        '0304' => [
            'message' => 'Card not allowed',
            'description' => 'The used card was not allowed.',
        ],
        '0305' => [
            'message' => 'Rejected by authorization system',
            'description' => 'The authorisation system rejected the card authorisation: for data security reasons, further detailed information is not transmitted to the Paygate and only known by the issuing bank.',
        ],
        '0306' => [
            'message' => 'FileTransfer wrong',
            'description' => 'Wrong file transfer or sequence number.',
        ],
        '0307' => [
            'message' => 'unable to convert account data',
            'description' => 'The account data couldn\'t converted by InterCard. (NoResponse or invalid account data)',
        ],
        '0309' => [
            'message' => 'Delayed processing of authorisation',
            'description' => 'Point of Sale: transaction failed.',
        ],
        '0312' => [
            'message' => 'Transaction invalid',
            'description' => 'Invalid transaction, e.g. due to a wrong currency.',
        ],
        '0313' => [
            'message' => 'Limit exceeded',
            'description' => 'The limit has been exceeded.',
        ],
        '0314' => [
            'message' => 'Card invalid',
            'description' => 'The card was invalid.',
        ],
        '0321' => [
            'message' => 'Initial transaction could not be found',
            'description' => 'System error within the banking data centre.',
        ],
        '0324' => [
            'message' => 'Filetransfer not supported',
            'description' => 'Point of Sale: transaction failed.',
        ],
        '0329' => [
            'message' => 'Filetransfer not successful',
            'description' => 'Point of Sale: transaction failed.',
        ],
        '0330' => [
            'message' => 'wrong format',
            'description' => 'System error within the banking data centre.',
        ],
        '0331' => [
            'message' => 'Issuer invalid',
            'description' => 'Issuer invalid/not allowed.',
        ],
        '0333' => [
            'message' => 'Expiry date run out',
            'description' => 'Expiry date of the card run out.',
        ],
        '0334' => [
            'message' => 'possible fraud',
            'description' => 'Potentially fraudulent payment.',
        ],
        '0340' => [
            'message' => 'Action not supported',
            'description' => 'Payment rejected due to a system error within the banking data centre.',
        ],
        '0341' => [
            'message' => 'Karte verloren, bitte einziehen',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0343' => [
            'message' => 'Card stolen, pick up card.',
            'description' => 'Card stolen, pick up card.',
        ],
        '0349' => [
            'message' => 'Wrong currency',
            'description' => 'Wrong currency transmitted to API.',
        ],
        '0350' => [
            'message' => 'Double authorization',
            'description' => 'There has been a double authorisation.',
        ],
        '0351' => [
            'message' => 'Limit überschritten, Doch-Funktion möglich',
            'description' => 'Card limit exceeded.',
        ],
        '0352' => [
            'message' => 'Account not found or inexistant',
            'description' => 'Point of Sale: The Parameter in column B caused a problem.',
        ],
        '0354' => [
            'message' => 'ec-Chip invalid',
            'description' => 'The used chip card was invalid.',
        ],
        '0355' => [
            'message' => 'PIN incorrect',
            'description' => 'The used PIN is invalid.',
        ],
        '0356' => [
            'message' => 'Card invalid',
            'description' => 'The used card is invalid/not allowed.',
        ],
        '0357' => [
            'message' => 'Initial transaction could not be found',
            'description' => 'System error within the banking data centre.',
        ],
        '0358' => [
            'message' => 'Transaktion nicht erlaubt',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0359' => [
            'message' => 'possible fraud',
            'description' => 'Potentially fraudulent payment.',
        ],
        '0361' => [
            'message' => 'card blocked due to black list',
            'description' => 'Card blocked in local blacklist.',
        ],
        '0362' => [
            'message' => 'card blocked',
            'description' => 'Card blocked.',
        ],
        '0364' => [
            'message' => 'Transaction amount not equal to reference transaction',
            'description' => 'Point of Sale: the parameter in column B caused a problem.',
        ],
        '0365' => [
            'message' => 'Limit of transaction frequency exceeded',
            'description' => 'Point of Sale: the parameter in column B caused a problem.',
        ],
        '0367' => [
            'message' => 'Karte einziehen',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0368' => [
            'message' => 'System not responding, Timeout',
            'description' => 'Point of Sale: the parameter in column B caused a problem.',
        ],
        '0375' => [
            'message' => 'maloperation counter within AS lapsed',
            'description' => 'Point of Sale: the parameter in column B caused a problem.',
        ],
        '0376' => [
            'message' => 'wrong index',
            'description' => 'System error within the banking data centre.',
        ],
        '0377' => [
            'message' => 'PIN has to be entered / error in BMP62',
            'description' => 'Point of Sale: the parameter in column B caused a problem.',
        ],
        '0378' => [
            'message' => 'Sequence error in BMP62 / transaction system can not be accessed',
            'description' => 'Point of Sale: the parameter in column B caused a problem.',
        ],
        '0379' => [
            'message' => 'Database could not be accessed',
            'description' => 'Point of Sale: the parameter in column B caused a problem.',
        ],
        '0380' => [
            'message' => 'requested amount exceeds limit',
            'description' => 'Point of Sale: the parameter in column B caused a problem.',
        ],
        '0381' => [
            'message' => 'Initialization corrupted',
            'description' => 'Point of Sale: the parameter in column B caused a problem.',
        ],
        '0382' => [
            'message' => '(pre-) initialization not possible',
            'description' => 'Point of Sale: the parameter in column B caused a problem.',
        ],
        '0383' => [
            'message' => 'PIN-Pad-exchange not possible',
            'description' => 'PIN-Pad-Change not possible (POS only).',
        ],
        '0385' => [
            'message' => 'declined by issuer',
            'description' => 'Payment rejected by issuing bank.',
        ],
        '0386' => [
            'message' => 'Master data invalid, ZKA-No. wrong',
            'description' => 'System error within the banking data centre.',
        ],
        '0387' => [
            'message' => 'Terminal unknown',
            'description' => 'System error within the banking data centre.',
        ],
        '0388' => [
            'message' => 'PIN not active',
            'description' => 'Point of Sale: the parameter in column B caused a problem.',
        ],
        '0389' => [
            'message' => 'Wrong CRC',
            'description' => 'Point of Sale: the parameter in column B caused a problem.',
        ],
        '0391' => [
            'message' => 'Issuer unavailable',
            'description' => 'Issuing bank or bank network was temporarily unavailable.',
        ],
        '0392' => [
            'message' => 'Authorization system detected a wrong routing',
            'description' => 'System error within the banking data centre.',
        ],
        '0396' => [
            'message' => 'processing not possible',
            'description' => 'Processing was not possible temporarily.',
        ],
        '0397' => [
            'message' => 'encryption error',
            'description' => 'System error within the banking data centre.',
        ],
        '0398' => [
            'message' => 'Date/Time mismatch, wrong Trace-No.',
            'description' => 'System error within the banking data centre: either date/time stamp was erraneous or trace number was not ascending.',
        ],
        '0399' => [
            'message' => 'unknown',
            'description' => 'System error within the banking data centre.',
        ],
        '0400' => [
            'message' => 'Mobile number unknown',
            'description' => 'The used telephone number was not a prepaid phone number.',
        ],
        '0401' => [
            'message' => 'Declined',
            'description' => 'Topping up of the prepaid card was not possible temporarily.',
        ],
        '0402' => [
            'message' => 'Declined',
            'description' => 'Topping up of the prepaid card was not possible temporarily.',
        ],
        '0403' => [
            'message' => 'Chargelimit reached',
            'description' => 'Maximum topping up amount was reached.',
        ],
        '0404' => [
            'message' => 'Charging blocked',
            'description' => 'Charging was blocked. Credit card was not charged.',
        ],
        '0405' => [
            'message' => 'Internal authorization system error',
            'description' => 'Charging was blocked. Credit card was not charged.',
        ],
        '0406' => [
            'message' => 'Authorization system internal connection error',
            'description' => 'Charging was blocked. Credit card was not charged.',
        ],
        '0407' => [
            'message' => 'Internal authorization system error',
            'description' => 'Charging was blocked. Credit card was not charged.',
        ],
        '0408' => [
            'message' => 'Mobile number unknown or not found',
            'description' => 'The phone number was not a valid prepaid number.',
        ],
        '0409' => [
            'message' => 'System error',
            'description' => 'Charging was blocked. Credit card was not charged.',
        ],
        '0410' => [
            'message' => 'Invalid amount',
            'description' => 'The transmitted topping up amount was invalid.',
        ],
        '0411' => [
            'message' => 'Charging status unknown, call back (T-Mobile)',
            'description' => 'The status of topping up was unknown: please contact T-Mobile.',
        ],
        '0412' => [
            'message' => 'Charging status unknown, call back (Vodafone)',
            'description' => 'The status of topping up was unknown: please contact Vodafone.',
        ],
        '0413' => [
            'message' => 'Call GZS hotline: Code-Nr 01',
            'description' => 'The status of topping up was unknown: please contact easycash.',
        ],
        '0414' => [
            'message' => 'Invalid VU number',
            'description' => 'The merchant number of your acquiring agreement was invalid, please contact Computop support.',
        ],
        '0415' => [
            'message' => 'Cashback not possible',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0500' => [
            'message' => 'Invalid',
            'description' => 'the combination banking code and bank account number was invalid.',
        ],
        '0501' => [
            'message' => 'Missing file',
            'description' => 'The file for bank code checks was unavailable.',
        ],
        '0502' => [
            'message' => 'Konto Check error',
            'description' => 'System error while checking the bank code.',
        ],
        '0510' => [
            'message' => 'olv check failed',
            'description' => 'Direct Debit rejected.',
        ],
        '0600' => [
            'message' => 'Invalid ID',
            'description' => 'Credit rejected - initial transaction could not be found.',
        ],
        '0650' => [
            'message' => 'ShopID not transferred',
            'description' => 'The configuration of the payment method has not been finished, please contact Computop support.',
        ],
        '0651' => [
            'message' => 'ShopID unknown',
            'description' => 'The configuration of the payment method has not been finished, please contact Computop support.',
        ],
        '0652' => [
            'message' => 'Customer ID not transferred',
            'description' => 'The configuration of the payment method has not been finished, please contact Computop support.',
        ],
        '0653' => [
            'message' => 'Customer ID unknown',
            'description' => 'The configuration of the payment method has not been finished, please contact Computop support.',
        ],
        '0654' => [
            'message' => 'Shop-password not transferred',
            'description' => 'The configuration of the payment method has not been finished, please contact Computop support.',
        ],
        '0655' => [
            'message' => 'Shop-password unknown',
            'description' => 'The configuration of the payment method has not been finished, please contact Computop support.',
        ],
        '0656' => [
            'message' => 'Missing TransType',
            'description' => 'The configuration of the payment method has not been finished, please contact Computop support.',
        ],
        '0657' => [
            'message' => 'Invalid TransType',
            'description' => 'The configuration of the payment method has not been finished, please contact Computop support.',
        ],
        '0658' => [
            'message' => 'TransType Not Allowed',
            'description' => 'The configuration of the payment method has not been finished, please contact Computop support.',
        ],
        '0664' => [
            'message' => 'Invalid Banking Account',
            'description' => 'Online bank transfer: invalid account number.',
        ],
        '0665' => [
            'message' => 'Invalid OrderNo',
            'description' => 'The configuration of the payment method has not been finished, please contact Computop support.',
        ],
        '0670' => [
            'message' => 'BLZV',
            'description' => 'The parameter BLZV caused the problem.',
        ],
        '0702' => [
            'message' => 'Invalid',
            'description' => 'Validation error.',
        ],
        '0703' => [
            'message' => 'User Canceled',
            'description' => 'User cancelled.',
        ],
        '0705' => [
            'message' => 'result uncertain',
            'description' => 'The definite payment status could not be transmitted.',
        ],
        '0709' => [
            'message' => 'indoubt',
            'description' => 'The backend system has not confirmed the transaction yet',
        ],
        '0710' => [
            'message' => 'The status of the banking data centre is unknown.',
            'description' => 'The backend system rejected the transaction.',
        ],
        '0720' => [
            'message' => 'Invalid Hash',
            'description' => 'Wrong length or format of the Hash key.',
        ],
        '0721 ' => [
            'message' => 'Incorrect Hash',
            'description' => 'Wrong calculation of the Hash key.',
        ],
        '0722' => [
            'message' => 'User Unknown',
            'description' => 'User unknown by Schufa.',
        ],
        '0723' => [
            'message' => 'Invalid user',
            'description' => 'User aborted process and was unknown.',
        ],
        '0777' => [
            'message' => 'Request / Response mismatch',
            'description' => 'Credit- or debit card payment rejected due to error within the banking data centre.',
        ],
        '0801' => [
            'message' => 'Certificate/Signature error',
            'description' => 'Authentication failed due to certificate error (Schufa).',
        ],
        '0802' => [
            'message' => 'Certificate/Signature missing',
            'description' => 'Authentication failed due to certificate error (Schufa).',
        ],
        '0803' => [
            'message' => 'too many requests',
            'description' => 'Authentication failed due to exceeded amount of parallel requests.',
        ],
        '0804' => [
            'message' => 'Communication to host disturbed',
            'description' => 'Communication error with Schufa.',
        ],
        '0805' => [
            'message' => 'Host not reachable',
            'description' => 'Communication error with Schufa.',
        ],
        '0806' => [
            'message' => 'Host overloaded',
            'description' => 'Communication error with Schufa.',
        ],
        '0807' => [
            'message' => 'Field value missing or invalid',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0808' => [
            'message' => 'Access denied',
            'description' => 'Authentisierung failed (Schufa).',
        ],
        '0809' => [
            'message' => 'Internal error',
            'description' => 'System error (Schufa).',
        ],
        '0810' => [
            'message' => 'unknown',
            'description' => 'Unknown error (Schufa).',
        ],
        '0851' => [
            'message' => 'RED: Address invalid',
            'description' => 'Name analysis was not possible: data incorrect or available for several people.',
        ],
        '0852' => [
            'message' => 'RED: Address incomplete',
            'description' => 'Incomplete address data.',
        ],
        '0853' => [
            'message' => 'RED: unknown',
            'description' => 'Unknown error whil checking address.',
        ],
        '0854' => [
            'message' => 'RED: Correct name',
            'description' => 'Data error: adjust name.',
        ],
        '0855' => [
            'message' => 'RED: Correct address',
            'description' => 'Data error: adjust address.',
        ],
        '0856' => [
            'message' => 'RED: invalid data type',
            'description' => 'Data error: invalid data type within XML-Nachricht to Paycontrol.',
        ],
        '0857' => [
            'message' => 'RED: internal error',
            'description' => 'Internal error whilst interpreting creditworthiness check.',
        ],
        '0861' => [
            'message' => 'YELLOW: (recommendations based on a "traffic light system")',
            'description' => 'Negative creditworthiness check or soft negative features for the person.',
        ],
        '0862' => [
            'message' => 'ROT: (recommendations based on a "traffic light system")',
            'description' => 'Medium or hard negative features for the person or invalid address or incomplete.',
        ],
        '0901' => [
            'message' => 'Message format error',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0902' => [
            'message' => 'External System Error',
            'description' => 'External System Error',
        ],
        '0904' => [
            'message' => 'Invalid value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0905' => [
            'message' => 'Processing error',
            'description' => 'The backend system rejected the transaction.',
        ],
        '0906' => [
            'message' => 'External Error, see CodeExt or ErrorText for details',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0921' => [
            'message' => 'FTG maintenance mode',
            'description' => 'Maintencance work of the Financial Transaction Gateway of the banks.',
        ],
        '0922' => [
            'message' => 'Bank is offline',
            'description' => 'Issuer was temporarily unavailable.',
        ],
        '0923' => [
            'message' => 'Invalid sender bank because of fusion',
            'description' => 'Customer\'s banking code was invalid due to merger between two banks.',
        ],
        '0924' => [
            'message' => 'Invalid sender account due to black list entry',
            'description' => 'Customer\'s account was not allowed due to blacklist entry.',
        ],
        '0925' => [
            'message' => 'Invalid sender account due to missing data',
            'description' => 'Customer\'s account was not allowed due to lacking information.',
        ],
        '0926' => [
            'message' => 'Internal error',
            'description' => 'Internal error within banking network.',
        ],
        '0927' => [
            'message' => 'MerchantTxId mismatch with PayId',
            'description' => 'Parameter MerchantTxId did not match the Computop PayID.',
        ],
        '0928' => [
            'message' => 'TxId missing',
            'description' => 'Paramter TxID was missing.',
        ],
        '0929' => [
            'message' => 'RedirectUrl missing',
            'description' => 'Parameter RedirectURL was missing.',
        ],
        '0930' => [
            'message' => 'Bank offline while entering PIN or TAN',
            'description' => 'Bank was not available upon entry of PIN and TAN.',
        ],
        '0931' => [
            'message' => 'Timeout due to missing PIN or TAN',
            'description' => 'Timeout during entry of PIN or TAN.',
        ],
        '0932' => [
            'message' => 'Bank message invalid online account',
            'description' => 'Bank notification: the transmitted bank account did not support online banking.',
        ],
        '0933' => [
            'message' => 'Transaction NOT authorized',
            'description' => 'Transaction could not be authorised.',
        ],
        '0934' => [
            'message' => 'Transaction status unknown',
            'description' => 'Final transaction status could not be retrieved.',
        ],
        '0935' => [
            'message' => 'Credit failed - Refund is pending or completed for this transaction',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0940' => [
            'message' => 'check sum incorrect',
            'description' => 'Direct debit or banking transfer rejected by bank check.',
        ],
        '0941' => [
            'message' => 'Bank unknown',
            'description' => 'Direct debit or banking transfer rejected by bank check.',
        ],
        '0942' => [
            'message' => 'Format invalid',
            'description' => 'Direct debit or banking transfer rejected by bank check.',
        ],
        '0943' => [
            'message' => 'Bank not featured',
            'description' => 'Direct debit or banking transfer rejected by bank check.',
        ],
        '0944' => [
            'message' => 'Karte gesperrt',
            'description' => '(Card locked) Debit or transfer was denied by bank check.',
        ],
        '0946' => [
            'message' => 'Cancellation by user',
            'description' => 'Transaction was aborted by customer, therefore rejected.',
        ],
        '0947' => [
            'message' => 'Account data invalid',
            'description' => 'Direct debit or banking transfer was rejected.',
        ],
        '0948 ' => [
            'message' => 'Card blocked',
            'description' => 'Transaction rejected due to blocked card.',
        ],
        '0949' => [
            'message' => 'Bank temporarily unavailable',
            'description' => 'Direct debit or transfer rejected by bank.',
        ],
        '0950' => [
            'message' => 'Authorize failed',
            'description' => 'Authorisation failed, no further details known.',
        ],
        '0951' => [
            'message' => 'Capture failed',
            'description' => 'Capture failed, no further details known.',
        ],
        '0952' => [
            'message' => 'Credit failed',
            'description' => 'Refund failed, no further details known.',
        ],
        '0953' => [
            'message' => 'Credit failed',
            'description' => 'Refund failed, money Transfer is not yet completed',
        ],
        '0954' => [
            'message' => 'Credit failed - Because a complaint case exists on this transaction',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0955' => [
            'message' => 'Credit failed - Refund failed as receiver account is closed',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0956' => [
            'message' => 'Credit failed - The account for the counterparty is locked or inactive',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0957' => [
            'message' => 'Credit failed - The partial refund amount must be less than or equal to the remaining amount',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0958' => [
            'message' => 'Credit failed - This transaction has already been fully refunded',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0959' => [
            'message' => 'Credit failed - You are over the time limit to perform a refund on this transaction',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0960' => [
            'message' => 'Credit failed - Refund is pending or completed for this transaction',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0961' => [
            'message' => 'TicketNr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0962' => [
            'message' => 'PassengerNr ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0963' => [
            'message' => 'FlightDate ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0964' => [
            'message' => 'Origin1 ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0965' => [
            'message' => 'Destination1 ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0966' => [
            'message' => 'Carrier1 ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0970' => [
            'message' => 'AddrState ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0971' => [
            'message' => 'AddrStreet ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0972' => [
            'message' => 'AddrHouseNr ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0973' => [
            'message' => 'AddrCountryCode ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0974' => [
            'message' => 'AddrZipCode ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0975' => [
            'message' => 'AddrCity ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0976' => [
            'message' => 'LastName ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0977' => [
            'message' => 'CompanyOrPerson ',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0978' => [
            'message' => 'FirstName missing',
            'description' => 'The Parameter in column B was missing.',
        ],
        '0979' => [
            'message' => 'Salutation missing',
            'description' => 'The Parameter in column B was missing.',
        ],
        '0980' => [
            'message' => 'PayerID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0981' => [
            'message' => 'trxType',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0982' => [
            'message' => 'Chargeback',
            'description' => 'PayPal notified a chargeback.',
        ],
        '0984' => [
            'message' => 'Voided',
            'description' => 'PayPal (IPN) transmitted a reversed transaction.',
        ],
        '0985' => [
            'message' => 'Pending',
            'description' => 'Transaction was not processed completely.',
        ],
        '0986' => [
            'message' => 'BILLINGAGREEMENTID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0987' => [
            'message' => 'PayPalMethod',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0988' => [
            'message' => 'TID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0989' => [
            'message' => 'IssuerID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0990' => [
            'message' => 'Limit',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0991' => [
            'message' => 'Declined by risk',
            'description' => 'The transaction was declined by acquiring bank due to fraud checks.',
        ],
        '0992' => [
            'message' => 'Not supported',
            'description' => 'The feature was not supported.',
        ],
        '0993' => [
            'message' => 'FxCurrency ',
            'description' => 'Transaction failed, details in column B.',
        ],
        '0994' => [
            'message' => 'Technical Error',
            'description' => 'The transaction failed due to a technical error in a downstream data system.',
        ],
        '0996' => [
            'message' => 'property',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0997' => [
            'message' => 'Transtext',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '0999' => [
            'message' => 'awardcode',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1000' => [
            'message' => 'UsageAgreement',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1001' => [
            'message' => 'Structural error',
            'description' => 'Backend system rejected payment due to format error.',
        ],
        '1002' => [
            'message' => 'CRC error',
            'description' => 'Backend system rejected payment due to security breach.',
        ],
        '1003' => [
            'message' => 'Flow lost during transaction',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1004' => [
            'message' => 'No connection',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1005' => [
            'message' => 'Error Processing CRRes',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1010' => [
            'message' => 'Error Processing VEReq',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1020' => [
            'message' => 'Invalid ACS URL',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1026' => [
            'message' => 'INVALID PARAMETER ACCDATEOFREGISTRATION ',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1030' => [
            'message' => 'Cardholder Not Participating',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1035' => [
            'message' => 'Cardholder Unable To Authenticate',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1036' => [
            'message' => 'Unsupported Cardholder Enrolled Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1040' => [
            'message' => 'Error Communicating with Visa Directory',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1050' => [
            'message' => 'Message reversed automatically',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1051' => [
            'message' => 'Error Processing PARes, Error Response Returned By ACS',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1055' => [
            'message' => 'Error Deserializing PARes',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1060' => [
            'message' => 'Missing or Invalid PARes',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1070' => [
            'message' => 'Error processing VERes',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1075' => [
            'message' => 'Encountered Empty VERes',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1080' => [
            'message' => 'Error processing PAReq',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1085' => [
            'message' => 'Error processing PAReq, Display Amount Could Not Be Determined',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1090' => [
            'message' => 'Unsupported PAReq Version requested by ACS',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1100' => [
            'message' => 'internal error (wrong card data)',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1101' => [
            'message' => 'Initial transaction could not be found for reversal',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1102' => [
            'message' => 'wrong amount for reversal',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1103' => [
            'message' => 'Ursprungszahlung bereits storniert',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1104' => [
            'message' => 'only credit cards for refunds',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1105' => [
            'message' => 'Wrong trace number',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1106' => [
            'message' => 'Erraneous card data',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1107' => [
            'message' => 'Card expired',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1108' => [
            'message' => 'Automated reversal not possible',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1109' => [
            'message' => 'Error while reading card data',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1110' => [
            'message' => 'Error Persisting Verification Information',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1111' => [
            'message' => 'Unknown provider',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1112' => [
            'message' => 'Wrong amount',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1113' => [
            'message' => 'Please carry out diagnosis',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1114' => [
            'message' => 'Transmit correct mobile number',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1115' => [
            'message' => 'No mobile number (PIN printing)',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1120' => [
            'message' => 'Error Persisting Authentication Information',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1125' => [
            'message' => 'Error Persisting Transaction_Lookup Information',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1126' => [
            'message' => 'Error Updating Transaction_Lookup Information',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1130' => [
            'message' => 'Error Persisting VERes Information',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1140' => [
            'message' => 'Error Persisting PARes Information',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1150' => [
            'message' => 'Error Persisting PAReq Information',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1160' => [
            'message' => 'Error Persisting VEReq Information',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1170' => [
            'message' => 'Error Persisting Information',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1201' => [
            'message' => 'Configuration Error',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1202' => [
            'message' => 'Authorization failed',
            'description' => 'Declined by mpass system',
        ],
        '1203' => [
            'message' => 'Transaction expired',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1204' => [
            'message' => 'Customer not active',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1205' => [
            'message' => 'Customer unknown',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1206' => [
            'message' => 'Customer not allowed',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1210' => [
            'message' => 'AboID',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1211' => [
            'message' => 'AboAction',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1212' => [
            'message' => 'AboAmount',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1213' => [
            'message' => 'Interval',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1214' => [
            'message' => 'Active',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1230' => [
            'message' => 'DunningDate',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1231' => [
            'message' => 'ReturnDebitDate',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1232' => [
            'message' => 'EventToken',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1233' => [
            'message' => 'CustomerId',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1234' => [
            'message' => 'RefPayID',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1235' => [
            'message' => 'ContractID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1250' => [
            'message' => 'Logical Error',
            'description' => 'The backend system rejected the transaction due to a system or configuration error.',
        ],
        '1251' => [
            'message' => 'Technical Error',
            'description' => 'The backend system rejected the transaction due to a system or configuration error.',
        ],
        '1260' => [
            'message' => 'Security Error',
            'description' => 'The backend system rejected the transaction due to a security check, details in column B.',
        ],
        '1261' => [
            'message' => 'Invalid CnB Parameter',
            'description' => 'The backend system rejected the transaction due to a security check, details in column B.',
        ],
        '1262' => [
            'message' => 'Invalid Password',
            'description' => 'The backend system rejected the transaction due to a security check, details in column B.',
        ],
        '1263' => [
            'message' => 'Access denied ',
            'description' => 'The backend system rejected the transaction due to a security check, details in column B.',
        ],
        '1264' => [
            'message' => 'NationCode',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1270' => [
            'message' => 'InstantAuth',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1271' => [
            'message' => 'MultiUse',
            'description' => 'Indicates whether the VAN should be able to be used multiple times up to the Maximum Auth Amount. If “false” then only a single transaction between Min and Max amounts is allowed',
        ],
        '1272' => [
            'message' => 'MinAmount',
            'description' => 'The minimum amount allowed to be authorised',
        ],
        '1273' => [
            'message' => 'MaxAmount',
            'description' => 'The maximum amount allowed to be authorised',
        ],
        '1274' => [
            'message' => 'MerchantCategoryCode',
            'description' => 'Exact Merchant Category Code of the merchant who will process the transaction',
        ],
        '1275' => [
            'message' => 'MerchantCategoryName',
            'description' => 'The general category the merchant who will process the transaction belongs to, from a predefined list',
        ],
        '1276' => [
            'message' => 'Percentage',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1277' => [
            'message' => 'SupportLogId',
            'description' => 'A support log ID that can be quoted to assist in troubleshooting',
        ],
        '1280' => [
            'message' => 'Margin',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1281' => [
            'message' => 'FundingSource',
            'description' => 'Source who should be issued to.',
        ],
        '1282' => [
            'message' => 'QuoteValue',
            'description' => 'A rate from the foreign currency exchange.',
        ],
        '1283' => [
            'message' => 'UserData',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1284' => [
            'message' => 'EnhancedData',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1285' => [
            'message' => 'Layout',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1287' => [
            'message' => 'bdDeviceToken',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1288' => [
            'message' => 'bdEmail',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1289' => [
            'message' => 'bdPhone',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1298' => [
            'message' => 'sdDeviceToken',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1299' => [
            'message' => 'sdPhone',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1300' => [
            'message' => 'CHStreet',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1301' => [
            'message' => 'CHCountryCode',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1302' => [
            'message' => 'CHZipCode',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1303' => [
            'message' => 'CHCity',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1320' => [
            'message' => 'SDFirstName',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1321' => [
            'message' => 'SDLastName',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1322' => [
            'message' => 'SDSalutation',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1323' => [
            'message' => 'SDCompanyOrPerson',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1324' => [
            'message' => 'SDStreet',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1325' => [
            'message' => 'SDHouseNumber/ SDStreetNr',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1326' => [
            'message' => 'SDCountryCode',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1327' => [
            'message' => 'SDZipcode',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1328' => [
            'message' => 'SDCity',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1329' => [
            'message' => 'SDTitle',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1330' => [
            'message' => 'BDFirstName',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1331' => [
            'message' => 'BDLastName',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1332' => [
            'message' => 'BDSalutation',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1333' => [
            'message' => 'BDCompanyOrPerson',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1334' => [
            'message' => 'BDStreet',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1335' => [
            'message' => 'BDHouseNumber/ BDStreetNr',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1336' => [
            'message' => 'BDCountryCode',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1337' => [
            'message' => 'BDZipcode',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1338' => [
            'message' => 'BDCity',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1339' => [
            'message' => 'BDTitle',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1340' => [
            'message' => 'BDStreet2',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1341' => [
            'message' => 'SDStreet2',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1342' => [
            'message' => 'SDPhone',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1343' => [
            'message' => 'SDMobileNo',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1344' => [
            'message' => 'SDCompany',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1345' => [
            'message' => 'HolderName',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1346' => [
            'message' => 'TaxNumber',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1347' => [
            'message' => 'BDCompany',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1348' => [
            'message' => 'ShopSystem',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1349' => [
            'message' => 'ShopSystemVersion',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1350' => [
            'message' => 'CARDNUMBER / EXPIRY MISMATCH',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1351' => [
            'message' => 'CARDNUMBER / BIRTHDATE MISMATCH',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1352' => [
            'message' => 'NOT OF LEGAL AGE',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1353' => [
            'message' => 'BIRTHDATE',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1354' => [
            'message' => 'CARDHOLDER',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1355' => [
            'message' => 'Check Transaction Id',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1356' => [
            'message' => 'RISKLEVEL OF CARD TOO HIGH',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1357' => [
            'message' => 'BuyerIDCode',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1358' => [
            'message' => 'ShippingData',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1359' => [
            'message' => 'bdMobileNo',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1360' => [
            'message' => 'KlarnaAction',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1361' => [
            'message' => 'AnnualSalary',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1362' => [
            'message' => 'SocialSecurityNumber',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1363' => [
            'message' => 'Email',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1364' => [
            'message' => 'Phone',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1365' => [
            'message' => 'Language',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1366' => [
            'message' => 'Country',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1367' => [
            'message' => 'Customer not active',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1368' => [
            'message' => 'Customer unknown',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1369' => [
            'message' => 'Customer not allowed',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1370' => [
            'message' => 'Invalid Adress Data',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1371' => [
            'message' => 'Invoice Problem',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1372' => [
            'message' => 'ReservationNr',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1373' => [
            'message' => 'InvoiceNr',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1374' => [
            'message' => 'Klarna System Error',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1375' => [
            'message' => 'InvoiceFlag',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1376' => [
            'message' => 'Reference',
            'description' => 'The parameter in column B caused a problem.',
        ],
        '1377' => [
            'message' => 'OrderID1',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1378' => [
            'message' => 'OrderID2',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1379' => [
            'message' => 'CredNo',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1380' => [
            'message' => 'NO DECISION RECEIVED',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1381' => [
            'message' => 'CUSTOMER INSECURE',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1382' => [
            'message' => 'DATEOFBIRTH',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1383' => [
            'message' => 'DATEOFREGISTRATION',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1384' => [
            'message' => 'OrderID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1385' => [
            'message' => 'shAmount',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1386' => [
            'message' => 'PayType',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1387' => [
            'message' => 'Note',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1388' => [
            'message' => 'SubID',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1389' => [
            'message' => 'GoodsCategory',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1390' => [
            'message' => 'Nationality',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1391' => [
            'message' => 'AllowMarketing',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1392' => [
            'message' => 'AllowCredInq',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1393' => [
            'message' => 'ShoppingBasket',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1394' => [
            'message' => 'RPMethod',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1395' => [
            'message' => 'RPNumber',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1396' => [
            'message' => 'RPAmount',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1397' => [
            'message' => 'MaxRisk',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1398' => [
            'message' => 'CustomerClassification',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1399' => [
            'message' => 'RISK MANAGEMENT SYSTEM',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1400' => [
            'message' => 'OptionDate',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1401' => [
            'message' => 'OutputType',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1402' => [
            'message' => 'TrackingId',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1403' => [
            'message' => 'ParcelService',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1404' => [
            'message' => 'PackstationID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1405' => [
            'message' => 'NumberOfDays',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1406' => [
            'message' => 'Postponed',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1407' => [
            'message' => 'TermsAndCondition',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1408' => [
            'message' => 'BcolumnserSessionId',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1409' => [
            'message' => 'CookieId',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1410' => [
            'message' => 'BcolumnserHeader',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1411' => [
            'message' => 'MandateProvided',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1412' => [
            'message' => 'DeviceID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1413' => [
            'message' => 'CheckoutDuration',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1414' => [
            'message' => 'ShoppingDuration',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1415' => [
            'message' => 'TripData',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1416' => [
            'message' => 'TravelerList',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1417' => [
            'message' => 'AuthResult',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1418' => [
            'message' => 'CAVV',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1419' => [
            'message' => 'ACSID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1420' => [
            'message' => 'ACSIDHex',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1421' => [
            'message' => 'XID3DHEX',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1422' => [
            'message' => 'ECI3D',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1423' => [
            'message' => 'ShopApiKey',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1424' => [
            'message' => 'Transaction stopped',
            'description' => 'An invalid value for AlphaAuthResult of VEReq has been submitted.',
        ],
        '1430' => [
            'message' => 'INCREMENT NOT ALLOWED',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1431' => [
            'message' => 'transId MISMATCH',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1434' => [
            'message' => 'NOTHING AUTHORIZED',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1450' => [
            'message' => 'Language',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1451' => [
            'message' => 'CustomerID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1452' => [
            'message' => 'NewCustomer',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1453' => [
            'message' => 'BillPayAction',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1454' => [
            'message' => 'GtcValue',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1455' => [
            'message' => 'BillPayCapture',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1456' => [
            'message' => 'Phone',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1457' => [
            'message' => 'UseBillingData',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1458' => [
            'message' => 'CompanyName',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1459' => [
            'message' => 'LegalForm',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1460' => [
            'message' => 'OrderHistory',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1461' => [
            'message' => 'BpMethod',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1462' => [
            'message' => 'Error in AddressData',
            'description' => 'The backend system rejected the transaction due to a technical error, details in column B.',
        ],
        '1463' => [
            'message' => 'ActivationDelay',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1464' => [
            'message' => 'BpBaseAmount',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1465' => [
            'message' => 'Billpay System Error',
            'description' => 'The backend system rejected the transaction due to a technical error, details in column B.',
        ],
        '1466' => [
            'message' => 'BpRateCount',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1467' => [
            'message' => 'InstalmentData',
            'description' => 'Billpay: the data for the instalment calculcation caused a problem.',
        ],
        '1468' => [
            'message' => 'sdState',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1469' => [
            'message' => 'sdCompany',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1470' => [
            'message' => 'DistributionType',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1471' => [
            'message' => 'DistributionBy',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1472' => [
            'message' => 'CountryCode',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1473' => [
            'message' => 'CardProgram',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1474' => [
            'message' => 'UsePoints',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1475' => [
            'message' => 'PointAmount',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1476' => [
            'message' => 'Campaign',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1477' => [
            'message' => 'TokenExt',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1478' => [
            'message' => 'InstallmentAmount',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1479' => [
            'message' => 'InstallmentDate',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1480' => [
            'message' => 'UserAgent',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1490' => [
            'message' => 'bdAddressAddition',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1491' => [
            'message' => 'CustomerInformation',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1500' => [
            'message' => 'Invalid Field Data',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1501' => [
            'message' => 'Missing Companion Data',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1502' => [
            'message' => 'Invalid Division Number',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1505' => [
            'message' => 'Level 3 Data invalid',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1506' => [
            'message' => 'Invalid Secure Payment Data',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1507' => [
            'message' => 'Invalid Merchant Category Code',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1510' => [
            'message' => 'Missing customer servicephone',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1513' => [
            'message' => 'Response Invalid',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1514' => [
            'message' => 'Partial Authorization not allowed',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1515' => [
            'message' => 'Duplicate Transaction',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1516' => [
            'message' => 'Invalid CashBack Amount',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1517' => [
            'message' => 'Division transaction amount limit exceeded',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1518' => [
            'message' => 'No card record',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1519' => [
            'message' => 'Already reversed',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1520' => [
            'message' => 'Amount mismatch',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1521' => [
            'message' => 'Excesive PIN Try',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1522' => [
            'message' => 'Exceeds activity count limit',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1523' => [
            'message' => 'Cardholder requested this TRX to be stopped',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1524' => [
            'message' => 'Cardholder requested ALL recurring/installment TRX to be stopped',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1525' => [
            'message' => 'Cardholder requested ALL TRX to be stopped',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1526' => [
            'message' => 'New card issued',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1527' => [
            'message' => 'Issuer flagged account as suspected fraud',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1528' => [
            'message' => 'Institution not valid',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1529' => [
            'message' => 'Issuer does not allow trx-type',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1531' => [
            'message' => 'Unable to validate debit authorization record',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1532' => [
            'message' => 'Unable to process transaction',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1533' => [
            'message' => 'Bank Account has been closed',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1534' => [
            'message' => 'Invalid AMEX CID',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1536' => [
            'message' => 'Account does not exist',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1537' => [
            'message' => 'Declined using stand-in rules',
            'description' => 'The backend system rejected the transaction, details in column B.',
        ],
        '1540' => [
            'message' => 'Surcharge',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1541' => [
            'message' => 'StepUpForced',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1542' => [
            'message' => 'SoftDecline',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1543' => [
            'message' => 'Language',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1600' => [
            'message' => 'telbiz',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1601' => [
            'message' => 'telmobil',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1602' => [
            'message' => 'telpriv',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1603' => [
            'message' => 'sozversnr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1604' => [
            'message' => 'emailadranb',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1605' => [
            'message' => 'emailadrsyn',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1606' => [
            'message' => 'emailadrtld',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1607' => [
            'message' => 'okvip',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1608' => [
            'message' => 'okkndart',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1609' => [
            'message' => 'la1name',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1610' => [
            'message' => 'la1vorname',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1611' => [
            'message' => 'la1strasse',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1612' => [
            'message' => 'la1hno',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1613' => [
            'message' => 'la1ort',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1614' => [
            'message' => 'la1plz',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1615' => [
            'message' => 'la1land',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1616' => [
            'message' => 'la1gebdat',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1617' => [
            'message' => 'kdkndktonr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1618' => [
            'message' => 'kdinkassostand',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1619' => [
            'message' => 'kdktostand',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1620' => [
            'message' => 'kdjemkomplettgezkz',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1621' => [
            'message' => 'kdnochnichtfaellbetr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1622' => [
            'message' => 'kdueberfaellbetr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1623' => [
            'message' => 'kdktostartdat',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1624' => [
            'message' => 'kdktosperrkz',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1625' => [
            'message' => 'kdkndktoart',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1626' => [
            'message' => 'kdkredlin',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1627' => [
            'message' => 'kdmahnstatus',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1628' => [
            'message' => 'kdkredlinauftr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1629' => [
            'message' => 'kdaltkndkz',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1630' => [
            'message' => 'adauftrwert',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1631' => [
            'message' => 'adwaehrung',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1632' => [
            'message' => 'adzahlungsart',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1633' => [
            'message' => 'adsonderartkz',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1634' => [
            'message' => 'adlieferart',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1635' => [
            'message' => 'adanzartikel',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1636' => [
            'message' => 'adauftragsnr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1637' => [
            'message' => 'adratenzahl',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1638' => [
            'message' => 'wgdaten',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1700' => [
            'message' => 'Device',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1701' => [
            'message' => 'KSN',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1702' => [
            'message' => 'TrackEnc',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1703' => [
            'message' => 'Invalid Device',
            'description' => 'The hardware serial number (device) was invalid.',
        ],
        '1704' => [
            'message' => 'POS Decryption failed',
            'description' => 'The track data decryption failed.',
        ],
        '1705' => [
            'message' => 'Trackdata invalid',
            'description' => 'The track data could not be read.',
        ],
        '1710' => [
            'message' => 'prodsigncert',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1711' => [
            'message' => 'terminalcrt',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1712' => [
            'message' => 'tempkeyloadcrt',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1713' => [
            'message' => 'suggestediksn',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1714' => [
            'message' => 'ProductNr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1715' => [
            'message' => 'Localisation',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1716' => [
            'message' => 'Already Performed',
            'description' => 'Action already performed',
        ],
        '1717' => [
            'message' => 'ServiceData',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1750' => [
            'message' => 'EMVData',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1751' => [
            'message' => 'POS Signature failed',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1752' => [
            'message' => 'POSTerminalID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1753' => [
            'message' => 'MessageType',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1754' => [
            'message' => 'DMACKSN',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1755' => [
            'message' => 'DMAC',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1756' => [
            'message' => 'DataKSN',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1757' => [
            'message' => 'CCNrEnc',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1758' => [
            'message' => 'CCSeqNr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1759' => [
            'message' => 'dccStatus',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1760' => [
            'message' => 'LocalDate',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1761' => [
            'message' => 'LocalTime',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1762' => [
            'message' => 'ReceiptNr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1763' => [
            'message' => 'ProcessMode',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1764' => [
            'message' => 'EntryMode',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1765' => [
            'message' => 'TerminalData',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1766' => [
            'message' => 'Track2',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1767' => [
            'message' => 'PIN',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1768' => [
            'message' => 'Message Length Mismatch',
            'description' => 'There is a mismatch between the length of the message and value provided in the header.',
        ],
        '1769' => [
            'message' => 'Endpoint',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1770' => [
            'message' => 'ProcessingCode',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1771' => [
            'message' => 'BankSortCode',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1772' => [
            'message' => 'ConditionCode',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1801' => [
            'message' => 'INVALID PARAM FULFILLMENTDATE',
            'description' => 'Transmitted fulfillment date was invalid or in future.',
        ],
        '1802' => [
            'message' => 'CURRENCY MISMATCH',
            'description' => 'Transmitted currency did not match initial transaction.',
        ],
        '1803' => [
            'message' => 'INVALID PARAMETER TaxChargeAmount',
            'description' => 'Transmitted tax charge amount did not match the specifications.',
        ],
        '1804' => [
            'message' => 'INVALID PARAMETER ChargeAmount',
            'description' => 'Transmitted charge amount did not match the specifications.',
        ],
        '1805' => [
            'message' => 'ARTICLENR INVALID',
            'description' => 'The article referring to the article number could not be found.',
        ],
        '1806' => [
            'message' => 'QUANTITY OVERRIDE',
            'description' => 'The deliver quantity exceeded the authorised quantity.',
        ],
        '1808' => [
            'message' => 'INVALID ORDERID',
            'description' => 'Transmitted order ID was invalid.',
        ],
        '1809' => [
            'message' => 'MISSING PARAM PURCHASECONTRACTID',
            'description' => 'The parameter in column B was missing.',
        ],
        '1810' => [
            'message' => 'INVALID PARAM COUNTRYCODE',
            'description' => 'The parameter in column B was invalid.',
        ],
        '1811' => [
            'message' => 'ServiceLevel in ArticleList ist ungültig',
            'description' => 'Transmitted parameter did not match the specifications.',
        ],
        '1812' => [
            'message' => 'ShippingMethod ungültig',
            'description' => 'Transmitted parameter did not match the specifications.',
        ],
        '1815' => [
            'message' => 'NOTHING TO REVERSE',
            'description' => 'Reverse was not possible, no initial authorising available.',
        ],
        '1818' => [
            'message' => 'order canceled',
            'description' => 'Amazon reported that the order was cancelled.',
        ],
        '1821' => [
            'message' => 'Signature mismatch',
            'description' => 'The signature transmitted by Amazon was invalid.',
        ],
        '1822' => [
            'message' => 'IOPN Message already exists',
            'description' => 'The message transmitted by Amazon was received and processed already.',
        ],
        '1830' => [
            'message' => 'Error while GetPurchaseContract',
            'description' => 'Calling the function "GetPurchaseContract" caused the error.',
        ],
        '1831' => [
            'message' => 'Error while SetPurchaseItems',
            'description' => 'Calling the function "SetPurchaseItems" caused the error.',
        ],
        '1832' => [
            'message' => 'Error while CompletePurchaseContract',
            'description' => 'Calling the function "CompletePurchaseContract" caused the error.',
        ],
        '1833' => [
            'message' => 'PurchaseContract canceled',
            'description' => 'The order was cancelled.',
        ],
        '1834' => [
            'message' => 'PurchaseContract expired',
            'description' => 'The order has expired.',
        ],
        '1835' => [
            'message' => 'AMAZON ALERT',
            'description' => 'Amazon reported an error while processing the payment. The Amazon result code was transmitted additionally.',
        ],
        '1836' => [
            'message' => 'AMAZON ALERT ',
            'description' => 'Amazon reported a warning while processing the payment. It is recommended to check the payment manually. The Amazon result code was transmitted additionally.',
        ],
        '1837' => [
            'message' => 'Error while SetContractCharges',
            'description' => 'Calling the funktion "SetContractCharges" caused the error.',
        ],
        '1850' => [
            'message' => 'ProductName',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1851' => [
            'message' => 'RequestReason',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1852' => [
            'message' => 'Title',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1853' => [
            'message' => 'BaseAmount',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1854' => [
            'message' => 'BaseCurrency',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1855' => [
            'message' => 'Recipient',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1856' => [
            'message' => 'QuoteId',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1857' => [
            'message' => 'LocalAmount',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1858' => [
            'message' => 'LocalCurrency',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1859' => [
            'message' => 're-enter transaction',
            'description' => 'The transaction has already been processed',
        ],
        '1860' => [
            'message' => 'InstallmentNumber',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1861' => [
            'message' => 'Expiration',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1862' => [
            'message' => 'AccType',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1863' => [
            'message' => 'AcceptableCards',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1864' => [
            'message' => 'RewardProgram',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1865' => [
            'message' => 'AuthLevelBasic',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1866' => [
            'message' => 'MasterPassID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1867' => [
            'message' => 'transId',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1868' => [
            'message' => 'Already Authorized',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1869' => [
            'message' => 'SuppressShippingAddress',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1870' => [
            'message' => 'URLOrigin',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1871' => [
            'message' => 'LongAccessToken',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1872' => [
            'message' => 'PairingToken',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1873' => [
            'message' => 'PairingVerifier',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1874' => [
            'message' => 'RequestedDataTypes',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1875' => [
            'message' => 'CheckoutToken',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1876' => [
            'message' => 'CheckoutVerifier',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1877' => [
            'message' => 'CheckoutUrl',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1880' => [
            'message' => 'Error while generate EID',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1881' => [
            'message' => 'InvoiceText',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1882' => [
            'message' => 'TrxIdCount',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1883' => [
            'message' => 'addata1',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1884' => [
            'message' => 'insufficient funds',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1885' => [
            'message' => 'Consent',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1886' => [
            'message' => 'PurchaseCountryCode',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1887' => [
            'message' => 'URLCheckout',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1888' => [
            'message' => 'URLConfirm',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1889' => [
            'message' => 'URLTerms',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1900' => [
            'message' => 'Mandateid',
            'description' => 'Mandate could not be created.',
        ],
        '1901' => [
            'message' => 'MandateName',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1902' => [
            'message' => 'Debit Parameter',
            'description' => 'None of the necessary parameters was submitted.',
        ],
        '1903' => [
            'message' => 'Designated Date incorrect',
            'description' => 'The payment cannot be executed at the requested appointment.',
        ],
        '1904' => [
            'message' => 'DebitorID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1905' => [
            'message' => 'TaxID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1906' => [
            'message' => 'ShopId',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1907' => [
            'message' => 'InvoiceDate',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1908' => [
            'message' => 'NetAmount',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1909' => [
            'message' => 'NetAmount1',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1910' => [
            'message' => 'TaxCode1',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1911' => [
            'message' => 'TaxAmount1',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1912' => [
            'message' => 'NetAmount2',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1913' => [
            'message' => 'TaxCode2',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1914' => [
            'message' => 'TaxAmount2',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1915' => [
            'message' => 'NetAmount3',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1916' => [
            'message' => 'TaxCode3',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1917' => [
            'message' => 'TaxAmount3',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1918' => [
            'message' => 'ShoppingBasketID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1919' => [
            'message' => 'CreationDate',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1920' => [
            'message' => 'DueDate',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1921' => [
            'message' => 'FSK',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1922' => [
            'message' => 'custgroup',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1923' => [
            'message' => 'VatID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1924' => [
            'message' => 'BenefitPeriodFrom',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1925' => [
            'message' => 'BenefitPeriodTill',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1926' => [
            'message' => 'Doctitle',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1927' => [
            'message' => 'AccountId',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1928' => [
            'message' => 'DeliveryChannel',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1929' => [
            'message' => 'AmountClass',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1930' => [
            'message' => 'DtOfSgntr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1931' => [
            'message' => 'MandateID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1932' => [
            'message' => 'MdtSeqType',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1933' => [
            'message' => 'AccVerify',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1934' => [
            'message' => 'FSChannelID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1935' => [
            'message' => 'FSServiceID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1936' => [
            'message' => 'MiddleName',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1937' => [
            'message' => 'AddressAddition',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1938' => [
            'message' => 'WorkPhone',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1939' => [
            'message' => 'sdMiddleName',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1940' => [
            'message' => 'sdAddressAddition',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1941' => [
            'message' => 'sdWorkPhone',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1942' => [
            'message' => 'sdEMail',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1943' => [
            'message' => 'Invalid Request',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1944' => [
            'message' => 'AccessToken',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1945' => [
            'message' => 'OrderReferenceId',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1946' => [
            'message' => 'transId',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1947' => [
            'message' => 'Expiry',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1948' => [
            'message' => 'Scope',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1949' => [
            'message' => 'Invalid Payment Method',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1950' => [
            'message' => 'Order has not been confirmed',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1951' => [
            'message' => 'Order Expired',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1952' => [
            'message' => 'Max Authorizations Captured',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1953' => [
            'message' => 'Closed',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1954' => [
            'message' => 'Rejected',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1955' => [
            'message' => 'Authorization Expired',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1956' => [
            'message' => 'Max Refunds Processed',
            'description' => 'Transaction failed, details in column B.',
        ],
        '1957' => [
            'message' => 'TokenType',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '1990' => [
            'message' => 'URLBack',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '2000' => [
            'message' => 'FRAUD SCREENING ERROR',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2001' => [
            'message' => 'DECLINED BY FRAUD SCREENING',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2002' => [
            'message' => 'FRAUD SCREENING NO RESPONSE',
            'description' => 'Backend system (e.g. acquiring, card schemes or payment schemes API) was not responding.',
        ],
        '2003' => [
            'message' => 'Internal Error: Unable to handle message type at this time',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2004' => [
            'message' => 'Message Request Format Exception',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2005' => [
            'message' => 'Internal Error: Message Response Format Exception',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2006' => [
            'message' => 'Unsupported Message Version',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2007' => [
            'message' => 'Message Group Disabled',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2008' => [
            'message' => 'System Unavailable for Maintenance',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2009' => [
            'message' => 'Invalid Request Format: Invalid XML',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2010' => [
            'message' => 'Invalid Request Format: Empty Request',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2020' => [
            'message' => 'Invalid Transaction Password',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2021' => [
            'message' => 'Merchant Profile is not configured with a Transaction Password',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2030' => [
            'message' => 'Unable to process transaction with specified api version',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2101' => [
            'message' => 'TransDate',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2102' => [
            'message' => 'TransTime',
            'description' => 'Transaction failed, details in column B.',
        ],
        '2201' => [
            'message' => 'MpsMode',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '2202' => [
            'message' => 'Call Security',
            'description' => 'Issuer refused payment, please call the security',
        ],
        '2203' => [
            'message' => 'RegistrationDevice',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '2204' => [
            'message' => 'RegistrationIPAddr',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '2206' => [
            'message' => 'Timeout',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '2306' => [
            'message' => 'Cut-off in progress',
            'description' => 'Cut-off in progress',
        ],
        '2321' => [
            'message' => 'Exceeds withdrawal amount limit',
            'description' => 'Exceeds withdrawal amount limit',
        ],
        '2323' => [
            'message' => 'Exceeds withdrawal frequency limit',
            'description' => 'Exceeds withdrawal frequency limit',
        ],
        '2381' => [
            'message' => 'Card blocked',
            'description' => 'Card blocked',
        ],
        '2382' => [
            'message' => 'Account blocked',
            'description' => 'Account blocked',
        ],
        '4000' => [
            'message' => 'Error Validating Processor Id Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4010' => [
            'message' => 'Error Validating Acquirer Bin Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4020' => [
            'message' => 'Error Validating Merchant Id Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4025' => [
            'message' => 'Error Validating Transaction Type',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4030' => [
            'message' => 'Error Validating PAN Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4040' => [
            'message' => 'Error Validating 3-D Secure Version Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4050' => [
            'message' => 'Error Validating Merchant Password',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4070' => [
            'message' => 'Error Validating Merchant Name',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4080' => [
            'message' => 'Error Validating Merchant URL',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4090' => [
            'message' => 'Error Validating Credit Card Expiration Information',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4092' => [
            'message' => 'Error Validating Card Number Month Expiration Information',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4093' => [
            'message' => 'Error Validating Card Number Year Expiration Information',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4094' => [
            'message' => 'Error Validating Card Number',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4140' => [
            'message' => 'Error Validating ACS URL',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4150' => [
            'message' => 'Error Validating Payment Protocol',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4160' => [
            'message' => 'Error Validating Purchase.date',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4170' => [
            'message' => 'Error Validating Purchase.xid',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4180' => [
            'message' => 'Error Validating Purchase.purchAmount',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4190' => [
            'message' => 'Error Validating Purchase Amount',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4200' => [
            'message' => 'Error Validating Purchase Description',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4220' => [
            'message' => 'Merchant Not Configured to process the Credit Card Brand passed',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4230' => [
            'message' => 'Required Element Brand, not found in Message',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4240' => [
            'message' => 'Merchant unable to process transactions, not active',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4243' => [
            'message' => 'Merchant unable to process transactions, Payment Initiative configuration not found',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4245' => [
            'message' => 'Merchant unable to process transactions, Payment Initiative not active',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4250' => [
            'message' => 'Error Validating Processor Id',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4260' => [
            'message' => 'Error Validating Order Number',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4265' => [
            'message' => 'Error Validating Transaction Id',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4267' => [
            'message' => 'Error Validating Message, Order Number is Empty',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4268' => [
            'message' => 'Error Validating Message, Transaction Id is Empty',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4270' => [
            'message' => 'Error Validating Raw Amount',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4271' => [
            'message' => 'Error Validating Transaction Amount',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4280' => [
            'message' => 'Error Validating Currency Code',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4282' => [
            'message' => 'Error Validating Currency Code, Not Supported On Transaction Type',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4310' => [
            'message' => 'Error parsing VERes Message Elements',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4320' => [
            'message' => 'Invalid Critical Attribute in undefined element',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4330' => [
            'message' => 'Error Validating Enrollment Response',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4331' => [
            'message' => 'Error Validating Authentication Status',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4340' => [
            'message' => 'Error Validating iReq Code',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4350' => [
            'message' => 'Error Validating Message Extension',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4360' => [
            'message' => 'Error Validating Critical Message Extensions',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4370' => [
            'message' => 'Error Validating MsgId Within VEReq and VERes Messages',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4375' => [
            'message' => 'Error Validating Recurring Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4380' => [
            'message' => 'Error Validating Recurring Frequency Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4390' => [
            'message' => 'Error Validating Recurring Frequency End Date',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4400' => [
            'message' => 'Error Parsing PARes Message Elements',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4410' => [
            'message' => 'Error Validating Vendor Code',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4420' => [
            'message' => 'Error Validating PAN Value, Should Not Contain Zeros',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4430' => [
            'message' => 'Error Validating TX.cavv Value, Should Not Be Present',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4435' => [
            'message' => 'Error Validating TX.cavv Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4440' => [
            'message' => 'Error Validating TX.eci Value, Should Not Be Present',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4445' => [
            'message' => 'Error Validating TX.eci Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4450' => [
            'message' => 'Error Validating TX.cavvAlgorithm Value, Should Not Be Present',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4455' => [
            'message' => 'Error Validating TX.cavvAlgorithm Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4460' => [
            'message' => 'Error Validating Message Id',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4470' => [
            'message' => 'Error Validating (MsgId, Xid, Purchase.currency, Purchase.exponent, Purchase.purchAmount) Within PAReq and PARes Messages',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4480' => [
            'message' => 'Error Validating PARes Id',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4490' => [
            'message' => 'Error Validating ISO Currency Code',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4500' => [
            'message' => 'Error Validating ISO Currency Exponent',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4510' => [
            'message' => 'Error Validating TX.time',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4520' => [
            'message' => 'Error Validating Installment Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4530' => [
            'message' => 'Error Validating Installment Value, Must Be Greater Than 1',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4531' => [
            'message' => 'Error Validating Payment Type value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4535' => [
            'message' => 'Error Validating IPAddress Value, Must Be Formatted',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4536' => [
            'message' => 'Error Validating ISO 3166 Country Code',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4537' => [
            'message' => 'Error Validating transId value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4540' => [
            'message' => 'Error Validating PARes Id and Reference URI',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4550' => [
            'message' => 'Error Validating PARes, Invalid Message.Signature.CanonicalizationMethod xmlns Attribute',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4560' => [
            'message' => 'Error Validating PARes, Invalid Message.Signature.SignatureMethod xmlns attribute',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4570' => [
            'message' => 'Error Validating PARes, Invalid Message.Signature.SignedInfo xmlns attribute',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4580' => [
            'message' => 'Error Validating PARes, Invalid Message.Signature xmlns attribute',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4590' => [
            'message' => 'Error Validating PARes, Invalid Digital Signature Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4591' => [
            'message' => 'Signature verification failed',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4600' => [
            'message' => 'Error Validating PARes, Invalid Message.Signature.CanonicalizationMethod Algorithm Attribute',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4610' => [
            'message' => 'Error Validating MsgId Within CRReq and CRRes Messages',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4620' => [
            'message' => 'Error Validating MsgId Within CRRes Messages',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4630' => [
            'message' => 'Error Validating CRRes Message, Message Not Found',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4640' => [
            'message' => 'Error Validating CRRes Message Elements',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4650' => [
            'message' => 'Error Validating CRRes, Invalid Card Start Range Values',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4660' => [
            'message' => 'Error Validating CRRes, Invalid Card End Range Values',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4670' => [
            'message' => 'Error Validating CRRes, Invalid Card Range Actions',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4680' => [
            'message' => 'Error Validating CRRes, Invalid Serial Number',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4685' => [
            'message' => 'Error Validating CRRes, Serial Number Not Found',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4690' => [
            'message' => 'Encountered and within CRRes, no action taken on the Card Range Cache',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4700' => [
            'message' => 'Error Validating CRRes, Version Element Not Found',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4710' => [
            'message' => 'Error Validating CRRes, Message Id Element Not Found',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4720' => [
            'message' => 'Error Validating CRRes, ThreeDSecure Element Not Found',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4761' => [
            'message' => 'Error Validating TermURL',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4762' => [
            'message' => 'Error Validating Payload',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4770' => [
            'message' => 'Error Validating AAV Control byte',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4780' => [
            'message' => 'Error Validating AAV Sale Amount',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4790' => [
            'message' => 'Error Validating AAV Sale Amount Truncation Value',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4800' => [
            'message' => 'Error Validating AAV Transaction Currency Code',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4810' => [
            'message' => 'Error Validating Merchant Name Hash',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4820' => [
            'message' => 'Error Validating Merchant Transaction Stampq',
            'description' => 'Transaction failed, details in column B.',
        ],
        '4910' => [
            'message' => 'Authentication Data Not Available',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9000' => [
            'message' => 'Unable to communicate with MAPS Server',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9010' => [
            'message' => 'Error parsing XML Response',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9020' => [
            'message' => 'The server name or address could not be resolved',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9030' => [
            'message' => 'The URL does not use a recognized protocol',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9040' => [
            'message' => 'HTTP(S) Request Timed Out or Invalid Timeout Specified',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9100' => [
            'message' => 'Error Processing CRReq',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9101' => [
            'message' => 'Error Processing Message Request',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9102' => [
            'message' => 'Error Processing Lookup Request Message',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9103' => [
            'message' => 'Error Processing Authenticate Request Message',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9110' => [
            'message' => 'Unsupported PAReq Version requested by ACS',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9130' => [
            'message' => 'Current Processing Mode Does Not Support Specified Message Type',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9131' => [
            'message' => 'System Message Does Not Support Specified Message Version',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9135' => [
            'message' => 'Check Order Number',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9137' => [
            'message' => 'Payment Initiative and Message Type Mismatch',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9138' => [
            'message' => 'Payment Initiative Not Supported Under Specified Message Version',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9139' => [
            'message' => 'Card Type and Message Type Mismatch',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9140' => [
            'message' => 'Message Version Not Supported',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9141' => [
            'message' => 'General Authenticate Message Error',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9160' => [
            'message' => 'Payment Initiative Not Supported',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9161' => [
            'message' => 'Payment Initiative Supported, But Not Enabled',
            'description' => 'Transaction failed, details in column B.',
        ],
        '9201' => [
            'message' => 'Unsupported Message Type',
            'description' => 'Transaction failed, details in column B.',
        ],
        '002A' => [
            'message' => 'Lastname/ Name',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '002B' => [
            'message' => 'AddrStreetNr/ HNo',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '002C' => [
            'message' => 'EMail',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '002D' => [
            'message' => 'TaxAmount',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '002E' => [
            'message' => 'ArticleList',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '002F' => [
            'message' => 'INVALID PARAM PROMOTION',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '003A' => [
            'message' => 'AddrStreet/ Straße',
            'description' => 'One of the parameters in column B caused a problem.',
        ],
        '003B' => [
            'message' => 'AddrZip/ PLZ',
            'description' => 'One of the parameters in column B caused a problem.',
        ],
        '003C' => [
            'message' => 'AddrCity/ Ort',
            'description' => 'One of the parameters in column B caused a problem.',
        ],
        '003D' => [
            'message' => 'Invalid IP adress',
            'description' => 'The IP address was invalid.',
        ],
        '003E' => [
            'message' => 'RequestID',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '003F' => [
            'message' => 'amount3d',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '004A' => [
            'message' => 'BIC NOT LISTED',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '004B' => [
            'message' => 'BANKCODE IBAN MISMATCH',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '011A' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the IP-Checks within Securepay (max. number per day).',
        ],
        '011B' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the Card-Checks within Securepay (max. number per day).',
        ],
        '011C' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the amount check combined with IP-checks within Securepay (max. number per day).',
        ],
        '011D' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the amount check combined with IP-checks within Securepay (max. number per day).',
        ],
        '011E' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the parameter checks (identical reference number and/or transId) within Securepay (limit per day).',
        ],
        '011F' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the card/IP check within Securepay (limit per day).',
        ],
        '011G' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the  DeviceID-Check within Securepay (limit per day).',
        ],
        '011H' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the  DeviceID/Card-Check within Securepay (limit per day).',
        ],
        '011I' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the  DeviceID/IP-Check within Securepay (limit per day).',
        ],
        '012A' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the IP check within Securepay (maximum number per week).',
        ],
        '012B' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the card check within Securepay (maximum number per week).',
        ],
        '012C' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the amount check combined with IP-check within Securepay (maximum number per week).',
        ],
        '012D' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the amount check combined with card-check within Securepay (limit per week).',
        ],
        '012E' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the parameter check (identical reference number and/or transId) within Securepay (limit per week).',
        ],
        '012F' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the card/IP-check within Securepay (limit per week).',
        ],
        '012G' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the  DeviceID-Check within Securepay (limit per week).',
        ],
        '012H' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the  DeviceID/Card-Check within Securepay (limit per week).',
        ],
        '012I' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the  DeviceID/IP-Check within Securepay (limit per week).',
        ],
        '013A' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the IP-check within Securepay (limit per month).',
        ],
        '013B' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the card check within Securepay (limit per month).',
        ],
        '013C' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the amount check combined with the IP-check within Securepay (limit per month).',
        ],
        '013D' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the amount check combined with the card-check within Securepay (limit per month).',
        ],
        '013E' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the parameter check (identical reference number and/or transId) within Securepay (limit per month).',
        ],
        '013F' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the card/IP-check within Securepay (limit per month).',
        ],
        '013G' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the  DeviceID-Check within Securepay (limit per month).',
        ],
        '013H' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the  DeviceID/Card-Check within Securepay (limit per month).',
        ],
        '013I' => [
            'message' => 'DECLINED BY FRAUD',
            'description' => 'Payment rejected due to the settings of the  DeviceID/IP-Check within Securepay (limit per month).',
        ],
        '014A' => [
            'message' => 'DECLINED BY SECUREPAY',
            'description' => 'Payment rejected as the IP-address is blocked temporarily due to the settings within Securepay. You can unblock the IP-address viathe Securepay settings in Analytics.',
        ],
        '014B' => [
            'message' => 'DECLINED BY SECUREPAY',
            'description' => 'Payment rejected as the card number is blocked temporarily due to the settings within Securepay. You can unblock the card within the Securepay settings in Analytics.',
        ],
        '014C' => [
            'message' => 'DECLINED BY SECUREPAY',
            'description' => 'Payment rejected as the IP-address is blocked temporarily due to the settings within Securepay (amount limit exceeded). You can unblock the IP-address within the Securepay settings in Analytics.',
        ],
        '014D' => [
            'message' => 'DECLINED BY SECUREPAY',
            'description' => 'Payment rejected as the card is blocked temporarily due to the settings within Securepay (amount limit exceeded). You can unblock the card within the Securepay settings in Analytics.',
        ],
        '014E' => [
            'message' => 'DECLINED BY SECUREPAY',
            'description' => 'Payment rejected as the parameter value is blocked temporarily due to the settings within Securepay (limit exceeded). You can unblock the parameter value within the Securepay settings in Analytics.',
        ],
        '014F' => [
            'message' => 'DECLINED BY SECUREPAY',
            'description' => 'Payment rejected as the IP address is blocked temporarily due to the settings within Securepay (limit of cards from identical IP-address exceeded). You can unblock the IP-address within the Securepay settings in Analytics.',
        ],
        '014G' => [
            'message' => 'DECLINED BY SECUREPAY',
            'description' => 'Payment rejected due to the settings of the  DeviceID-Check within Securepay.',
        ],
        '014H' => [
            'message' => 'DECLINED BY SECUREPAY',
            'description' => 'Payment rejected due to the settings of the  DeviceID/Card-Check within Securepay.',
        ],
        '014I' => [
            'message' => 'DECLINED BY SECUREPAY',
            'description' => 'Payment rejected due to the settings of the  DeviceID/IP-Check within Securepay.',
        ],
        '020A' => [
            'message' => 'BYPASSED',
            'description' => 'Authenticate was skipped upon Cardinal Commerce recommendation',
        ],
        '040A' => [
            'message' => 'System error',
            'description' => 'Charging was blocked. Credit card was not charged.',
        ],
        '040B' => [
            'message' => 'Internal authorization system error',
            'description' => 'Charging was blocked. Credit card was not charged.',
        ],
        '110A' => [
            'message' => 'Timeout generated by user',
            'description' => 'Transaction failed, details in column B.',
        ],
        '110B' => [
            'message' => 'Unknown function',
            'description' => 'Transaction failed, details in column B.',
        ],
        '110C' => [
            'message' => 'Card not activated',
            'description' => 'Transaction failed, details in column B.',
        ],
        '110D ' => [
            'message' => 'Card not accepted',
            'description' => 'Transaction failed, details in column B.',
        ],
        '110E' => [
            'message' => 'Commando erraneous',
            'description' => 'Transaction failed, details in column B.',
        ],
        '139A' => [
            'message' => 'InterestRate',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '139B' => [
            'message' => 'DebitPayType',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '139C' => [
            'message' => 'ShoppingBasketAmount',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '139D' => [
            'message' => 'Calculation Error',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '139E' => [
            'message' => 'Rate',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '139F' => [
            'message' => 'Month',
            'description' => 'The Parameter in column B caused a problem.',
        ],
        '139G' => [
            'message' => 'Token Expired',
            'description' => 'Transaction failed, details in column B.',
        ],
    ],
];
