<?php

return [
    'states' => [
        '0' => [
            'message' => 'OK',
            'description' => 'Transaction réussie. Le code d\'action peut contenir des informations.',
        ],
        '2' => [
            'message' => 'Erreur',
            'description' => 'Transaction échouée',
        ],
        '4' => [
            'message' => 'Fatale',
            'description' => 'La transaction a échoué en raison d\'une erreur qui pourrait également affecter les transactions suivantes.',
        ],
        '6' => [
            'message' => 'Continuer',
            'description' => 'Le traitement de la transaction n\'est pas encore terminé : à la fin du traitement, le Paygate enverra un message de notification contenant le statut final.',
        ],
        '7' => [
            'message' => 'EMV',
            'description' => 'États intermédiaires dans la séquence EMV 3Ds',
        ],
    ],
    'modules' => [
        '000' => [
            'message' => '',
            'description' => '',
        ],
        '001' => [
            'message' => 'Crypto (Décryptage, Cryptage)',
            'description' => 'Un problème de cryptage ou de décryptage est survenu.',
        ],
        '010' => [
            'message' => 'Paramètre manquant',
            'description' => 'Un paramètre obligatoire manquait.',
        ],
        '011' => [
            'message' => 'Erreur de format de paramètre',
            'description' => 'Un paramètre contenait une valeur mal formatée.',
        ],
        '012' => [
            'message' => 'Valeur de paramètre invalide',
            'description' => 'Un paramètre contenait une valeur invalide.',
        ],
        '013' => [
            'message' => 'Paramètre trop court',
            'description' => 'Un paramètre contenait une valeur trop courte.',
        ],
        '014' => [
            'message' => 'Paramètre trop long',
            'description' => 'Un paramètre contenait une valeur trop longue.',
        ],
        '015' => [
            'message' => 'Valeur de paramètre manquante',
            'description' => 'Un paramètre obligatoire ne contenait aucune valeur.',
        ],
        '016' => [
            'message' => 'Valeur de paramètre inconnue',
            'description' => 'Un paramètre obligatoire contenait une valeur inconnue.',
        ],
        '017' => [
            'message' => 'Paramètre déjà existant',
            'description' => 'Un paramètre contenait une valeur déjà utilisée.',
        ],
        '018' => [
            'message' => 'Valeur de paramètre expirée',
            'description' => 'Un paramètre contenait une valeur expirée.',
        ],
        '030' => [
            'message' => 'Base de données',
            'description' => 'La requête de la base de données a causé un problème.',
        ],
        '040' => [
            'message' => 'Verrouillage',
            'description' => 'Le verrouillage de l\'ID terminal, nécessaire pour le traitement d\'un paiement, n\'a pas été possible.',
        ],
        '050' => [
            'message' => 'Marchand',
            'description' => 'La configuration au sein du PayGate a causé une erreur.',
        ],
        '060' => [
            'message' => 'Paiement',
            'description' => 'Le paiement n\'a pas pu être traité.',
        ],
        '100' => [
            'message' => 'Traitement de carte de crédit',
            'description' => 'Le traitement de la carte de crédit a causé un problème.',
        ],
        '101' => [
            'message' => 'Traitement fallback et Paygate International',
            'description' => 'Le traitement d\'une transaction fallback ou de schémas domestiques a causé un problème.',
        ],
        '103' => [
            'message' => 'Traitement VbV/MCSC',
            'description' => 'Le traitement d\'une transaction Verified by Visa ou MasterCard SecureCode a causé un problème.',
        ],
        '105' => [
            'message' => 'Traitement de carte de crédit',
            'description' => 'Le traitement de la carte de crédit a causé un problème.',
        ],
        '106' => [
            'message' => 'Traitement de carte de crédit',
            'description' => 'Le traitement de la carte de crédit a causé un problème.',
        ],
        '107' => [
            'message' => 'Traitement de carte de crédit et de débit',
            'description' => 'Le traitement d\'une transaction Dankort a causé un problème.',
        ],
        '108' => [
            'message' => 'Traitement de carte de crédit et de débit',
            'description' => 'Le traitement d\'une transaction via CIAL/CIC a causé un problème.',
        ],
        '109' => [
            'message' => 'Traitement de carte de crédit et de débit',
            'description' => 'Le traitement d\'une transaction via Deutsche Card Services a causé un problème.',
        ],
        '110' => [
            'message' => 'EDD général',
            'description' => 'Le traitement des débits directs électroniques a causé un problème.',
        ],
        '111' => [
            'message' => 'EDd',
            'description' => 'Le traitement des débits directs électroniques allemands a causé un problème.',
        ],
        '112' => [
            'message' => 'EDd',
            'description' => 'Le traitement des débits directs électroniques a causé un problème.',
        ],
        '113' => [
            'message' => 'Liste noire EDd',
            'description' => 'Les débits directs électroniques contre la liste noire ont causé un problème.',
        ],
        '114' => [
            'message' => 'Bitnet',
            'description' => 'Le traitement d\'une transaction Bitnet a causé un problème.',
        ],
        '115' => [
            'message' => 'iDEAl',
            'description' => 'Le traitement d\'une transaction iDEAL a causé un problème.',
        ],
        '116' => [
            'message' => 'giropay',
            'description' => 'Le traitement d\'une transaction giropay a causé un problème.',
        ],
        '117' => [
            'message' => 'EDd',
            'description' => 'Le traitement d\'un paiement par prélèvement automatique via EVO a causé un problème.',
        ],
        '118' => [
            'message' => 'Traitement de carte de crédit et de débit',
            'description' => 'Le traitement de la carte de crédit via Wirecard a causé un problème.',
        ],
        '119' => [
            'message' => 'Alipay',
            'description' => 'Le traitement d\'une transaction Alipay a causé un problème.',
        ],
        '120' => [
            'message' => '3DSecure général',
            'description' => 'L\'authentification via Verified by Visa ou MasterCard SecureCode a causé un problème.',
        ],
        '121' => [
            'message' => 'Traitement de carte de crédit et de débit',
            'description' => 'Le traitement de la carte de crédit via Elavon US a causé un problème.',
        ],
        '122' => [
            'message' => 'SmartDebit',
            'description' => 'Le traitement des prélèvements automatiques via SmartDebit a causé un problème.',
        ],
        '123' => [
            'message' => 'Payolution',
            'description' => 'Le traitement d\'une transaction Payolution a causé un problème.',
        ],
        '125' => [
            'message' => 'easyCredit',
            'description' => 'Le traitement d\'une transaction easyCredit a causé un problème.',
        ],
        '126' => [
            'message' => 'BNPP',
            'description' => 'Le traitement d\'une transaction BNPP a causé un problème.',
        ],
        '130' => [
            'message' => 'CashTicket',
            'description' => 'Le traitement via CashTicket a causé un problème.',
        ],
        '131' => [
            'message' => 'PSC',
            'description' => 'Le traitement via Paysafecard a causé un problème.',
        ],
        '132' => [
            'message' => 'FashionCheque',
            'description' => 'Le traitement d\'une transaction FashionCheque a causé un problème.',
        ],
        '135' => [
            'message' => 'PPRO Ukash',
            'description' => 'Le traitement d\'une transaction Ukash via PPRO a causé un problème.',
        ],
        '136' => [
            'message' => 'PPRO SEPA',
            'description' => 'Le traitement d\'une transaction SEPA via PPRO a causé un problème.',
        ],
        '137' => [
            'message' => 'PPRO CIMB Clicks',
            'description' => 'Le traitement d\'une transaction CIMB Clicks via PPRO a causé un problème.',
        ],
        '140' => [
            'message' => 'Banque (général)',
            'description' => 'Le traitement bancaire a causé un problème.',
        ],
        '141' => [
            'message' => 'Banque',
            'description' => 'Le traitement de la transaction bancaire via Barclays a causé un problème.',
        ],
        '142' => [
            'message' => 'Banque',
            'description' => 'Le traitement de la transaction bancaire via the Royal Bank of Scotland a causé un problème.',
        ],
        '150' => [
            'message' => 'Paiement SEPA direct',
            'description' => 'Le traitement d\'une transaction SEPA direct a causé un problème.',
        ],
        '151' => [
            'message' => 'SOFORT',
            'description' => 'Le traitement d\'une transaction SOFORT a causé un problème.',
        ],
        '152' => [
            'message' => 'Prélèvement SEPA direct',
            'description' => 'Le traitement d\'un prélèvement SEPA direct a causé un problème.',
        ],
        '153' => [
            'message' => 'Klarna',
            'description' => 'Le traitement d\'une transaction Klarna a causé un problème.',
        ],
        '160' => [
            'message' => 'Bancontact',
            'description' => 'Le traitement d\'une transaction Bancontact a causé un problème.',
        ],
        '161' => [
            'message' => 'China UnionPay',
            'description' => 'Le traitement d\'une transaction China UnionPay a causé un problème.',
        ],
        '162' => [
            'message' => 'Trustly',
            'description' => 'Le traitement d\'une transaction Trustly a causé un problème.',
        ],
        '163' => [
            'message' => 'WeChat Pay',
            'description' => 'Le traitement d\'une transaction WeChat Pay a causé un problème.',
        ],
        '164' => [
            'message' => 'American Express SafeKey',
            'description' => 'Le traitement d\'une transaction American Express SafeKey a causé un problème.',
        ],
        '180' => [
            'message' => 'BinLookup',
            'description' => 'Le traitement d\'une transaction BinLookup a causé un problème.',
        ],
        '181' => [
            'message' => 'Schufa',
            'description' => 'Le traitement via Schufa a posé un problème.',
        ],
        '182' => [
            'message' => 'Boniversum',
            'description' => 'Le traitement d\'une transaction Boniversum a posé un problème.',
        ],
        '183' => [
            'message' => 'ATM PPRO Indonésie',
            'description' => 'Le traitement d\'une transaction ATM indonésienne via PPRO a causé un problème.',
        ],
        '184' => [
            'message' => 'PPRO MyClear FPX',
            'description' => 'Le traitement d\'une transaction MyClear FPX via PPRO a causé un problème.',
        ],
        '185' => [
            'message' => 'Contrôle de paie',
            'description' => 'Le traitement via PayControl a causé un problème.',
        ],
        '186' => [
            'message' => 'PayProtect',
            'description' => 'Le traitement via PayProtect a causé un problème.',
        ],
        '187' => [
            'message' => 'Klarna',
            'description' => 'Le traitement via Klarna a posé un problème.',
        ],
        '188' => [
            'message' => 'Deltavista',
            'description' => 'Le traitement via Deltavista a posé un problème.',
        ],
        '189' => [
            'message' => 'TauxPay',
            'description' => 'Le traitement via RatePay a causé un problème.',
        ],
        '191' => [
            'message' => 'Mpass',
            'description' => 'Le traitement via mpass a causé un problème.',
        ],
        '192' => [
            'message' => 'Sofort',
            'description' => 'Le traitement via le réseau de paiement a causé un problème.',
        ],
        '193' => [
            'message' => 'EPs',
            'description' => 'Le traitement via EPS a causé un problème.',
        ],
        '194' => [
            'message' => 'Traitement des cartes de crédit et de débit',
            'description' => 'Le traitement d\'une carte de crédit ou de débit a causé un problème.',
        ],
        '195' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '196' => [
            'message' => 'eScore',
            'description' => 'Le traitement via eScore a causé un problème.',
        ],
        '197' => [
            'message' => 'Burgel',
            'description' => 'Le traitement via Bürgel a posé un problème.',
        ],
        '198' => [
            'message' => 'PayU',
            'description' => 'Le traitement via PayU a causé un problème.',
        ],
        '199' => [
            'message' => 'InterCarte',
            'description' => 'Le traitement via InterCard a causé un problème.',
        ],
        '200' => [
            'message' => 'Traitement des cartes de crédit et de débit',
            'description' => 'Le traitement d\'une carte de crédit ou de débit a causé un problème.',
        ],
        '201' => [
            'message' => 'Traitement des cartes de crédit et de débit',
            'description' => 'Le traitement d\'une carte de crédit ou de débit a causé un problème.',
        ],
        '202' => [
            'message' => 'PPRO PAYSBUY Cash',
            'description' => 'Le traitement d\'une transaction en espèces PAYSBUY via PPRO a causé un problème.',
        ],
        '203' => [
            'message' => 'PPRO RHB Banque',
            'description' => 'Le traitement d\'une transaction bancaire RHB via PPRO a causé un problème.',
        ],
        '204' => [
            'message' => 'PPRO 7-Eleven',
            'description' => 'Le traitement d\'une transaction 7-Eleven via PPRO a causé un problème.',
        ],
        '205' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '206' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '207' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '208' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '209' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '210' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '211' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '212' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '213' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '214' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '215' => [
            'message' => 'Snap',
            'description' => 'Le traitement d\'une transaction Snap a provoqué un problème.',
        ],
        '216' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '217' => [
            'message' => 'Vme',
            'description' => 'Le traitement d\'une transaction V.me a causé un problème.',
        ],
        '218' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '219' => [
            'message' => 'Traitement des cartes de crédit ',
            'description' => 'Le traitement d\'une carte de crédit a causé un problème.',
        ],
        '220' => [
            'message' => 'PayFac',
            'description' => 'Le traitement d\'une transaction PayFac a causé un problème.',
        ],
        '221' => [
            'message' => 'PPRO BitPay',
            'description' => 'Le traitement d\'une transaction BitPay via PPRO a causé un problème.',
        ],
        '222' => [
            'message' => 'PPRO Dragonpay',
            'description' => 'Le traitement d\'une transaction Dragonpay via PPRO a causé un problème.',
        ],
        '223' => [
            'message' => 'PPRO Maybank2u',
            'description' => 'Le traitement d\'une transaction Maybank2u via PPRO a causé un problème.',
        ],
        '225' => [
            'message' => 'PPRO AstroPay',
            'description' => 'Le traitement d\'une transaction AstroPay via PPRO a causé un problème.',
        ],
        '226' => [
            'message' => 'PPRO Rabéril',
            'description' => 'Le traitement d\'une transaction Raberil via PPRO a posé un problème.',
        ],
        '227' => [
            'message' => 'Paiement PPRO Raberil',
            'description' => 'Le traitement d\'une transaction Raberil Payout via PPRO a causé un problème.',
        ],
        '228' => [
            'message' => 'Virement Bancaire PPRO',
            'description' => 'Le traitement d\'une transaction de virement bancaire via PPRO a causé un problème.',
        ],
        '230' => [
            'message' => 'PPRO iDEAl',
            'description' => 'Le traitement d\'une transaction iDEAL via PPRO a causé un problème.',
        ],
        '231' => [
            'message' => 'PPRO Przelewy24',
            'description' => 'Le traitement d\'une transaction Przelewy24 via PPRO a causé un problème.',
        ],
        '232' => [
            'message' => 'PPRO PostFinance',
            'description' => 'Le traitement d\'une transaction PostFinance via PPRO a posé un problème.',
        ],
        '233' => [
            'message' => 'PPRO giropay',
            'description' => 'Le traitement d\'une transaction giropay via PPRO a causé un problème.',
        ],
        '234' => [
            'message' => 'PPRO Sofortüberweisung',
            'description' => 'Le traitement d\'une transaction Sofortüberweisung via PPRO a posé un problème.',
        ],
        '235' => [
            'message' => 'PPRO paysafecard',
            'description' => 'Le traitement d\'une transaction Paysafecard via PPRO a causé un problème.',
        ],
        '236' => [
            'message' => 'PPRO Cash-Ticket',
            'description' => 'Le traitement d\'une transaction Cash-Ticket via PPRO a causé un problème.',
        ],
        '237' => [
            'message' => 'PPRO EPs',
            'description' => 'Le traitement d\'une transaction EPS via PPRO a causé un problème.',
        ],
        '238' => [
            'message' => 'Clairhaus',
            'description' => 'Le traitement d\'une transaction Clearhouse a causé un problème.',
        ],
        '239' => [
            'message' => 'Carte de crédit PPRO',
            'description' => 'Le traitement d\'une carte de crédit via PPRO a causé un problème.',
        ],
        '240' => [
            'message' => 'PPRO Teleingreso',
            'description' => 'Le traitement d\'un Teleingreso via PPRO a posé un problème.',
        ],
        '241' => [
            'message' => 'PPRO Skrill',
            'description' => 'Le traitement d\'une transaction Skrill via PPRO a causé un problème.',
        ],
        '242' => [
            'message' => 'IDD PPRO',
            'description' => 'Le traitement d\'une transaction IDD via PPRO a causé un problème.',
        ],
        '243' => [
            'message' => 'PPRO FasterPay',
            'description' => 'Le traitement d\'une transaction FasterPay via PPRO a causé un problème.',
        ],
        '244' => [
            'message' => 'PPRO POLI',
            'description' => 'Le traitement d\'une transaction PoLi via PPRO a causé un problème.',
        ],
        '245' => [
            'message' => 'PPRO QIWI',
            'description' => 'Le traitement d\'une transaction QIWI via PPRO a causé un problème.',
        ],
        '246' => [
            'message' => 'PPRO TrustPay',
            'description' => 'Le traitement d\'une transaction Trustpay via PPRO a causé un problème.',
        ],
        '247' => [
            'message' => 'PPRO VLE',
            'description' => 'Le traitement d\'une transaction ELV (prélèvement allemand) via PPRO a posé un problème.',
        ],
        '248' => [
            'message' => 'PPRO SafetyPay',
            'description' => 'Le traitement d\'une transaction SafetyPay via PPRO a causé un problème.',
        ],
        '249' => [
            'message' => 'PPRO Alipay',
            'description' => 'Le traitement d\'une transaction Alipay via PPRO a causé un problème.',
        ],
        '250' => [
            'message' => 'Gestion des débiteurs',
            'description' => 'Le traitement de la gestion des débiteurs a posé un problème.',
        ],
        '251' => [
            'message' => 'Banksys',
            'description' => 'Le traitement d\'une transaction Banksys a causé un problème.',
        ],
        '252' => [
            'message' => 'Amazon APA',
            'description' => 'Le traitement d\'une transaction Amazon APA a provoqué un problème.',
        ],
        '253' => [
            'message' => 'GROs',
            'description' => 'Le traitement d\'une GRANDE transaction a causé un problème.',
        ],
        '254' => [
            'message' => 'Be2bill',
            'description' => 'Le traitement d\'une transaction Be2bill a posé un problème.',
        ],
        '255' => [
            'message' => 'Crédorax',
            'description' => 'Le traitement d\'une transaction Credorax a causé un problème.',
        ],
        '256' => [
            'message' => 'Limonetik',
            'description' => 'Le traitement d\'une transaction Limonetik a posé un problème.',
        ],
        '257' => [
            'message' => 'PPRO Multibanco',
            'description' => 'Le traitement d\'une transaction Multibanco via PPRO a posé un problème.',
        ],
        '258' => [
            'message' => 'Virement bancaire en ligne PPRO Finlande',
            'description' => 'Le traitement d\'une transaction de virement bancaire en ligne en Finlande via PPRO a provoqué un problème.',
        ],
        '259' => [
            'message' => 'PPRO Bancontact',
            'description' => 'Le traitement d\'une transaction Bancontact via PPRO a posé un problème.',
        ],
        '260' => [
            'message' => 'Assistant de paiement',
            'description' => 'Le traitement via PaymentWizard a causé un problème.',
        ],
        '261' => [
            'message' => 'PPRO MaBanque',
            'description' => 'Le traitement d\'une transaction MyBank via PPRO a causé un problème.',
        ],
        '262' => [
            'message' => 'RedSys',
            'description' => 'Le traitement d\'une transaction par carte de crédit a causé un problème.',
        ],
        '263' => [
            'message' => 'AMEXCAPn',
            'description' => 'Le traitement d\'une transaction AMEX CAPN a causé un problème.',
        ],
        '264' => [
            'message' => 'KlarnaCheckout',
            'description' => 'Le traitement d\'une transaction Klarna Checkout a provoqué un problème.',
        ],
        '265' => [
            'message' => 'POSTPAYER',
            'description' => 'Le traitement d\'une transaction POSTPAY a causé un problème.',
        ],
        '266' => [
            'message' => 'iPAYst',
            'description' => 'Le traitement d\'une transaction iPAYst a causé un problème.',
        ],
        '267' => [
            'message' => 'PayULU',
            'description' => 'Le traitement d\'une transaction PayULU a causé un problème.',
        ],
        '268' => [
            'message' => 'PayUALU',
            'description' => 'Le traitement d\'une transaction PayUALU a causé un problème.',
        ],
        '269' => [
            'message' => 'SIA',
            'description' => 'Le traitement d\'une transaction SIA a causé un problème.',
        ],
        '270' => [
            'message' => 'Carte Rouge',
            'description' => 'Le traitement d\'une transaction par carte de crédit a causé un problème.',
        ],
        '271' => [
            'message' => 'Cœur du pays',
            'description' => 'Le traitement d\'une transaction Heartland a causé un problème.',
        ],
        '272' => [
            'message' => 'CB2A',
            'description' => 'Le traitement d\'une transaction CB2A a posé un problème.',
        ],
        '273' => [
            'message' => 'Paydirekt',
            'description' => 'Le traitement d\'une transaction Paydirect a causé un problème.',
        ],
        '274' => [
            'message' => 'PayULatACC',
            'description' => 'Le traitement d\'une transaction PayU LatAm a causé un problème.',
        ],
        '275' => [
            'message' => 'PayULatAWC',
            'description' => 'Le traitement d\'une transaction PayU LatAm a causé un problème.',
        ],
        '276' => [
            'message' => 'Chinapay',
            'description' => 'Le traitement d\'une transaction Chinapay a causé un problème.',
        ],
        '277' => [
            'message' => 'Carte de test',
            'description' => 'Le traitement d\'une transaction par carte de test a provoqué un problème.',
        ],
        '278' => [
            'message' => 'CoréeCC',
            'description' => 'Le traitement d\'une transaction KoreaCC a causé un problème.',
        ],
        '279' => [
            'message' => 'CarteComplete',
            'description' => 'Le traitement d\'une transaction CardComplete a causé un problème.',
        ],
        '280' => [
            'message' => 'ChasePNs',
            'description' => 'Le traitement d\'une transaction ChasePNS a causé un problème.',
        ],
        '281' => [
            'message' => 'RBI',
            'description' => 'Le traitement d\'une transaction RBI a provoqué un problème.',
        ],
        '282' => [
            'message' => 'MasaPay',
            'description' => 'Le traitement d\'une transaction MasaPay a causé un problème.',
        ],
        '283' => [
            'message' => 'SafeCharge',
            'description' => 'Le traitement d\'une transaction SafeCharge a provoqué un problème.',
        ],
        '284' => [
            'message' => 'PPRO Boleto Bancario',
            'description' => 'Le traitement d\'une transaction Boleto Bancario via PPRO a causé un problème.',
        ],
        '285' => [
            'message' => 'PPRO Chine UnionPay',
            'description' => 'Le traitement d\'une transaction China UnionPay via PPRO a causé un problème.',
        ],
        '286' => [
            'message' => 'PPRO WeChat Pay',
            'description' => 'Le traitement d\'une transaction WeChat Pay via PPRO a causé un problème.',
        ],
        '287' => [
            'message' => 'PPRO Zimpler',
            'description' => 'Le traitement d\'une transaction Zimpler via PPRO a causé un problème.',
        ],
        '288' => [
            'message' => 'IFSF',
            'description' => 'Le traitement d\'une transaction IFSF a causé un problème.',
        ],
        '289' => [
            'message' => 'KlarnaPayment',
            'description' => 'Le traitement d\'une transaction Klarna Payment a causé un problème.',
        ],
        '290' => [
            'message' => 'girocard',
            'description' => 'Le traitement d\'une transaction POS giropay a provoqué un problème.',
        ],
        '300' => [
            'message' => 'POs',
            'description' => 'Le traitement d\'une transaction POS a causé un problème.',
        ],
        '305' => [
            'message' => 'POSCC',
            'description' => 'Le traitement d\'une transaction par carte de crédit ou de débit via le terminal POS a provoqué un problème.',
        ],
        '311' => [
            'message' => 'POSELV',
            'description' => 'Le traitement d\'une transaction ELV (prélèvement allemand) via le TPV a provoqué un problème.',
        ],
        '316' => [
            'message' => 'POSGIROPAY',
            'description' => 'Le traitement d\'une transaction giropay via le terminal POS a provoqué un problème.',
        ],
        '360' => [
            'message' => 'POSGK',
            'description' => 'Le traitement d\'une transaction par carte de paiement via le terminal POS a provoqué un problème.',
        ],
    ],
    'paramètres' => [
        '0000' => [
            'message' => 'Non spécifié',
            'description' => 'Problème non spécifié qui doit être analysé manuellement, veuillez contacter le support Computop.',
        ],
        '0001' => [
            'message' => 'ID Payant',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0002' => [
            'message' => 'transId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0003' => [
            'message' => 'IDCommerçant',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0004' => [
            'message' => 'ReqId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0005' => [
            'message' => 'Montant',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0006' => [
            'message' => 'Devise',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0007' => [
            'message' => 'Données',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0008' => [
            'message' => 'Len',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0009' => [
            'message' => 'Capturer',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0010' => [
            'message' => 'Réponse',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0011' => [
            'message' => 'Description de la commande',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0012' => [
            'message' => 'Commande2',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0013' => [
            'message' => 'CHDesc',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0014' => [
            'message' => 'Plaine',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0015' => [
            'message' => 'CCNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0016' => [
            'message' => 'CCNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0017' => [
            'message' => 'CCExpiry',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0018' => [
            'message' => 'CCMarque',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0019' => [
            'message' => 'CCCVC',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0020' => [
            'message' => 'PARAM INVALIDE : URLSUCCESs',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0021' => [
            'message' => 'PARAM INVALIDE : URLFAILURE',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0022' => [
            'message' => 'PARAM INVALIDE : URLNOTIFY',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0023' => [
            'message' => 'Acquéreur',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0024' => [
            'message' => 'AccNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0025' => [
            'message' => 'AccBank',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0026' => [
            'message' => 'AccIBAn',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0027' => [
            'message' => 'ListeAccIBAN',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0028' => [
            'message' => 'PARes',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0029' => [
            'message' => 'Numéro de portable',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0030' => [
            'message' => 'MobileNet',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0031' => [
            'message' => 'insStatus',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0032' => [
            'message' => 'RéfNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0033' => [
            'message' => 'Zone',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0034' => [
            'message' => 'TransURl',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0035' => [
            'message' => 'Textfeld1',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0036' => [
            'message' => 'Textfeld2',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0037' => [
            'message' => 'Prénom',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0038' => [
            'message' => 'genre',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0039' => [
            'message' => 'date de naissance',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0040' => [
            'message' => 'Aucune réponse',
            'description' => 'Les systèmes backend (par exemple, l\'acquisition, les systèmes de cartes ou l\'API des systèmes de paiement) ne répondaient pas.',
        ],
        '0041' => [
            'message' => 'Date de début',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0042' => [
            'message' => 'Date de fin',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0043' => [
            'message' => 'MerchantIDExt',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0044' => [
            'message' => 'MAC',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0045' => [
            'message' => 'Commerçant occupé',
            'description' => 'Surcharge du compte marchand.',
        ],
        '0046' => [
            'message' => 'Aucun TID disponible',
            'description' => 'Aucun identifiant de terminal disponible pour la transaction entrante.',
        ],
        '0047' => [
            'message' => 'TID manquant',
            'description' => 'Le TerminalID nécessaire manquait.',
        ],
        '0048' => [
            'message' => 'VuNr manquant',
            'description' => 'Le numéro du commerçant auprès de la banque acquéreuse manquait.',
        ],
        '0049' => [
            'message' => 'expirationTime',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0050' => [
            'message' => 'Erreur système',
            'description' => 'Les systèmes Paygate ou backend ont transmis une erreur système.',
        ],
        '0051' => [
            'message' => 'Timeout / Requête expirée',
            'description' => 'Erreur de traitement due à un délai d\'attente.',
        ],
        '0052' => [
            'message' => 'Erreur de communication',
            'description' => 'Erreur de traitement due à des problèmes de communication.',
        ],
        '0053' => [
            'message' => 'Annuler par l\'utilisateur',
            'description' => 'Traitement abandonné par l\'utilisateur.',
        ],
        '0054' => [
            'message' => 'Inversion',
            'description' => 'l\'annulation d\'une transaction a provoqué une erreur.',
        ],
        '0055' => [
            'message' => 'Inconnu',
            'description' => 'Problème inconnu qui doit être analysé manuellement, veuillez contacter le support Computop.',
        ],
        '0056' => [
            'message' => 'Délai d\'expiration',
            'description' => 'Le délai d\'attente individuel entre Paygate et le système marchand a été dépassé (NVAG).',
        ],
        '0057' => [
            'message' => 'Agences de crédit',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0058' => [
            'message' => 'Identifiant émetteur',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0059' => [
            'message' => 'Compte',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0060' => [
            'message' => 'Non actif',
            'description' => 'Le type de transaction transmis n\'a pas été activé pour le compte marchand, veuillez contacter le support Computop.',
        ],
        '0061' => [
            'message' => 'Introuvable',
            'description' => 'Le paiement n\'a pas pu être trouvé en raison d\'un PAYID erroné.',
        ],
        '0062' => [
            'message' => 'Autre transaction active',
            'description' => 'Une autre étape de transaction était en attente et bloquait donc la transaction demandée.',
        ],
        '0063' => [
            'message' => 'Non autorisé',
            'description' => 'La transaction n\'a pas été autorisée.',
        ],
        '0064' => [
            'message' => 'fractionnement actif',
            'description' => 'Pour une gestion améliorée des transactions uniquement : le Paygate effectuait une autorisation après une capture partielle et n\'a donc pas pu traiter la transaction demandée.',
        ],
        '0065' => [
            'message' => 'capture active',
            'description' => 'Pour une gestion améliorée des transactions uniquement : le Paygate effectuait une transaction de capture et n\'a donc pas pu traiter la transaction demandée.',
        ],
        '0066' => [
            'message' => 'crédit actif',
            'description' => 'Pour une gestion améliorée des transactions uniquement : le Paygate effectuait une transaction de crédit (remboursement) et n\'a donc pas pu traiter la transaction demandée.',
        ],
        '0067' => [
            'message' => 'Surcapture',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0068' => [
            'message' => 'Déjà autorisé',
            'description' => 'Le paiement a déjà été autorisé.',
        ],
        '0069' => [
            'message' => 'Rien capturé',
            'description' => 'La capture n\'a pas été traitée faute d\'autorisation préalable.',
        ],
        '0070' => [
            'message' => 'ValeurMin',
            'description' => 'La capture n\'a pas été traitée en raison d\'un montant inférieur à la valeur minimale (pour les valeurs minimales individuelles, veuillez contacter notre support).',
        ],
        '0071' => [
            'message' => 'Désactivé',
            'description' => 'La fonction demandée a été désactivée, par exemple les captures pendant la phase de test.',
        ],
        '0072' => [
            'message' => 'Déjà capturé',
            'description' => 'La capture a déjà été effectuée et n\'a pas pu être répétée.',
        ],
        '0073' => [
            'message' => 'Avorté',
            'description' => 'La transaction a été interrompue.',
        ],
        '0074' => [
            'message' => 'Remplacement du montant',
            'description' => 'Le montant de la capture était supérieur au montant admis qui était lié à l\'autorisation préalable.',
        ],
        '0075' => [
            'message' => 'Rien d\'autorisé',
            'description' => 'Autorisation manquante.',
        ],
        '0076' => [
            'message' => 'Abandon de la capture impossible',
            'description' => 'La capture était en cours de traitement (Capture_Request, Capture_Waiting) et n\'a donc pas pu être annulée.',
        ],
        '0077' => [
            'message' => 'Aucun mode de paiement valide trouvé',
            'description' => 'Le type de paiement demandé n\'a pas été activé pour le compte marchand, veuillez contacter le support Computop.',
        ],
        '0078' => [
            'message' => 'Mode de paiement invalide',
            'description' => 'Le type de paiement demandé n\'est pas pris en charge pour le mode de paiement.',
        ],
        '0079' => [
            'message' => 'URL de validation',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0080' => [
            'message' => 'Mode de paiement non pris en charge',
            'description' => 'Le type de paiement demandé n\'est pas pris en charge pour le mode de paiement.',
        ],
        '0081' => [
            'message' => 'Action non prise en charge',
            'description' => 'Le mode de paiement ne prend pas en charge le type de paiement demandé (par exemple Capture pour GeldKarte)',
        ],
        '0082' => [
            'message' => 'Mode de paiement invalide',
            'description' => 'Le type de paiement demandé n\'est pas pris en charge pour le mode de paiement.',
        ],
        '0083' => [
            'message' => 'Erreur système',
            'description' => 'Erreur système.',
        ],
        '0084' => [
            'message' => 'MobileNo invalid',
            'description' => 'Le numéro de portable n\'était pas valide.',
        ],
        '0085' => [
            'message' => 'Chaîne',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0086' => [
            'message' => 'SellingPoint',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0087' => [
            'message' => 'Service',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0088' => [
            'message' => 'AccBankCity',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0089' => [
            'message' => 'CodeBanque',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0090' => [
            'message' => '3DSecure SetValue a échoué',
            'description' => 'l\'initialisation du plugin marchand pour Verified by Visa et MasterCard SecureCode a échoué.',
        ],
        '0091' => [
            'message' => 'Non inscrit',
            'description' => 'Le numéro de carte de crédit du client n\'a pas été activé pour Verified by Visa ou MasterCard SecureCode.',
        ],
        '0092' => [
            'message' => 'Pas de réponse',
            'description' => 'Le paramètre PAResponse n\'a pas été transmis à Direct3D.aspx.',
        ],
        '0093' => [
            'message' => 'Pas de JavaScript',
            'description' => 'La colonne du client ne prend pas en charge JavaScript, qui est nécessaire pour Verified by Visa et SecureCode.',
        ],
        '0094' => [
            'message' => 'Date d\'expiration épuisée',
            'description' => 'Carte expirée.',
        ],
        '0095' => [
            'message' => 'Impossible de s\'authentifier',
            'description' => 'La carte n\'est pas éligible au 3D Secure',
        ],
        '0096' => [
            'message' => 'Non-Participation',
            'description' => 'Le numéro de carte de crédit du client n\'a pas été activé pour Verified by Visa ou MasterCard SecureCode.',
        ],
        '0097' => [
            'message' => 'Erreur de vérification',
            'description' => 'une erreur s\'est produite lors de VerifyEnrollment',
        ],
        '0098' => [
            'message' => 'Erreur d\'authentification de paiement',
            'description' => 'une erreur s\'est produite lors de l\'authentification',
        ],
        '0099' => [
            'message' => 'XId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0100' => [
            'message' => 'Refusé',
            'description' => 'La banque émettrice a refusé le paiement.',
        ],
        '0101' => [
            'message' => 'Désactivé',
            'description' => 'Le type de transaction a été désactivé et n\'a pas pu être traité.',
        ],
        '0102' => [
            'message' => 'Numéro de carte invalide',
            'description' => 'Numéro de carte invalide.',
        ],
        '0103' => [
            'message' => 'Émetteur de l\'appel',
            'description' => 'l\'émetteur a refusé le paiement, veuillez appeler l\'émetteur.',
        ],
        '0104' => [
            'message' => 'refusé par la liste noire ',
            'description' => 'La carte de crédit ou de débit transmise figurait sur la liste noire des commerçants et a donc été rejetée.',
        ],
        '0105' => [
            'message' => 'Amex AVS ne correspond pas',
            'description' => 'Les données transmises ne correspondent pas aux données American Express (vérification de l\'adresse).',
        ],
        '0106' => [
            'message' => 'Numéro de carte',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0107' => [
            'message' => 'Code de vérification',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0108' => [
            'message' => 'ID opérateur',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0110' => [
            'message' => 'Expiré',
            'description' => 'Carte expirée.',
        ],
        '0111' => [
            'message' => 'Marque non prise en charge',
            'description' => 'La marque de carte de crédit sélectionnée n\'est pas prise en charge.',
        ],
        '0112' => [
            'message' => 'AuthLabel',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0113' => [
            'message' => 'AuthToken',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0114' => [
            'message' => 'Date d\'expiration',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0115' => [
            'message' => 'AuthCode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0116' => [
            'message' => 'Total',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0117' => [
            'message' => 'Liste des factures',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0118' => [
            'message' => 'Ordre de révocation d\'autorisation',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0119' => [
            'message' => 'Révocation de toute commande d\'autorisation',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0120' => [
            'message' => 'Récupérer la carte',
            'description' => 'Récupérer la carte invalide (POS) utilisée.',
        ],
        '0121' => [
            'message' => 'Émetteur non joignable',
            'description' => 'La banque émettrice était temporairement indisponible.',
        ],
        '0122' => [
            'message' => 'CCBin',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0130' => [
            'message' => 'incompatibilité PCNR',
            'description' => 'Le numéro de pseudo-carte transmis n\'était pas valide.',
        ],
        '0131' => [
            'message' => 'INCONVENANCE PBAn',
            'description' => 'Le PBAN transmis n\'était pas valide.',
        ],
        '0132' => [
            'message' => 'Terme',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0133' => [
            'message' => 'Emploi',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0134' => [
            'message' => 'Revenu net mensuel',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0135' => [
            'message' => 'PackingStation',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0136' => [
            'message' => 'Lieu de naissance',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0137' => [
            'message' => 'Statut Client',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0138' => [
            'message' => 'ClientDepuis',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0139' => [
            'message' => 'ClientLoggedIn',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0140' => [
            'message' => 'Incompatibilité de personne',
            'description' => 'La personne recherchée différait par les paramètres date de naissance ou adresse (interface Schufa uniquement).',
        ],
        '0141' => [
            'message' => 'NombreArticles',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0142' => [
            'message' => 'NombreCommandes',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0143' => [
            'message' => 'NegativePaymentInfo',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0144' => [
            'message' => 'RiskArticles',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0145' => [
            'message' => 'Date',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0146' => [
            'message' => 'Commande',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0147' => [
            'message' => 'Risque Client',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0161' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du contrôle IP dans Securepay (limite par heure).',
        ],
        '0162' => [
            'message' => 'REFUSÉ POUR FRAUDE ',
            'description' => 'Paiement rejeté en raison des paramètres du chèque-carte dans Securepay (limite par heure).',
        ],
        '0163' => [
            'message' => 'REFUSÉ POUR FRAUDE ',
            'description' => 'Paiement rejeté en raison des paramètres du chèque de montant combinés avec le chèque IP dans Securepay (limite par heure).',
        ],
        '0164' => [
            'message' => 'REFUSÉ POUR FRAUDE ',
            'description' => 'Paiement rejeté en raison des paramètres du chèque de montant combiné avec le chèque de carte dans Securepay (limite par heure).',
        ],
        '0165' => [
            'message' => 'REFUSÉ POUR FRAUDE ',
            'description' => 'Paiement rejeté en raison du paramétrage du contrôle (numéro de référence identique et/ou transId) dans Securepay (limite horaire).',
        ],
        '0166' => [
            'message' => 'REFUSÉ POUR FRAUDE ',
            'description' => 'Paiement rejeté en raison des paramètres de contrôle de carte/chèque IP dans Securepay (limite par heure).',
        ],
        '0167' => [
            'message' => 'REFUSÉ POUR FRAUDE ',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID-Check dans Securepay (limite par heure).',
        ],
        '0168' => [
            'message' => 'REFUSÉ POUR FRAUDE ',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID/Card-Check dans Securepay (limite par heure).',
        ],
        '0169' => [
            'message' => 'REFUSÉ POUR FRAUDE ',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID/IP-Check dans Securepay (limite par heure).',
        ],
        '0170 ' => [
            'message' => 'Refusé par la liste blanche',
            'description' => 'La carte/BIN ne faisait pas partie de la liste blanche et a donc été rejetée.',
        ],
        '0190' => [
            'message' => 'Incompatibilité de zones',
            'description' => 'Le pays d\'expédition transmis ne correspond pas au pays émetteur de la carte de crédit.',
        ],
        '0191' => [
            'message' => 'Incompatibilité de zone IP',
            'description' => 'Le client utilisait une adresse IP qui ne faisait pas partie de votre liste de pays individuelle.',
        ],
        '0192' => [
            'message' => 'Incohérence IP CCOrigin',
            'description' => 'Le client utilisait une adresse IP qui ne correspondait pas au pays émetteur de la carte de crédit.',
        ],
        '0193' => [
            'message' => 'Erreur de suivi IP',
            'description' => 'Erreur lors de l\'analyse de l\'adresse IP du client.',
        ],
        '0194' => [
            'message' => 'INCONVENTION d\'ORIGINE IBAN IP',
            'description' => 'Le pays de l\'adresse IP ne correspond pas au pays de l\'IBAN.',
        ],
        '0200' => [
            'message' => 'l\'authentification a échoué',
            'description' => 'l\'authentification via Verified by Visa et/ou MasterCard SecureCode a échoué.',
        ],
        '0201' => [
            'message' => 'signature échouée',
            'description' => 'l\'authentification via Verified by Visa et/ou MasterCard SecureCode a échoué.',
        ],
        '0202' => [
            'message' => 'Traitement de contournement désactivé',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0203' => [
            'message' => 'La marque ne prend pas en charge 3D Secure',
            'description' => 'La marque de la carte ne participe pas à 3D secure.',
        ],
        '0301' => [
            'message' => 'Réponse manquante',
            'description' => 'La réponse du centre de données bancaire était incomplète.',
        ],
        '0302' => [
            'message' => 'Refusé, autorisation par téléphone possible',
            'description' => 'Paiement rejeté.',
        ],
        '0303' => [
            'message' => 'Numéro VU invalide',
            'description' => 'Erreur système au sein du centre de données bancaire.',
        ],
        '0304' => [
            'message' => 'Carte non autorisée',
            'description' => 'La carte utilisée n\'a pas été autorisée.',
        ],
        '0305' => [
            'message' => 'Rejeté par le système d\'autorisation',
            'description' => 'Le système d\'autorisation a rejeté l\'autorisation de la carte : pour des raisons de sécurité des données, d\'autres informations détaillées ne sont pas transmises au Paygate et sont connues uniquement de la banque émettrice.',
        ],
        '0306' => [
            'message' => 'Transfert de fichier incorrect',
            'description' => 'Transfert de fichier ou numéro de séquence incorrect.',
        ],
        '0307' => [
            'message' => 'impossible de convertir les données du compte',
            'description' => 'Les données du compte n\'ont pas pu être converties par InterCard. (Pas de réponse ou données de compte invalides)',
        ],
        '0309' => [
            'message' => 'Traitement retardé de l\'autorisation',
            'description' => 'Point de vente : échec de la transaction.',
        ],
        '0312' => [
            'message' => 'Transaction invalide',
            'description' => 'Transaction invalide, par exemple en raison d\'une mauvaise devise.',
        ],
        '0313' => [
            'message' => 'Limite dépassée',
            'description' => 'La limite a été dépassée.',
        ],
        '0314' => [
            'message' => 'Carte invalide',
            'description' => 'La carte n\'était pas valide.',
        ],
        '0321' => [
            'message' => 'La transaction initiale est introuvable',
            'description' => 'Erreur système au sein du centre de données bancaire.',
        ],
        '0324' => [
            'message' => 'Transfert de fichiers non pris en charge',
            'description' => 'Point de vente : échec de la transaction.',
        ],
        '0329' => [
            'message' => 'Transfert de fichier échoué',
            'description' => 'Point de vente : échec de la transaction.',
        ],
        '0330' => [
            'message' => 'mauvais format',
            'description' => 'Erreur système au sein du centre de données bancaire.',
        ],
        '0331' => [
            'message' => 'Émetteur invalide',
            'description' => 'Émetteur invalide/non autorisé.',
        ],
        '0333' => [
            'message' => 'Date d\'expiration épuisée',
            'description' => 'Date d\'expiration de la carte épuisée.',
        ],
        '0334' => [
            'message' => 'fraude possible',
            'description' => 'Paiement potentiellement frauduleux.',
        ],
        '0340' => [
            'message' => 'Action non prise en charge',
            'description' => 'Paiement rejeté en raison d\'une erreur système au sein du centre de données bancaire.',
        ],
        '0341' => [
            'message' => 'Carte verloren, bitte einziehen',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0343' => [
            'message' => 'Carte volée, récupérer la carte.',
            'description' => 'Carte volée, récupérer la carte.',
        ],
        '0349' => [
            'message' => 'Mauvaise devise',
            'description' => 'Mauvaise devise transmise à l\'API.',
        ],
        '0350' => [
            'message' => 'Double autorisation',
            'description' => 'Il y a eu une double autorisation.',
        ],
        '0351' => [
            'message' => 'Limit überschritten, Doch-Funktion möglich',
            'description' => 'Limite de carte dépassée.',
        ],
        '0352' => [
            'message' => 'Compte introuvable ou inexistant',
            'description' => 'Point de vente : Le paramètre dans la colonne B a causé un problème.',
        ],
        '0354' => [
            'message' => 'ec-Chip invalide',
            'description' => 'La carte à puce utilisée n\'est pas valide.',
        ],
        '0355' => [
            'message' => 'PIN incorrect',
            'description' => 'Le code PIN utilisé n\'est pas valide.',
        ],
        '0356' => [
            'message' => 'Carte invalide',
            'description' => 'La carte utilisée n\'est pas valide/non autorisée.',
        ],
        '0357' => [
            'message' => 'La transaction initiale est introuvable',
            'description' => 'Erreur système au sein du centre de données bancaire.',
        ],
        '0358' => [
            'message' => 'Transaktion nicht erlaubt',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0359' => [
            'message' => 'fraude possible',
            'description' => 'Paiement potentiellement frauduleux.',
        ],
        '0361' => [
            'message' => 'carte bloquée à cause d\'une liste noire',
            'description' => 'Carte bloquée dans la liste noire locale.',
        ],
        '0362' => [
            'message' => 'carte bloquée',
            'description' => 'Carte bloquée.',
        ],
        '0364' => [
            'message' => 'Montant de la transaction différent de la transaction de référence',
            'description' => 'Point de vente : le paramètre de la colonne B a causé un problème.',
        ],
        '0365' => [
            'message' => 'Limite de fréquence de transaction dépassée',
            'description' => 'Point de vente : le paramètre de la colonne B a causé un problème.',
        ],
        '0367' => [
            'message' => 'Carte unique',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0368' => [
            'message' => 'Le système ne répond pas, Timeout',
            'description' => 'Point de vente : le paramètre de la colonne B a causé un problème.',
        ],
        '0375' => [
            'message' => 'compteur de dysfonctionnements dans AS expiré',
            'description' => 'Point de vente : le paramètre de la colonne B a causé un problème.',
        ],
        '0376' => [
            'message' => 'mauvais index',
            'description' => 'Erreur système au sein du centre de données bancaire.',
        ],
        '0377' => [
            'message' => 'Le code PIN doit être saisi / erreur dans BMP62',
            'description' => 'Point de vente : le paramètre de la colonne B a causé un problème.',
        ],
        '0378' => [
            'message' => 'Erreur de séquence dans BMP62 / système de transaction inaccessible',
            'description' => 'Point de vente : le paramètre de la colonne B a causé un problème.',
        ],
        '0379' => [
            'message' => 'La base de données n\'est pas accessible',
            'description' => 'Point de vente : le paramètre de la colonne B a causé un problème.',
        ],
        '0380' => [
            'message' => 'le montant demandé dépasse la limite',
            'description' => 'Point de vente : le paramètre de la colonne B a causé un problème.',
        ],
        '0381' => [
            'message' => 'Initialisation corrompue',
            'description' => 'Point de vente : le paramètre de la colonne B a causé un problème.',
        ],
        '0382' => [
            'message' => '(pré-)initialisation impossible',
            'description' => 'Point de vente : le paramètre de la colonne B a causé un problème.',
        ],
        '0383' => [
            'message' => 'Échange de PIN-Pad impossible',
            'description' => 'PIN-Pad-Changement impossible (POS uniquement).',
        ],
        '0385' => [
            'message' => 'refusé par l\'émetteur',
            'description' => 'Paiement rejeté par la banque émettrice.',
        ],
        '0386' => [
            'message' => 'Données de base invalides, ZKA-No. faux',
            'description' => 'Erreur système au sein du centre de données bancaire.',
        ],
        '0387' => [
            'message' => 'Terminal inconnu',
            'description' => 'Erreur système au sein du centre de données bancaire.',
        ],
        '0388' => [
            'message' => 'PIN non actif',
            'description' => 'Point de vente : le paramètre de la colonne B a causé un problème.',
        ],
        '0389' => [
            'message' => 'CRC erroné',
            'description' => 'Point de vente : le paramètre de la colonne B a causé un problème.',
        ],
        '0391' => [
            'message' => 'Émetteur indisponible',
            'description' => 'La banque émettrice ou le réseau bancaire était temporairement indisponible.',
        ],
        '0392' => [
            'message' => 'Le système d\'autorisation a détecté un mauvais routage',
            'description' => 'Erreur système au sein du centre de données bancaire.',
        ],
        '0396' => [
            'message' => 'traitement impossible',
            'description' => 'Le traitement n\'a pas pu être temporairement possible.',
        ],
        '0397' => [
            'message' => 'erreur de cryptage',
            'description' => 'Erreur système au sein du centre de données bancaire.',
        ],
        '0398' => [
            'message' => 'Incohérence date/heure, numéro de trace erroné.',
            'description' => 'Erreur système au sein du centre de données bancaire : soit l\'horodatage était erroné, soit le numéro de trace n\'était pas ascendant.',
        ],
        '0399' => [
            'message' => 'inconnu',
            'description' => 'Erreur système au sein du centre de données bancaire.',
        ],
        '0400' => [
            'message' => 'Numéro de portable inconnu',
            'description' => 'Le numéro de téléphone utilisé n\'était pas un numéro de téléphone prépayé.',
        ],
        '0401' => [
            'message' => 'Refusé',
            'description' => 'Le rechargement de la carte prépayée n\'a pas été possible temporairement.',
        ],
        '0402' => [
            'message' => 'Refusé',
            'description' => 'Le rechargement de la carte prépayée n\'a pas été possible temporairement.',
        ],
        '0403' => [
            'message' => 'Limite de frais atteinte',
            'description' => 'Le montant maximum de recharge a été atteint.',
        ],
        '0404' => [
            'message' => 'Charge bloquée',
            'description' => 'La charge a été bloquée. La carte de crédit n\'a pas été débitée.',
        ],
        '0405' => [
            'message' => 'Erreur du système d\'autorisation interne',
            'description' => 'La charge a été bloquée. La carte de crédit n\'a pas été débitée.',
        ],
        '0406' => [
            'message' => 'Erreur de connexion interne au système d\'autorisation',
            'description' => 'La charge a été bloquée. La carte de crédit n\'a pas été débitée.',
        ],
        '0407' => [
            'message' => 'Erreur du système d\'autorisation interne',
            'description' => 'La charge a été bloquée. La carte de crédit n\'a pas été débitée.',
        ],
        '0408' => [
            'message' => 'Numéro de mobile inconnu ou introuvable',
            'description' => 'Le numéro de téléphone n\'est pas un numéro prépayé valide.',
        ],
        '0409' => [
            'message' => 'Erreur système',
            'description' => 'La charge a été bloquée. La carte de crédit n\'a pas été débitée.',
        ],
        '0410' => [
            'message' => 'Montant invalide',
            'description' => 'Le montant de recharge transmis n\'était pas valide.',
        ],
        '0411' => [
            'message' => 'État de charge inconnu, rappelez (T-Mobile)',
            'description' => 'l\'état de la recharge était inconnu : veuillez contacter T-Mobile.',
        ],
        '0412' => [
            'message' => 'État de charge inconnu, rappelez (Vodafone)',
            'description' => 'l\'état de la recharge était inconnu : veuillez contacter Vodafone.',
        ],
        '0413' => [
            'message' => 'Appeler la hotline GZS : Code-Nr 01',
            'description' => 'Le statut de la recharge était inconnu : veuillez contacter easycash.',
        ],
        '0414' => [
            'message' => 'Numéro VU invalide',
            'description' => 'Le numéro de commerçant de votre contrat d\'acquisition n\'est pas valide, veuillez contacter le support Computop.',
        ],
        '0415' => [
            'message' => 'Cashback impossible',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0500' => [
            'message' => 'Invalide',
            'description' => 'la combinaison code bancaire et numéro de compte bancaire n\'était pas valide.',
        ],
        '0501' => [
            'message' => 'Fichier manquant',
            'description' => 'Le fichier de vérification du code bancaire n\'était pas disponible.',
        ],
        '0502' => [
            'message' => 'Erreur Konto Check',
            'description' => 'Erreur système lors de la vérification du code bancaire.',
        ],
        '0510' => [
            'message' => 'échec de la vérification olv',
            'description' => 'Prélèvement automatique rejeté.',
        ],
        '0600' => [
            'message' => 'ID invalide',
            'description' => 'Crédit rejeté - la transaction initiale est introuvable.',
        ],
        '0650' => [
            'message' => 'ShopID non transféré',
            'description' => 'La configuration du moyen de paiement n\'est pas terminée, veuillez contacter le support Computop.',
        ],
        '0651' => [
            'message' => 'ID boutique inconnu',
            'description' => 'La configuration du moyen de paiement n\'est pas terminée, veuillez contacter le support Computop.',
        ],
        '0652' => [
            'message' => 'ID client non transféré',
            'description' => 'La configuration du moyen de paiement n\'est pas terminée, veuillez contacter le support Computop.',
        ],
        '0653' => [
            'message' => 'ID client inconnu',
            'description' => 'La configuration du moyen de paiement n\'est pas terminée, veuillez contacter le support Computop.',
        ],
        '0654' => [
            'message' => 'Mot de passe de la boutique non transféré',
            'description' => 'La configuration du moyen de paiement n\'est pas terminée, veuillez contacter le support Computop.',
        ],
        '0655' => [
            'message' => 'Mot de passe de la boutique inconnu',
            'description' => 'La configuration du moyen de paiement n\'est pas terminée, veuillez contacter le support Computop.',
        ],
        '0656' => [
            'message' => 'TransType manquant',
            'description' => 'La configuration du moyen de paiement n\'est pas terminée, veuillez contacter le support Computop.',
        ],
        '0657' => [
            'message' => 'TransType invalide',
            'description' => 'La configuration du moyen de paiement n\'est pas terminée, veuillez contacter le support Computop.',
        ],
        '0658' => [
            'message' => 'TransType non autorisé',
            'description' => 'La configuration du moyen de paiement n\'est pas terminée, veuillez contacter le support Computop.',
        ],
        '0664' => [
            'message' => 'Compte bancaire invalide',
            'description' => 'Virement bancaire en ligne : numéro de compte invalide.',
        ],
        '0665' => [
            'message' => 'Numéro de commande invalide',
            'description' => 'La configuration du moyen de paiement n\'est pas terminée, veuillez contacter le support Computop.',
        ],
        '0670' => [
            'message' => 'BLZV',
            'description' => 'Le paramètre BLZV est à l\'origine du problème.',
        ],
        '0702' => [
            'message' => 'Invalide',
            'description' => 'Erreur de validation.',
        ],
        '0703' => [
            'message' => 'Utilisateur annulé',
            'description' => 'Utilisateur annulé.',
        ],
        '0705' => [
            'message' => 'résultat incertain',
            'description' => 'Le statut définitif du paiement n\'a pas pu être transmis.',
        ],
        '0709' => [
            'message' => 'indoute',
            'description' => 'Le système backend n\'a pas encore confirmé la transaction',
        ],
        '0710' => [
            'message' => 'l\'état du centre de données bancaire est inconnu.',
            'description' => 'Le système backend a rejeté la transaction.',
        ],
        '0720' => [
            'message' => 'Hash invalide',
            'description' => 'Longueur ou format incorrect de la clé de hachage.',
        ],
        '0721' => [
            'message' => 'Hash incorrect',
            'description' => 'Erreur de calcul de la clé de hachage.',
        ],
        '0722' => [
            'message' => 'Utilisateur inconnu',
            'description' => 'Utilisateur inconnu par Schufa.',
        ],
        '0723' => [
            'message' => 'Utilisateur invalide',
            'description' => 'l\'utilisateur a interrompu le processus et était inconnu.',
        ],
        '0777' => [
            'message' => 'Incohérence demande/réponse',
            'description' => 'Paiement par carte de crédit ou de débit rejeté en raison d\'une erreur au sein du centre de données bancaire.',
        ],
        '0801' => [
            'message' => 'Erreur de certificat/signature',
            'description' => 'l\'authentification a échoué en raison d\'une erreur de certificat (Schufa).',
        ],
        '0802' => [
            'message' => 'Certificat/Signature manquant',
            'description' => 'l\'authentification a échoué en raison d\'une erreur de certificat (Schufa).',
        ],
        '0803' => [
            'message' => 'trop de demandes',
            'description' => 'l\'authentification a échoué en raison d\'un nombre dépassé de requêtes parallèles.',
        ],
        '0804' => [
            'message' => 'Communication avec l\'hôte perturbée',
            'description' => 'Erreur de communication avec Schufa.',
        ],
        '0805' => [
            'message' => 'Hôte inaccessible',
            'description' => 'Erreur de communication avec Schufa.',
        ],
        '0806' => [
            'message' => 'Hôte surchargé',
            'description' => 'Erreur de communication avec Schufa.',
        ],
        '0807' => [
            'message' => 'Valeur de champ manquante ou invalide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0808' => [
            'message' => 'Accès refusé',
            'description' => 'Échec de l\'authentification (Schufa).',
        ],
        '0809' => [
            'message' => 'Erreur interne',
            'description' => 'Erreur système (Schufa).',
        ],
        '0810' => [
            'message' => 'inconnu',
            'description' => 'Erreur inconnue (Schufa).',
        ],
        '0851' => [
            'message' => 'ROUGE : Adresse invalide',
            'description' => 'l\'analyse du nom n\'a pas été possible : données incorrectes ou disponibles pour plusieurs personnes.',
        ],
        '0852' => [
            'message' => 'ROUGE : Adresse incomplète',
            'description' => 'Données d\'adresse incomplètes.',
        ],
        '0853' => [
            'message' => 'ROUGE : inconnu',
            'description' => 'Erreur inconnue lors de la vérification de l\'adresse.',
        ],
        '0854' => [
            'message' => 'ROUGE : Nom correct',
            'description' => 'Erreur de données : ajuster le nom.',
        ],
        '0855' => [
            'message' => 'ROUGE : Adresse correcte',
            'description' => 'Erreur de données : ajuster l\'adresse.',
        ],
        '0856' => [
            'message' => 'ROUGE : type de données invalide',
            'description' => 'Erreur de données : type de données non valide dans XML-Nachricht vers Paycontrol.',
        ],
        '0857' => [
            'message' => 'ROUGE : erreur interne',
            'description' => 'Erreur interne lors de l\'interprétation du contrôle de solvabilité.',
        ],
        '0861' => [
            'message' => 'JAUNE : (recommandations basées sur un "système de feux tricolores")',
            'description' => 'Contrôle de solvabilité négatif ou caractéristiques légèrement négatives pour la personne.',
        ],
        '0862' => [
            'message' => 'ROT : (recommandations basées sur un "système de feux tricolores")',
            'description' => 'Caractéristiques négatives moyennes ou fortes pour la personne ou adresse invalide ou incomplète.',
        ],
        '0901' => [
            'message' => 'Erreur de format du message',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0902' => [
            'message' => 'Erreur système externe',
            'description' => 'Erreur système externe',
        ],
        '0904' => [
            'message' => 'Valeur invalide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0905' => [
            'message' => 'Erreur de traitement',
            'description' => 'Le système backend a rejeté la transaction.',
        ],
        '0906' => [
            'message' => 'Erreur externe, voir CodeExt ou ErrorText pour plus de détails',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0921' => [
            'message' => 'Mode maintenance FTG',
            'description' => 'Travaux de maintenance de la Plateforme de Transactions Financières des banques.',
        ],
        '0922' => [
            'message' => 'La banque est hors ligne',
            'description' => 'l\'émetteur était temporairement indisponible.',
        ],
        '0923' => [
            'message' => 'Banque émettrice invalide en raison de la fusion',
            'description' => 'Le code bancaire du client n\'est pas valide en raison d\'une fusion entre deux banques.',
        ],
        '0924' => [
            'message' => 'Compte expéditeur invalide en raison d\'une entrée sur liste noire',
            'description' => 'Le compte du client n\'a pas été autorisé en raison d\'une entrée sur liste noire.',
        ],
        '0925' => [
            'message' => 'Compte expéditeur invalide en raison de données manquantes',
            'description' => 'Le compte du client n\'a pas été autorisé en raison d\'un manque d\'informations.',
        ],
        '0926' => [
            'message' => 'Erreur interne',
            'description' => 'Erreur interne au sein du réseau bancaire.',
        ],
        '0927' => [
            'message' => 'Incohérence du MerchantTxId avec le PayId',
            'description' => 'Le paramètre MerchantTxId ne correspond pas au Computop PayID.',
        ],
        '0928' => [
            'message' => 'TxId manquant',
            'description' => 'Le paramètre TxID était manquant.',
        ],
        '0929' => [
            'message' => 'Url de redirection manquante',
            'description' => 'Le paramètre RedirectURL était manquant.',
        ],
        '0930' => [
            'message' => 'Banque hors ligne lors de la saisie du code PIN ou du TAn',
            'description' => 'La banque n\'était pas disponible lors de la saisie du code PIN et du TAN.',
        ],
        '0931' => [
            'message' => 'Délai d\'expiration dû à un code PIN ou TAN manquant',
            'description' => 'Délai d\'expiration lors de la saisie du code PIN ou du TAN.',
        ],
        '0932' => [
            'message' => 'Message bancaire compte en ligne invalide',
            'description' => 'Notification bancaire : le compte bancaire transmis ne prend pas en charge les services bancaires en ligne.',
        ],
        '0933' => [
            'message' => 'Transaction NON autorisée',
            'description' => 'La transaction n\'a pas pu être autorisée.',
        ],
        '0934' => [
            'message' => 'Statut de la transaction inconnu',
            'description' => 'Le statut final de la transaction n\'a pas pu être récupéré.',
        ],
        '0935' => [
            'message' => 'Échec du crédit - Le remboursement est en attente ou terminé pour cette transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0940' => [
            'message' => 'somme de contrôle incorrecte',
            'description' => 'Prélèvement ou virement bancaire refusé par chèque bancaire.',
        ],
        '0941' => [
            'message' => 'Banque inconnue',
            'description' => 'Prélèvement ou virement bancaire refusé par chèque bancaire.',
        ],
        '0942' => [
            'message' => 'Format invalide',
            'description' => 'Prélèvement ou virement bancaire refusé par chèque bancaire.',
        ],
        '0943' => [
            'message' => 'Banque non présentée',
            'description' => 'Prélèvement ou virement bancaire refusé par chèque bancaire.',
        ],
        '0944' => [
            'message' => 'Carte affichée',
            'description' => '(Carte verrouillée) Le débit ou le virement a été refusé par chèque bancaire.',
        ],
        '0946' => [
            'message' => 'Annulation par l\'utilisateur',
            'description' => 'La transaction a été annulée par le client, donc rejetée.',
        ],
        '0947' => [
            'message' => 'Données du compte invalides',
            'description' => 'Le prélèvement automatique ou le virement bancaire a été rejeté.',
        ],
        '0948' => [
            'message' => 'Carte bloquée',
            'description' => 'Transaction rejetée en raison d\'une carte bloquée.',
        ],
        '0949' => [
            'message' => 'Banque temporairement indisponible',
            'description' => 'Prélèvement ou virement refusé par la banque.',
        ],
        '0950' => [
            'message' => 'Échec de l\'autorisation',
            'description' => 'l\'autorisation a échoué, aucun autre détail connu.',
        ],
        '0951' => [
            'message' => 'La capture a échoué',
            'description' => 'La capture a échoué, aucun autre détail connu.',
        ],
        '0952' => [
            'message' => 'Échec du crédit',
            'description' => 'Le remboursement a échoué, aucun autre détail connu.',
        ],
        '0953' => [
            'message' => 'Échec du crédit',
            'description' => 'Le remboursement a échoué, le transfert d\'argent n\'est pas encore terminé',
        ],
        '0954' => [
            'message' => 'Échec du crédit - Car un dossier de réclamation existe sur cette transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0955' => [
            'message' => 'Échec du crédit - Échec du remboursement car le compte du destinataire est fermé',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0956' => [
            'message' => 'Échec du crédit - Le compte de la contrepartie est verrouillé ou inactif',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0957' => [
            'message' => 'Échec du crédit - Le montant du remboursement partiel doit être inférieur ou égal au montant restant',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0958' => [
            'message' => 'Échec du crédit - Cette transaction a déjà été entièrement remboursée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0959' => [
            'message' => 'Échec du crédit - Vous avez dépassé le délai imparti pour effectuer un remboursement sur cette transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0960' => [
            'message' => 'Échec du crédit - Le remboursement est en attente ou terminé pour cette transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0961' => [
            'message' => 'TicketNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0962' => [
            'message' => 'PassengerNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0963' => [
            'message' => 'Date du vol ',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0964' => [
            'message' => 'Origine1',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0965' => [
            'message' => 'Destination1',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0966' => [
            'message' => 'Transporteur1 ',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0970' => [
            'message' => 'ÉtatAdresse ',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0971' => [
            'message' => 'RueAdresse ',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0972' => [
            'message' => 'AdrHouseNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0973' => [
            'message' => 'AddrCountryCode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0974' => [
            'message' => 'AddrZipCode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0975' => [
            'message' => 'AdresseVille ',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0976' => [
            'message' => 'Nom',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0977' => [
            'message' => 'EntrepriseOuPersonne',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0978' => [
            'message' => 'Prénom manquant',
            'description' => 'Le paramètre dans la colonne B était manquant.',
        ],
        '0979' => [
            'message' => 'Salut manquant',
            'description' => 'Le paramètre dans la colonne B était manquant.',
        ],
        '0980' => [
            'message' => 'IDPayeur',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0981' => [
            'message' => 'trxType',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0982' => [
            'message' => 'Rétrofacturation',
            'description' => 'PayPal a notifié une rétrofacturation.',
        ],
        '0984' => [
            'message' => 'Annulé',
            'description' => 'PayPal (IPN) a transmis une transaction annulée.',
        ],
        '0985' => [
            'message' => 'En attente',
            'description' => 'La transaction n\'a pas été entièrement traitée.',
        ],
        '0986' => [
            'message' => 'ID DE BILLINGAGREEMENT',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0987' => [
            'message' => 'Méthode PayPal',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0988' => [
            'message' => 'TId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0989' => [
            'message' => 'Identifiant émetteur',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0990' => [
            'message' => 'Limite',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0991' => [
            'message' => 'Refusé en raison du risque',
            'description' => 'La transaction a été refusée par la banque acquéreuse en raison de contrôles frauduleux.',
        ],
        '0992' => [
            'message' => 'Non pris en charge',
            'description' => 'La fonctionnalité n\'était pas prise en charge.',
        ],
        '0993' => [
            'message' => 'FxCurrency',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '0994' => [
            'message' => 'Erreur technique',
            'description' => 'La transaction a échoué en raison d\'une erreur technique dans un système de données en aval.',
        ],
        '0996' => [
            'message' => 'propriété',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0997' => [
            'message' => 'Transtext',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '0999' => [
            'message' => 'code de récompense',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1000' => [
            'message' => 'Contrat d\'utilisation',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1001' => [
            'message' => 'Erreur structurelle',
            'description' => 'Le système backend a rejeté le paiement en raison d\'une erreur de format.',
        ],
        '1002' => [
            'message' => 'Erreur CRC',
            'description' => 'Le système backend a rejeté le paiement en raison d\'une faille de sécurité.',
        ],
        '1003' => [
            'message' => 'Flux perdu lors de la transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1004' => [
            'message' => 'Aucune connexion',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1005' => [
            'message' => 'Erreur de traitement des CRRes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1010' => [
            'message' => 'Erreur de traitement de VEReq',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1020' => [
            'message' => 'URL ACS invalide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1026' => [
            'message' => 'ACCDATE DE PARAMETRE INVALIDE ',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1030' => [
            'message' => 'Titulaire de carte ne participant pas',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1035' => [
            'message' => 'Titulaire de la carte impossible à authentifier',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1036' => [
            'message' => 'Valeur inscrite du titulaire de carte non prise en charge',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1040' => [
            'message' => 'Erreur de communication avec Visa Directory',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1050' => [
            'message' => 'Message inversé automatiquement',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1051' => [
            'message' => 'Erreur de traitement des PAR, réponse d\'erreur renvoyée par ACs',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1055' => [
            'message' => 'Erreur lors de la désérialisation des PAR',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1060' => [
            'message' => 'PARes manquants ou invalides',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1070' => [
            'message' => 'Erreur lors du traitement des VERes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1075' => [
            'message' => 'VERes vides rencontrés',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1080' => [
            'message' => 'Erreur lors du traitement de PAReq',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1085' => [
            'message' => 'Erreur lors du traitement de PAReq, le montant affiché n\'a pas pu être déterminé',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1090' => [
            'message' => 'Version PAReq non prise en charge demandée par ACs',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1100' => [
            'message' => 'erreur interne (données de carte erronées)',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1101' => [
            'message' => 'La transaction initiale n\'a pas pu être trouvée pour annulation',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1102' => [
            'message' => 'montant erroné pour annulation',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1103' => [
            'message' => 'Ursprungszahlung bereits storniert',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1104' => [
            'message' => 'uniquement les cartes de crédit pour les remboursements',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1105' => [
            'message' => 'Mauvais numéro de trace',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1106' => [
            'message' => 'Données de carte erronées',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1107' => [
            'message' => 'Carte expirée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1108' => [
            'message' => 'Inversion automatique impossible',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1109' => [
            'message' => 'Erreur lors de la lecture des données de la carte',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1110' => [
            'message' => 'Erreur persistante des informations de vérification',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1111' => [
            'message' => 'Fournisseur inconnu',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1112' => [
            'message' => 'Montant erroné',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1113' => [
            'message' => 'Veuillez effectuer un diagnostic',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1114' => [
            'message' => 'Transmettre le numéro de portable correct',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1115' => [
            'message' => 'Pas de numéro de portable (impression du code PIN)',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1120' => [
            'message' => 'Erreur persistante lors de la persistance des informations d\'authentification',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1125' => [
            'message' => 'Erreur persistante lors de la persistance des informations de recherche de transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1126' => [
            'message' => 'Erreur lors de la mise à jour des informations de transaction_Lookup',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1130' => [
            'message' => 'Erreur persistante lors de la persistance des informations VERes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1140' => [
            'message' => 'Erreur persistante des informations PARes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1150' => [
            'message' => 'Erreur persistante lors de la persistance des informations PAReq',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1160' => [
            'message' => 'Erreur persistante lors de la persistance des informations VEReq',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1170' => [
            'message' => 'Informations d\'erreur persistante',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1201' => [
            'message' => 'Erreur de configuration',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1202' => [
            'message' => 'Échec de l\'autorisation',
            'description' => 'Refusé par le système mpass',
        ],
        '1203' => [
            'message' => 'Transaction expirée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1204' => [
            'message' => 'Client non actif',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1205' => [
            'message' => 'Client inconnu',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1206' => [
            'message' => 'Client non autorisé',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1210' => [
            'message' => 'AboId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1211' => [
            'message' => 'AboAction',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1212' => [
            'message' => 'AboMontant',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1213' => [
            'message' => 'Intervalle',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1214' => [
            'message' => 'Actif',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1230' => [
            'message' => 'Date de relance',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1231' => [
            'message' => 'ReturnDebitDate',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1232' => [
            'message' => 'EventToken',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1233' => [
            'message' => 'IDClient',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1234' => [
            'message' => 'RefPayId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1235' => [
            'message' => 'ID du contrat',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1250' => [
            'message' => 'Erreur logique',
            'description' => 'Le système backend a rejeté la transaction en raison d\'une erreur système ou de configuration.',
        ],
        '1251' => [
            'message' => 'Erreur technique',
            'description' => 'Le système backend a rejeté la transaction en raison d\'une erreur système ou de configuration.',
        ],
        '1260' => [
            'message' => 'Erreur de sécurité',
            'description' => 'Le système backend a rejeté la transaction en raison d\'un contrôle de sécurité, détails dans la colonne B.',
        ],
        '1261' => [
            'message' => 'Paramètre CnB invalide',
            'description' => 'Le système backend a rejeté la transaction en raison d\'un contrôle de sécurité, détails dans la colonne B.',
        ],
        '1262' => [
            'message' => 'Mot de passe invalide',
            'description' => 'Le système backend a rejeté la transaction en raison d\'un contrôle de sécurité, détails dans la colonne B.',
        ],
        '1263' => [
            'message' => 'Accès refusé ',
            'description' => 'Le système backend a rejeté la transaction en raison d\'un contrôle de sécurité, détails dans la colonne B.',
        ],
        '1264' => [
            'message' => 'NationCode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1270' => [
            'message' => 'AuthInstant',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1271' => [
            'message' => 'MultiUsage',
            'description' => 'Indique si le VAN doit pouvoir être utilisé plusieurs fois jusqu\'au montant maximum d\'authentification. Si « faux », alors une seule transaction entre les montants Min et Max est autorisée',
        ],
        '1272' => [
            'message' => 'Montant Min',
            'description' => 'Le montant minimum pouvant être autorisé',
        ],
        '1273' => [
            'message' => 'MontantMax',
            'description' => 'Le montant maximum pouvant être autorisé',
        ],
        '1274' => [
            'message' => 'MerchantCategoryCode',
            'description' => 'Code de catégorie marchand exact du commerçant qui traitera la transaction',
        ],
        '1275' => [
            'message' => 'NomCatégorieMarchand',
            'description' => 'La catégorie générale à laquelle appartient le commerçant qui va traiter la transaction, parmi une liste prédéfinie',
        ],
        '1276' => [
            'message' => 'Pourcentage',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1277' => [
            'message' => 'SupportLogId',
            'description' => 'Un ID de journal de support qui peut être cité pour aider au dépannage',
        ],
        '1280' => [
            'message' => 'Marge',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1281' => [
            'message' => 'Source de financement',
            'description' => 'Source à qui doit être délivré.',
        ],
        '1282' => [
            'message' => 'ValeurCitation',
            'description' => 'Un taux de change.',
        ],
        '1283' => [
            'message' => 'Données Utilisateur',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1284' => [
            'message' => 'Données améliorées',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1285' => [
            'message' => 'Mise en page',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1287' => [
            'message' => 'bdDeviceToken',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1288' => [
            'message' => 'bdEmail',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1289' => [
            'message' => 'bdPhone',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1298' => [
            'message' => 'sdDeviceToken',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1299' => [
            'message' => 'téléphone Sd',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1300' => [
            'message' => 'CHStreet',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1301' => [
            'message' => 'CHCountryCode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1302' => [
            'message' => 'CHZipCode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1303' => [
            'message' => 'CHCity',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1320' => [
            'message' => 'SDPremierNom',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1321' => [
            'message' => 'SDLastName',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1322' => [
            'message' => 'SDSalutation',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1323' => [
            'message' => 'SDCompanyOrPerson',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1324' => [
            'message' => 'SDStreet',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1325' => [
            'message' => 'SDHouseNumber/ SDStreetNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1326' => [
            'message' => 'SDCountryCode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1327' => [
            'message' => 'SDZipcode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1328' => [
            'message' => 'SDVille',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1329' => [
            'message' => 'TitreSd',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1330' => [
            'message' => 'BDPremierNom',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1331' => [
            'message' => 'BDDastName',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1332' => [
            'message' => 'BDSalutation',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1333' => [
            'message' => 'BDCompanyOrPerson',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1334' => [
            'message' => 'BDStreet',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1335' => [
            'message' => 'BDHouseNumber/ BDStreetNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1336' => [
            'message' => 'BDCountryCode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1337' => [
            'message' => 'BDZipcode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1338' => [
            'message' => 'BDCité',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1339' => [
            'message' => 'BDTitre',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1340' => [
            'message' => 'BDStreet2',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1341' => [
            'message' => 'SDStreet2',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1342' => [
            'message' => 'SDTéléphone',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1343' => [
            'message' => 'SDMobileNon',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1344' => [
            'message' => 'SDCompany',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1345' => [
            'message' => 'Nom du titulaire',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1346' => [
            'message' => 'NuméroTax',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1347' => [
            'message' => 'BDCompany',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1348' => [
            'message' => 'Système Boutique',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1349' => [
            'message' => 'Version du système de boutique',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1350' => [
            'message' => 'INCONVENANCE NUMÉRO DE CARTE / EXPIRATIOn',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1351' => [
            'message' => 'INCOMPATISSEMENT NUMÉRO DE CARTE / DATE DE NAISSANCE',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1352' => [
            'message' => 'PAS d\'ÂGE LÉGAl',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1353' => [
            'message' => 'DATE DE NAISSANCE',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1354' => [
            'message' => 'PORTEUR DE CARTE',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1355' => [
            'message' => 'Vérifier l\'ID de la transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1356' => [
            'message' => 'NIVEAU DE RISQUE DE LA CARTE TROP ÉLEVÉ',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1357' => [
            'message' => 'CodeIDAcheteur',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1358' => [
            'message' => 'Données d\'expédition',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1359' => [
            'message' => 'bdMobileNo',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1360' => [
            'message' => 'KlarnaAction',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1361' => [
            'message' => 'SalaireAnnuel',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1362' => [
            'message' => 'Numéro de sécurité sociale',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1363' => [
            'message' => 'E-mail',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1364' => [
            'message' => 'Téléphone',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1365' => [
            'message' => 'Langue',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1366' => [
            'message' => 'Pays',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1367' => [
            'message' => 'Client non actif',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1368' => [
            'message' => 'Client inconnu',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1369' => [
            'message' => 'Client non autorisé',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1370' => [
            'message' => 'Données d\'adresse invalides',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1371' => [
            'message' => 'Problème de facture',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1372' => [
            'message' => 'N° de réservation',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1373' => [
            'message' => 'FactureNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1374' => [
            'message' => 'Erreur système Klarna',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1375' => [
            'message' => 'InvoiceFlag',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1376' => [
            'message' => 'Référence',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1377' => [
            'message' => 'IDCommande1',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1378' => [
            'message' => 'IDCommande2',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1379' => [
            'message' => 'CredNo',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1380' => [
            'message' => 'AUCUNE DÉCISION REÇUE',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1381' => [
            'message' => 'CLIENT INSÉCURISÉ',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1382' => [
            'message' => 'DATE DE NAISSANCE',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1383' => [
            'message' => 'DATE d\'ENREGISTREMENT',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1384' => [
            'message' => 'ID de commande',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1385' => [
            'message' => 'shAmount',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1386' => [
            'message' => 'Type de paiement',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1387' => [
            'message' => 'Remarque',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1388' => [
            'message' => 'Sous-Id',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1389' => [
            'message' => 'Catégorie de marchandises',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1390' => [
            'message' => 'Nationalité',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1391' => [
            'message' => 'Autoriser le marketing',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1392' => [
            'message' => 'AutoriserCredInq',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1393' => [
            'message' => 'Panier d\'achats',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1394' => [
            'message' => 'RPMéthode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1395' => [
            'message' => 'RPNuméro',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1396' => [
            'message' => 'Montant RPA',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1397' => [
            'message' => 'MaxRisque',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1398' => [
            'message' => 'ClassificationClient',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1399' => [
            'message' => 'SYSTÈME DE GESTION DES RISQUEs',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1400' => [
            'message' => 'OptionDate',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1401' => [
            'message' => 'Type de sortie',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1402' => [
            'message' => 'ID de suivi',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1403' => [
            'message' => 'ParcelService',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1404' => [
            'message' => 'PackstationId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1405' => [
            'message' => 'Nombre de jours',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1406' => [
            'message' => 'Reporté',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1407' => [
            'message' => 'ConditionsEtConditions',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1408' => [
            'message' => 'BcolumnserSessionId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1409' => [
            'message' => 'CookieId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1410' => [
            'message' => 'BcolumnserHeader',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1411' => [
            'message' => 'MandatFourni',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1412' => [
            'message' => 'ID de périphérique',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1413' => [
            'message' => 'Durée de paiement',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1414' => [
            'message' => 'Durée Shopping',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1415' => [
            'message' => 'Données de voyage',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1416' => [
            'message' => 'Liste des voyageurs',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1417' => [
            'message' => 'Résultat d\'authentification',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1418' => [
            'message' => 'CAVV',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1419' => [
            'message' => 'ACSId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1420' => [
            'message' => 'ACSIDHex',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1421' => [
            'message' => 'XID3DHEX',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1422' => [
            'message' => 'ECI3d',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1423' => [
            'message' => 'BoutiqueApiKey',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1424' => [
            'message' => 'Transaction arrêtée',
            'description' => 'Une valeur non valide pour AlphaAuthResult de VEReq a été soumise.',
        ],
        '1430' => [
            'message' => 'AUGMENTATION NON AUTORISÉE',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1431' => [
            'message' => 'INCONVENANCE DE transId',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1434' => [
            'message' => 'RIEN AUTORISÉ',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1450' => [
            'message' => 'Langue',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1451' => [
            'message' => 'IDClient',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1452' => [
            'message' => 'NouveauClient',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1453' => [
            'message' => 'BillPayAction',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1454' => [
            'message' => 'GtcValue',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1455' => [
            'message' => 'BillPayCapture',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1456' => [
            'message' => 'Téléphone',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1457' => [
            'message' => 'UtiliserBillingData',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1458' => [
            'message' => 'Nom de la société',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1459' => [
            'message' => 'Formulaire Légal',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1460' => [
            'message' => 'Historique des commandes',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1461' => [
            'message' => 'BpMéthode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1462' => [
            'message' => 'Erreur dans AddressData',
            'description' => 'Le système backend a rejeté la transaction en raison d\'une erreur technique, détails dans la colonne B.',
        ],
        '1463' => [
            'message' => 'Délai d\'activation',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1464' => [
            'message' => 'BpBaseAmount',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1465' => [
            'message' => 'Erreur système de paiement de facture',
            'description' => 'Le système backend a rejeté la transaction en raison d\'une erreur technique, détails dans la colonne B.',
        ],
        '1466' => [
            'message' => 'BpRateCount',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1467' => [
            'message' => 'InstalmentData',
            'description' => 'Billpay : les données pour le calcul des mensualités ont causé un problème.',
        ],
        '1468' => [
            'message' => 'étatsd',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1469' => [
            'message' => 'sdCompany',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1470' => [
            'message' => 'Type de distribution',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1471' => [
            'message' => 'DistributionBy',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1472' => [
            'message' => 'CodePays',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1473' => [
            'message' => 'Programme de carte',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1474' => [
            'message' => 'Points d\'utilisation',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1475' => [
            'message' => 'PointAmount',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1476' => [
            'message' => 'Campagne',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1477' => [
            'message' => 'JetonExt',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1478' => [
            'message' => 'Montant du versement',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1479' => [
            'message' => 'Date de versement',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1480' => [
            'message' => 'Agent utilisateur',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1490' => [
            'message' => 'bdAddressAddition',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1491' => [
            'message' => 'Informations client',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1500' => [
            'message' => 'Données de champ invalides',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1501' => [
            'message' => 'Données compagnon manquantes',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1502' => [
            'message' => 'Numéro de division invalide',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1505' => [
            'message' => 'Données de niveau 3 invalides',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1506' => [
            'message' => 'Données de paiement sécurisé invalides',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1507' => [
            'message' => 'Code de catégorie marchand invalide',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1510' => [
            'message' => 'Téléphone du service client manquant',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1513' => [
            'message' => 'Réponse invalide',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1514' => [
            'message' => 'Autorisation partielle non autorisée',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1515' => [
            'message' => 'Transaction en double',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1516' => [
            'message' => 'Montant du cashback invalide',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1517' => [
            'message' => 'Montant limite des transactions de division dépassé',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1518' => [
            'message' => 'Aucun enregistrement de carte',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1519' => [
            'message' => 'Déjà inversé',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1520' => [
            'message' => 'Incohérence du montant',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1521' => [
            'message' => 'Essayage excessif du code PIn',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1522' => [
            'message' => 'Dépasse la limite du nombre d\'activités',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1523' => [
            'message' => 'Le titulaire de la carte a demandé l\'arrêt de ce TRX',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1524' => [
            'message' => 'Le titulaire de la carte a demandé l\'arrêt de TOUS les TRX récurrents/à versements',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1525' => [
            'message' => 'Le titulaire de la carte a demandé l\'arrêt de TOUS les TRX',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1526' => [
            'message' => 'Nouvelle carte émise',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1527' => [
            'message' => 'l\'émetteur a signalé le compte comme étant une fraude présumée',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1528' => [
            'message' => 'Institution non valide',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1529' => [
            'message' => 'l\'émetteur n\'autorise pas le type trx',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1531' => [
            'message' => 'Impossible de valider l\'enregistrement d\'autorisation de débit',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1532' => [
            'message' => 'Impossible de traiter la transaction',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1533' => [
            'message' => 'Le compte bancaire a été fermé',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1534' => [
            'message' => 'CID AMEX invalide',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1536' => [
            'message' => 'Le compte n\'existe pas',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1537' => [
            'message' => 'Refusé en utilisant les règles de remplacement',
            'description' => 'Le système backend a rejeté la transaction, détails dans la colonne B.',
        ],
        '1540' => [
            'message' => 'Surcharge',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1541' => [
            'message' => 'StepUpForcé',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1542' => [
            'message' => 'SoftDecline',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1543' => [
            'message' => 'Langue',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1600' => [
            'message' => 'telbiz',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1601' => [
            'message' => 'telmobil',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1602' => [
            'message' => 'telpriv',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1603' => [
            'message' => 'sozversnr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1604' => [
            'message' => 'emailadranb',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1605' => [
            'message' => 'emailadrsyn',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1606' => [
            'message' => 'emailadrtld',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1607' => [
            'message' => 'okvip',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1608' => [
            'message' => 'okkndart',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1609' => [
            'message' => 'la1nom',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1610' => [
            'message' => 'la1vorname',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1611' => [
            'message' => 'la1strasse',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1612' => [
            'message' => 'la1hno',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1613' => [
            'message' => 'la1ort',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1614' => [
            'message' => 'la1plz',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1615' => [
            'message' => 'la1land',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1616' => [
            'message' => 'la1gebdat',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1617' => [
            'message' => 'kdkndktonr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1618' => [
            'message' => 'kdinkassostand',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1619' => [
            'message' => 'kdktostand',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1620' => [
            'message' => 'kdjemkomplettgezkz',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1621' => [
            'message' => 'kdnochnichtfaellbetr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1622' => [
            'message' => 'kdueberfaellbetr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1623' => [
            'message' => 'kdktostartdat',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1624' => [
            'message' => 'kdktosperrkz',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1625' => [
            'message' => 'kdkndktoart',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1626' => [
            'message' => 'kdkredlin',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1627' => [
            'message' => 'statut kdmahn',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1628' => [
            'message' => 'kdkredlinauftr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1629' => [
            'message' => 'kdaltkndkz',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1630' => [
            'message' => 'adapté',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1631' => [
            'message' => 'annonce',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1632' => [
            'message' => 'adzahlungsart',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1633' => [
            'message' => 'adsonderartkz',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1634' => [
            'message' => 'adlieferart',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1635' => [
            'message' => 'annonces',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1636' => [
            'message' => 'adauftragsnr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1637' => [
            'message' => 'adratenzahl',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1638' => [
            'message' => 'date de travail',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1700' => [
            'message' => 'Appareil',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1701' => [
            'message' => 'KSn',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1702' => [
            'message' => 'TrackEnc',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1703' => [
            'message' => 'Périphérique invalide',
            'description' => 'Le numéro de série du matériel (périphérique) n\'était pas valide.',
        ],
        '1704' => [
            'message' => 'Échec du décryptage du point de vente',
            'description' => 'Le décryptage des données de la piste a échoué.',
        ],
        '1705' => [
            'message' => 'Données de piste invalides',
            'description' => 'Les données de la piste n\'ont pas pu être lues.',
        ],
        '1710' => [
            'message' => 'prosigncert',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1711' => [
            'message' => 'terminalcrt',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1712' => [
            'message' => 'tempkeyloadcrt',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1713' => [
            'message' => 'suggestediksn',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1714' => [
            'message' => 'ProduitNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1715' => [
            'message' => 'Localisation',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1716' => [
            'message' => 'Déjà effectué',
            'description' => 'Action déjà effectuée',
        ],
        '1717' => [
            'message' => 'ServiceData',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1750' => [
            'message' => 'EMVDonnées',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1751' => [
            'message' => 'Échec de la signature POs',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1752' => [
            'message' => 'POSTerminalId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1753' => [
            'message' => 'Type de message',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1754' => [
            'message' => 'DMACKSn',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1755' => [
            'message' => 'DMAC',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1756' => [
            'message' => 'DataKSn',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1757' => [
            'message' => 'CCNrEnc',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1758' => [
            'message' => 'CCSeqNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1759' => [
            'message' => 'dccStatus',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1760' => [
            'message' => 'DateLocale',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1761' => [
            'message' => 'Heure Locale',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1762' => [
            'message' => 'ReçuNr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1763' => [
            'message' => 'Mode Processus',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1764' => [
            'message' => 'Mode d\'entrée',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1765' => [
            'message' => 'TerminalDonnées',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1766' => [
            'message' => 'Piste2',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1767' => [
            'message' => 'PIn',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1768' => [
            'message' => 'Différence de longueur du message',
            'description' => 'Il y a une inadéquation entre la longueur du message et la valeur fournie dans l\'en-tête.',
        ],
        '1769' => [
            'message' => 'Point de terminaison',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1770' => [
            'message' => 'Code de traitement',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1771' => [
            'message' => 'Code de tri bancaire',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1772' => [
            'message' => 'ConditionCode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1801' => [
            'message' => 'DATE DE FULFILLMENT PARAM INVALIDE',
            'description' => 'La date d\'exécution transmise était invalide ou future.',
        ],
        '1802' => [
            'message' => 'INCOMPATENCE DE DEVISEs',
            'description' => 'La devise transmise ne correspond pas à la transaction initiale.',
        ],
        '1803' => [
            'message' => 'PARAMETRE INVALIDE TaxChargeAmount',
            'description' => 'Le montant de la taxe transmise ne correspond pas aux spécifications.',
        ],
        '1804' => [
            'message' => 'PARAMETRE INVALIDE ChargeAmount',
            'description' => 'Le montant des frais transmis ne correspond pas aux spécifications.',
        ],
        '1805' => [
            'message' => 'ARTICLENR INVALIDE',
            'description' => 'l\'article faisant référence au numéro d\'article est introuvable.',
        ],
        '1806' => [
            'message' => 'REMPLACEMENT DE QUANTITÉ',
            'description' => 'La quantité livrée a dépassé la quantité autorisée.',
        ],
        '1808' => [
            'message' => 'ID DE COMMANDE INVALIDE',
            'description' => 'l\'ID de commande transmis n\'était pas valide.',
        ],
        '1809' => [
            'message' => 'PARAM MANQUANT ACHATCONTRACTId',
            'description' => 'Le paramètre dans la colonne B était manquant.',
        ],
        '1810' => [
            'message' => 'CODE PAYS PARAM INVALIDE',
            'description' => 'Le paramètre dans la colonne B n\'était pas valide.',
        ],
        '1811' => [
            'message' => 'ServiceLevel in ArticleList n\'est pas utile',
            'description' => 'Le paramètre transmis ne correspond pas aux spécifications.',
        ],
        '1812' => [
            'message' => 'Méthode d\'expédition non disponible',
            'description' => 'Le paramètre transmis ne correspond pas aux spécifications.',
        ],
        '1815' => [
            'message' => 'RIEN À INVERSER',
            'description' => 'l\'inversion n\'était pas possible, aucune autorisation initiale disponible.',
        ],
        '1818' => [
            'message' => 'commande annulée',
            'description' => 'Amazon a signalé que la commande a été annulée.',
        ],
        '1821' => [
            'message' => 'Incohérence de signature',
            'description' => 'La signature transmise par Amazon n\'est pas valide.',
        ],
        '1822' => [
            'message' => 'Le message IOPN existe déjà',
            'description' => 'Le message transmis par Amazon a déjà été reçu et traité.',
        ],
        '1830' => [
            'message' => 'Erreur lors de GetPurchaseContract',
            'description' => 'l\'appel de la fonction "GetPurchaseContract" a provoqué l\'erreur.',
        ],
        '1831' => [
            'message' => 'Erreur lors de SetPurchaseItems',
            'description' => 'l\'appel de la fonction "SetPurchaseItems" a provoqué l\'erreur.',
        ],
        '1832' => [
            'message' => 'Erreur lors de la réalisation du contrat d\'achat',
            'description' => 'l\'appel de la fonction "CompletePurchaseContract" a provoqué l\'erreur.',
        ],
        '1833' => [
            'message' => 'PurchaseContract annulé',
            'description' => 'La commande a été annulée.',
        ],
        '1834' => [
            'message' => 'Contrat d\'achat expiré',
            'description' => 'La commande a expiré.',
        ],
        '1835' => [
            'message' => 'ALERTE AMAZOn',
            'description' => 'Amazon a signalé une erreur lors du traitement du paiement. Le code de résultat Amazon a également été transmis.',
        ],
        '1836' => [
            'message' => 'ALERTE AMAZOn',
            'description' => 'Amazon a signalé un avertissement lors du traitement du paiement. Il est recommandé de vérifier le paiement manuellement. Le code de résultat Amazon a également été transmis.',
        ],
        '1837' => [
            'message' => 'Erreur lors de SetContractCharges',
            'description' => 'l\'appel de la fonction "SetContractCharges" a provoqué l\'erreur.',
        ],
        '1850' => [
            'message' => 'NomProduit',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1851' => [
            'message' => 'DemandeRaison',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1852' => [
            'message' => 'Titre',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1853' => [
            'message' => 'Montant de base',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1854' => [
            'message' => 'Devise de base',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1855' => [
            'message' => 'Destinataire',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1856' => [
            'message' => 'IdCitation',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1857' => [
            'message' => 'MontantLocal',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1858' => [
            'message' => 'Devise Locale',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1859' => [
            'message' => 'ressaisir la transaction',
            'description' => 'La transaction a déjà été traitée',
        ],
        '1860' => [
            'message' => 'Numéro de versement',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1861' => [
            'message' => 'Expiration',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1862' => [
            'message' => 'TypeAcc',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1863' => [
            'message' => 'Cartes acceptées',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1864' => [
            'message' => 'Programme de récompense',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1865' => [
            'message' => 'AuthLevelBasic',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1866' => [
            'message' => 'MasterPassId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1867' => [
            'message' => 'ID de transaction',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1868' => [
            'message' => 'Déjà autorisé',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1869' => [
            'message' => 'SuppressShippingAddress',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1870' => [
            'message' => 'URLOrigine',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1871' => [
            'message' => 'LongAccessToken',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1872' => [
            'message' => 'PairingToken',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1873' => [
            'message' => 'PairingVerifier',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1874' => [
            'message' => 'RequestedDataTypes',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1875' => [
            'message' => 'CheckoutToken',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1876' => [
            'message' => 'CheckoutVerifier',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1877' => [
            'message' => 'Url de paiement',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1880' => [
            'message' => 'Erreur lors de la génération de l\'EId',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1881' => [
            'message' => 'Texte de la facture',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1882' => [
            'message' => 'TrxIdCount',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1883' => [
            'message' => 'addata1',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1884' => [
            'message' => 'fonds insuffisants',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1885' => [
            'message' => 'Consentement',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1886' => [
            'message' => 'PurchaseCountryCode',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1887' => [
            'message' => 'URLCheckout',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1888' => [
            'message' => 'URLConfirm',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1889' => [
            'message' => 'Conditions URl',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1900' => [
            'message' => 'ID du mandat',
            'description' => 'Le mandat n\'a pas pu être créé.',
        ],
        '1901' => [
            'message' => 'Nom du mandat',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1902' => [
            'message' => 'Paramètre de débit',
            'description' => 'Aucun des paramètres nécessaires n\'a été soumis.',
        ],
        '1903' => [
            'message' => 'Date désignée incorrecte',
            'description' => 'Le paiement ne peut être exécuté au rendez-vous demandé.',
        ],
        '1904' => [
            'message' => 'IDDébiteur',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1905' => [
            'message' => 'Identifiant fiscal',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1906' => [
            'message' => 'IDBoutique',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1907' => [
            'message' => 'Date de facture',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1908' => [
            'message' => 'Montant net',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1909' => [
            'message' => 'Montant Net1',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1910' => [
            'message' => 'CodeTax1',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1911' => [
            'message' => 'MontantTax1',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1912' => [
            'message' => 'Montant Net2',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1913' => [
            'message' => 'CodeTax2',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1914' => [
            'message' => 'MontantTax2',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1915' => [
            'message' => 'Montant Net3',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1916' => [
            'message' => 'CodeTax3',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1917' => [
            'message' => 'MontantTax3',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1918' => [
            'message' => 'ID du panier d\'achat',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1919' => [
            'message' => 'Date de création',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1920' => [
            'message' => 'Date d\'échéance',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1921' => [
            'message' => 'FSK',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1922' => [
            'message' => 'groupe client',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1923' => [
            'message' => 'IDVat',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1924' => [
            'message' => 'BenefitPeriodFrom',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1925' => [
            'message' => 'BenefitPeriodTill',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1926' => [
            'message' => 'titre du document',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1927' => [
            'message' => 'ID de compte',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1928' => [
            'message' => 'DeliveryChannel',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1929' => [
            'message' => 'ClasseMontant',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1930' => [
            'message' => 'DtOfSgntr',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1931' => [
            'message' => 'IDMandat',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1932' => [
            'message' => 'MdtSeqType',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1933' => [
            'message' => 'AccVerify',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1934' => [
            'message' => 'IDFSCannel',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1935' => [
            'message' => 'FSServiceId',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1936' => [
            'message' => 'MiddleName',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1937' => [
            'message' => 'AdresseAddition',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1938' => [
            'message' => 'Téléphone de travail',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1939' => [
            'message' => 'sdMiddleName',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1940' => [
            'message' => 'sdAddressAddition',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1941' => [
            'message' => 'sdWorkPhone',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1942' => [
            'message' => 'sdEMail',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1943' => [
            'message' => 'Demande invalide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1944' => [
            'message' => 'AccessToken',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1945' => [
            'message' => 'IdRéférenceCommande',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1946' => [
            'message' => 'ID de transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1947' => [
            'message' => 'Expiration',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1948' => [
            'message' => 'Portée',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1949' => [
            'message' => 'Mode de paiement invalide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1950' => [
            'message' => 'La commande n\'a pas été confirmée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1951' => [
            'message' => 'Commande expirée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1952' => [
            'message' => 'Autorisations maximales capturées',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1953' => [
            'message' => 'Fermé',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1954' => [
            'message' => 'Rejeté',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1955' => [
            'message' => 'Autorisation expirée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1956' => [
            'message' => 'Max Remboursements Traités',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '1957' => [
            'message' => 'Type de jeton',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '1990' => [
            'message' => 'URLRetour',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '2000' => [
            'message' => 'ERREUR DE DÉPISTAGE DE LA FRAUDE',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2001' => [
            'message' => 'REFUSÉ PAR DÉPISTAGE DE LA FRAUDE',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2002' => [
            'message' => 'DÉPISTAGE DE LA FRAUDE AUCUNE RÉPONSE',
            'description' => 'Le système backend (par exemple, l\'acquisition, les systèmes de cartes ou l\'API des systèmes de paiement) ne répondait pas.',
        ],
        '2003' => [
            'message' => 'Erreur interne : impossible de gérer le type de message pour le moment',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2004' => [
            'message' => 'Exception de format de demande de message',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2005' => [
            'message' => 'Erreur interne : exception de format de réponse au message',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2006' => [
            'message' => 'Version du message non prise en charge',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2007' => [
            'message' => 'Groupe de messages désactivé',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2008' => [
            'message' => 'Système indisponible pour la maintenance',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2009' => [
            'message' => 'Format de requête invalide : XML invalide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2010' => [
            'message' => 'Format de requête invalide : requête vide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2020' => [
            'message' => 'Mot de passe de transaction invalide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2021' => [
            'message' => 'Le profil marchand n\'est pas configuré avec un mot de passe de transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2030' => [
            'message' => 'Impossible de traiter la transaction avec la version API spécifiée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2101' => [
            'message' => 'TransDate',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2102' => [
            'message' => 'TransTime',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '2201' => [
            'message' => 'Mode Mps',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '2202' => [
            'message' => 'Appel de sécurité',
            'description' => 'l\'émetteur a refusé le paiement, veuillez appeler la sécurité',
        ],
        '2203' => [
            'message' => 'EnregistrementDevice',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '2204' => [
            'message' => 'AdrIP d\'enregistrement',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '2206' => [
            'message' => 'Délai d\'expiration',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '2306' => [
            'message' => 'Cut-off en cours',
            'description' => 'Cut-off en cours',
        ],
        '2321' => [
            'message' => 'Dépasse la limite du montant de retrait',
            'description' => 'Dépasse la limite du montant de retrait',
        ],
        '2323' => [
            'message' => 'Dépasse la limite de fréquence de retrait',
            'description' => 'Dépasse la limite de fréquence de retrait',
        ],
        '2381' => [
            'message' => 'Carte bloquée',
            'description' => 'Carte bloquée',
        ],
        '2382' => [
            'message' => 'Compte bloqué',
            'description' => 'Compte bloqué',
        ],
        '4000' => [
            'message' => 'Erreur lors de la validation de la valeur de l\'ID du processeur',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4010' => [
            'message' => 'Erreur lors de la validation de la valeur du bac de l\'acquéreur',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4020' => [
            'message' => 'Erreur lors de la validation de la valeur de l\'identifiant du marchand',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4025' => [
            'message' => 'Erreur lors de la validation du type de transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4030' => [
            'message' => 'Erreur lors de la validation de la valeur PAn',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4040' => [
            'message' => 'Erreur lors de la validation de la valeur de la version 3-D Secure',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4050' => [
            'message' => 'Erreur lors de la validation du mot de passe du commerçant',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4070' => [
            'message' => 'Erreur lors de la validation du nom du marchand',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4080' => [
            'message' => 'Erreur lors de la validation de l\'URL du marchand',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4090' => [
            'message' => 'Erreur lors de la validation des informations d\'expiration de la carte de crédit',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4092' => [
            'message' => 'Erreur lors de la validation des informations d\'expiration du mois et du numéro de carte',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4093' => [
            'message' => 'Erreur lors de la validation des informations d\'expiration du numéro de carte, de l\'année',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4094' => [
            'message' => 'Erreur lors de la validation du numéro de carte',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4140' => [
            'message' => 'Erreur lors de la validation de l\'URL ACs',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4150' => [
            'message' => 'Erreur lors de la validation du protocole de paiement',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4160' => [
            'message' => 'Erreur lors de la validation de Purchase.date',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4170' => [
            'message' => 'Erreur lors de la validation de Purchase.xid',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4180' => [
            'message' => 'Erreur lors de la validation de Purchase.purchAmount',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4190' => [
            'message' => 'Erreur lors de la validation du montant de l\'achat',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4200' => [
            'message' => 'Erreur lors de la validation de la description d\'achat',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4220' => [
            'message' => 'Commerçant non configuré pour traiter la marque de carte de crédit transmise',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4230' => [
            'message' => 'Marque d\'élément requise, introuvable dans le message',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4240' => [
            'message' => 'Le commerçant ne parvient pas à traiter les transactions, n\'est pas actif',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4243' => [
            'message' => 'Le marchand ne parvient pas à traiter les transactions, configuration de l\'initiative de paiement introuvable',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4245' => [
            'message' => 'Le marchand ne peut pas traiter les transactions, initiative de paiement non active',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4250' => [
            'message' => 'Erreur lors de la validation de l\'ID du processeur',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4260' => [
            'message' => 'Erreur lors de la validation du numéro de commande',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4265' => [
            'message' => 'Erreur lors de la validation de l\'ID de transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4267' => [
            'message' => 'Message d\'erreur de validation, le numéro de commande est vide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4268' => [
            'message' => 'Message d\'erreur de validation, l\'ID de transaction est vide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4270' => [
            'message' => 'Erreur lors de la validation du montant brut',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4271' => [
            'message' => 'Erreur lors de la validation du montant de la transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4280' => [
            'message' => 'Erreur lors de la validation du code de devise',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4282' => [
            'message' => 'Erreur lors de la validation du code de devise, non pris en charge sur le type de transaction',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4310' => [
            'message' => 'Erreur lors de l\'analyse des éléments du message VERes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4320' => [
            'message' => 'Attribut critique invalide dans un élément non défini',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4330' => [
            'message' => 'Erreur lors de la validation de la réponse d\'inscription',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4331' => [
            'message' => 'Erreur lors de la validation du statut d\'authentification',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4340' => [
            'message' => 'Erreur lors de la validation du code iReq',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4350' => [
            'message' => 'Erreur lors de la validation de l\'extension du message',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4360' => [
            'message' => 'Erreur lors de la validation des extensions de messages critiques',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4370' => [
            'message' => 'Erreur lors de la validation de MsgId dans les messages VEReq et VERes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4375' => [
            'message' => 'Erreur lors de la validation de la valeur récurrente',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4380' => [
            'message' => 'Erreur lors de la validation de la valeur de fréquence récurrente',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4390' => [
            'message' => 'Erreur lors de la validation de la date de fin de la fréquence récurrente',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4400' => [
            'message' => 'Erreur lors de l\'analyse des éléments du message PARes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4410' => [
            'message' => 'Erreur lors de la validation du code fournisseur',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4420' => [
            'message' => 'Erreur lors de la validation de la valeur PAN, ne doit pas contenir de zéros',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4430' => [
            'message' => 'Erreur lors de la validation de la valeur TX.cavv, ne devrait pas être présente',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4435' => [
            'message' => 'Erreur lors de la validation de la valeur TX.cavv',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4440' => [
            'message' => 'Erreur lors de la validation de la valeur TX.eci, ne devrait pas être présente',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4445' => [
            'message' => 'Erreur lors de la validation de la valeur TX.eci',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4450' => [
            'message' => 'Erreur lors de la validation de la valeur TX.cavvAlgorithm, ne devrait pas être présente',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4455' => [
            'message' => 'Erreur lors de la validation de la valeur TX.cavvAlgorithm',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4460' => [
            'message' => 'Erreur lors de la validation de l\'identifiant du message',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4470' => [
            'message' => 'Erreur de validation (MsgId, Xid, Purchase.currency, Purchase.exponent, Purchase.purchAmount) dans les messages PAReq et PARes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4480' => [
            'message' => 'Erreur lors de la validation de l\'identifiant PARes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4490' => [
            'message' => 'Erreur lors de la validation du code de devise ISO',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4500' => [
            'message' => 'Erreur lors de la validation de l\'exposant de devise ISO',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4510' => [
            'message' => 'Erreur lors de la validation de TX.time',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4520' => [
            'message' => 'Erreur lors de la validation de la valeur du versement',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4530' => [
            'message' => 'Erreur lors de la validation de la valeur du versement, doit être supérieure à 1',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4531' => [
            'message' => 'Erreur lors de la validation de la valeur du type de paiement',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4535' => [
            'message' => 'Erreur lors de la validation de la valeur de l\'adresse IP, doit être formatée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4536' => [
            'message' => 'Erreur lors de la validation du code pays ISO 3166',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4537' => [
            'message' => 'Erreur lors de la validation de la valeur transId',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4540' => [
            'message' => 'Erreur lors de la validation de l\'identifiant PARes et de l\'URI de référence',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4550' => [
            'message' => 'Erreur de validation des PARes, attribut xmlns Message.Signature.CanonicalizationMethod non valide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4560' => [
            'message' => 'Erreur de validation des PARes, attribut xmlns Message.Signature.SignatureMethod non valide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4570' => [
            'message' => 'Erreur de validation des PARes, attribut xmlns Message.Signature.SignedInfo non valide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4580' => [
            'message' => 'Erreur de validation des PARes, attribut Message.Signature xmlns non valide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4590' => [
            'message' => 'Erreur lors de la validation des PAR, valeur de signature numérique invalide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4591' => [
            'message' => 'Échec de la vérification de la signature',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4600' => [
            'message' => 'Erreur lors de la validation des PARes, attribut d\'algorithme Message.Signature.CanonicalizationMethod non valide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4610' => [
            'message' => 'Erreur lors de la validation de MsgId dans les messages CRReq et CRRes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4620' => [
            'message' => 'Erreur lors de la validation de MsgId dans les messages CRRes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4630' => [
            'message' => 'Erreur lors de la validation du message CRRes, message introuvable',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4640' => [
            'message' => 'Erreur lors de la validation des éléments du message CRRes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4650' => [
            'message' => 'Erreur lors de la validation des CRRes, valeurs de plage de début de carte non valides',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4660' => [
            'message' => 'Erreur lors de la validation des CRRes, valeurs de plage de fin de carte non valides',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4670' => [
            'message' => 'Erreur lors de la validation des CRRes, actions de plage de cartes non valides',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4680' => [
            'message' => 'Erreur de validation des CRRes, numéro de série invalide',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4685' => [
            'message' => 'Erreur lors de la validation des CRRes, numéro de série introuvable',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4690' => [
            'message' => 'Rencontré et dans les CRRes, aucune action entreprise sur le cache de portée de cartes',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4700' => [
            'message' => 'Erreur lors de la validation des CRRes, élément de version introuvable',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4710' => [
            'message' => 'Erreur lors de la validation des CRRes, élément d\'identification du message introuvable',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4720' => [
            'message' => 'Erreur lors de la validation des CRRes, élément ThreeDSecure introuvable',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4761' => [
            'message' => 'Erreur lors de la validation de TermURl',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4762' => [
            'message' => 'Erreur lors de la validation de la charge utile',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4770' => [
            'message' => 'Erreur lors de la validation de l\'octet de contrôle AAV',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4780' => [
            'message' => 'Erreur lors de la validation du montant de la vente AAV',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4790' => [
            'message' => 'Erreur lors de la validation de la valeur de troncature du montant de la vente AAV',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4800' => [
            'message' => 'Erreur lors de la validation du code de devise de la transaction AAV',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4810' => [
            'message' => 'Erreur lors de la validation du hachage du nom du marchand',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4820' => [
            'message' => 'Erreur lors de la validation du tampon de transaction du commerçant',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '4910' => [
            'message' => 'Données d\'authentification non disponibles',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9000' => [
            'message' => 'Impossible de communiquer avec MAPS Server',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9010' => [
            'message' => 'Erreur lors de l\'analyse de la réponse XMl',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9020' => [
            'message' => 'Le nom ou l\'adresse du serveur n\'a pas pu être résolu',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9030' => [
            'message' => 'l\'URL n\'utilise pas de protocole reconnu',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9040' => [
            'message' => 'Demande HTTP(S) expirée ou délai d\'expiration non valide spécifié',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9100' => [
            'message' => 'Erreur de traitement CRReq',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9101' => [
            'message' => 'Erreur de traitement de la demande de message',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9102' => [
            'message' => 'Message de demande de recherche d\'erreur de traitement',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9103' => [
            'message' => 'Erreur de traitement du message de demande d\'authentification',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9110' => [
            'message' => 'Version PAReq non prise en charge demandée par ACs',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9130' => [
            'message' => 'Le mode de traitement actuel ne prend pas en charge le type de message spécifié',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9131' => [
            'message' => 'Le message système ne prend pas en charge la version de message spécifiée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9135' => [
            'message' => 'Vérifier le numéro de commande',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9137' => [
            'message' => 'Incohérence entre l\'initiative de paiement et le type de message',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9138' => [
            'message' => 'Initiative de paiement non prise en charge dans la version de message spécifiée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9139' => [
            'message' => 'Incohérence entre le type de carte et le type de message',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9140' => [
            'message' => 'Version du message non prise en charge',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9141' => [
            'message' => 'Erreur générale du message d\'authentification',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9160' => [
            'message' => 'Initiative de paiement non prise en charge',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9161' => [
            'message' => 'Initiative de paiement prise en charge, mais non activée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '9201' => [
            'message' => 'Type de message non pris en charge',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '002A' => [
            'message' => 'Nom/ Prénom',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '002B' => [
            'message' => 'AdrStreetNr/ HNo',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '002C' => [
            'message' => 'EMail',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '002d' => [
            'message' => 'MontantTax',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '002E' => [
            'message' => 'Liste d\'articles',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '002F' => [
            'message' => 'PROMOTION PARAM INVALIDE',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '003A' => [
            'message' => 'AdrStreet/ Straße',
            'description' => 'Un des paramètres de la colonne B a causé un problème.',
        ],
        '003B' => [
            'message' => 'AddrZip/PLZ',
            'description' => 'Un des paramètres de la colonne B a causé un problème.',
        ],
        '003C' => [
            'message' => 'AdrCity/ Ort',
            'description' => 'Un des paramètres de la colonne B a causé un problème.',
        ],
        '003d' => [
            'message' => 'Adresse IP invalide',
            'description' => 'l\'adresse IP n\'était pas valide.',
        ],
        '003E' => [
            'message' => 'ID de demande',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '003F' => [
            'message' => 'montant3d',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '004A' => [
            'message' => 'BIC NON LISTE',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '004B' => [
            'message' => 'INCONVENANCE IBAN CODE BANQUE',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '011A' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres des chèques IP dans Securepay (nombre maximum par jour).',
        ],
        '011B' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres des chèques-cartes dans Securepay (nombre maximum par jour).',
        ],
        '011C' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du chèque de montant combinés aux contrôles IP dans Securepay (nombre maximum par jour).',
        ],
        '011d' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du chèque de montant combinés aux contrôles IP dans Securepay (nombre maximum par jour).',
        ],
        '011E' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison du paramétrage des contrôles (numéro de référence identique et/ou transId) dans Securepay (limite par jour).',
        ],
        '011F' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres de contrôle de la carte/IP dans Securepay (limite par jour).',
        ],
        '011G' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID-Check dans Securepay (limite par jour).',
        ],
        '011H' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID/Card-Check dans Securepay (limite par jour).',
        ],
        '011I' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID/IP-Check dans Securepay (limite par jour).',
        ],
        '012A' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres de contrôle IP dans Securepay (nombre maximum par semaine).',
        ],
        '012B' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres de contrôle de carte dans Securepay (nombre maximum par semaine).',
        ],
        '012C' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du chèque de montant combiné au contrôle IP dans Securepay (nombre maximum par semaine).',
        ],
        '012d' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du chèque de montant combiné au contrôle de carte dans Securepay (limite par semaine).',
        ],
        '012E' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison du paramétrage du contrôle des paramètres (numéro de référence identique et/ou transId) dans Securepay (limite par semaine).',
        ],
        '012F' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres de la carte/du contrôle IP dans Securepay (limite par semaine).',
        ],
        '012G' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID-Check dans Securepay (limite par semaine).',
        ],
        '012H' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID/Card-Check dans Securepay (limite par semaine).',
        ],
        '012I' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID/IP-Check dans Securepay (limite par semaine).',
        ],
        '013A' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du contrôle IP dans Securepay (limite mensuelle).',
        ],
        '013B' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres de contrôle de carte dans Securepay (limite mensuelle).',
        ],
        '013C' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du contrôle de montant combinés au contrôle IP dans Securepay (limite par mois).',
        ],
        '013d' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du chèque de montant combiné avec le chèque de carte dans Securepay (limite par mois).',
        ],
        '013E' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison du paramétrage du contrôle des paramètres (numéro de référence identique et/ou transId) dans Securepay (limite mensuelle).',
        ],
        '013F' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres de la carte/du contrôle IP dans Securepay (limite mensuelle).',
        ],
        '013G' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID-Check dans Securepay (limite mensuelle).',
        ],
        '013H' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID/Card-Check dans Securepay (limite mensuelle).',
        ],
        '013I' => [
            'message' => 'REFUSÉ POUR FRAUDE',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID/IP-Check dans Securepay (limite mensuelle).',
        ],
        '014A' => [
            'message' => 'REFUSÉ PAR SECUREPAY',
            'description' => 'Paiement rejeté car l\'adresse IP est temporairement bloquée en raison des paramètres de Securepay. Vous pouvez débloquer l\'adresse IP via les paramètres Securepay dans Analytics.',
        ],
        '014B' => [
            'message' => 'REFUSÉ PAR SECUREPAY',
            'description' => 'Paiement rejeté car le numéro de carte est temporairement bloqué en raison des paramètres de Securepay. Vous pouvez débloquer la carte dans les paramètres Securepay dans Analytics.',
        ],
        '014C' => [
            'message' => 'REFUSÉ PAR SECUREPAY',
            'description' => 'Paiement rejeté car l\'adresse IP est temporairement bloquée en raison des paramètres de Securepay (montant limite dépassé). Vous pouvez débloquer l\'adresse IP dans les paramètres Securepay dans Analytics.',
        ],
        '014d' => [
            'message' => 'REFUSÉ PAR SECUREPAY',
            'description' => 'Paiement rejeté car la carte est temporairement bloquée en raison des paramètres de Securepay (montant limite dépassé). Vous pouvez débloquer la carte dans les paramètres Securepay dans Analytics.',
        ],
        '014E' => [
            'message' => 'REFUSÉ PAR SECUREPAY',
            'description' => 'Paiement rejeté car la valeur du paramètre est temporairement bloquée en raison des paramètres de Securepay (limite dépassée). Vous pouvez débloquer la valeur du paramètre dans les paramètres Securepay dans Analytics.',
        ],
        '014F' => [
            'message' => 'REFUSÉ PAR SECUREPAY',
            'description' => 'Paiement rejeté car l\'adresse IP est temporairement bloquée en raison des paramètres de Securepay (limite de cartes provenant d\'une adresse IP identique dépassée). Vous pouvez débloquer l\'adresse IP dans les paramètres Securepay dans Analytics.',
        ],
        '014G' => [
            'message' => 'REFUSÉ PAR SECUREPAY',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID-Check dans Securepay.',
        ],
        '014H' => [
            'message' => 'REFUSÉ PAR SECUREPAY',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID/Card-Check dans Securepay.',
        ],
        '014I' => [
            'message' => 'REFUSÉ PAR SECUREPAY',
            'description' => 'Paiement rejeté en raison des paramètres du DeviceID/IP-Check dans Securepay.',
        ],
        '020A' => [
            'message' => 'CONTOURNÉ',
            'description' => 'l\'authentification a été ignorée sur recommandation de Cardinal Commerce',
        ],
        '040A' => [
            'message' => 'Erreur système',
            'description' => 'La charge a été bloquée. La carte de crédit n\'a pas été débitée.',
        ],
        '040B' => [
            'message' => 'Erreur du système d\'autorisation interne',
            'description' => 'La charge a été bloquée. La carte de crédit n\'a pas été débitée.',
        ],
        '110A' => [
            'message' => 'Délai d\'attente généré par l\'utilisateur',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '110B' => [
            'message' => 'Fonction inconnue',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '110C' => [
            'message' => 'Carte non activée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '110d' => [
            'message' => 'Carte non acceptée',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '110E' => [
            'message' => 'Commando errant',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
        '139A' => [
            'message' => 'Taux d\'intérêt',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '139B' => [
            'message' => 'DebitPayType',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '139C' => [
            'message' => 'Montant du panier',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '139d' => [
            'message' => 'Erreur de calcul',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '139E' => [
            'message' => 'Tarif',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '139F' => [
            'message' => 'Mois',
            'description' => 'Le paramètre dans la colonne B a causé un problème.',
        ],
        '139G' => [
            'message' => 'Jeton expiré',
            'description' => 'La transaction a échoué, détails dans la colonne B.',
        ],
    ],
];
