<?php

namespace AxeptaPaygate\Payment;

use AxeptaPaygate\Payment\Traits\CardTrait;

class AmericanExpressPaymentMethod extends PaymentMethod
{
    use CardTrait;

    public static function build()
    {
        if (($operation = self::buildOrNull()) != null) {
            return $operation;
        }

        return parent::build();
    }
}
