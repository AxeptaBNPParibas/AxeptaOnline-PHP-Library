<?php

namespace AxeptaPaygate\Core;

use AxeptaPaygate\Api\OAuth2Api;
use AxeptaPaygate\Exception\CodeMessageException;
use AxeptaPaygate\Exception\PaymentMethodNotAvailableException;
use AxeptaPaygate\Utils;

class AxeptaPaygate
{
    private static $_configuration;

    public static function buildOperation()
    {
        $cfg = AxeptaPaygate::getConfiguration();

        $trigram = $cfg->get('trigram');
        $paymentMethod = Utils::getPaymentMethodFromTrigram($trigram);

        if (!$paymentMethod::isAvailableForCountry($cfg->get('iso2CountryCode')) && !$cfg->isDryRun()) {
            throw new PaymentMethodNotAvailableException('The desired payment method is not available for this country');
        }
        if (!$paymentMethod::isCurrencySupported($cfg['amount.currency']) && !$cfg->isDryRun()) {
            throw new PaymentMethodNotAvailableException('The desired payment method is not available for this currency');
        }

        return $paymentMethod::build();
    }

    public static function getPaymentDetails(string $accessToken, string $paymentId)
    {
        $url = OAuth2Api::getBaseurl() . '/payments/getByPayId/' . $paymentId;
        $request = OAuth2Api::buildJsonRequest($accessToken, $url);
        $response = $request->call();

        return json_decode($response, true);
    }

    public static function init(...$args)
    {
        self::$_configuration = new Configuration(...$args);
    }

    // convenience method
    public static function getAccessToken(...$args)
    {
        return OAuth2Api::getAccessToken(...$args);
    }

    public static function getConfiguration()
    {
        return self::$_configuration;
    }

    public static function getCodeMessage($code, $language = 'en'): array
    {
        if (strlen($code) != 8) {
            throw new CodeMessageException('Parameter `code` must be 8 characters long');
        }

        $filename = __DIR__ . '/Dictionnary/' . $language . '.php';
        if (!file_exists($filename)) {
            $filename = __DIR__ . '/Dictionnary/en.php';
        }

        // Load the dictionnary file for the given language
        $dictionnary = include_once $filename;

        $codeMessage = [
            'state' => $dictionnary['states'][substr($code, 0, 1)] ?? null,
            'module' => $dictionnary['modules'][substr($code, 1, 3)] ?? null,
            'parameter' => $dictionnary['parameters'][substr($code, 4, 7)] ?? null,
        ];

        if ($code == '00000000') {
            $codeMessage['parameter'] = ['message' => '', 'description' => ''];
        }

        if (in_array(null, array_values($codeMessage))) {
            throw new CodeMessageException('Parameter `code` is not valid');
        }

        return $codeMessage;
    }

    public static function getRequiredConfigurationKeys($trigram, $operationType, $paymentRenderingMode = null)
    {
        // To get the required configuration keys, we need to run the
        // buildOperation() method in dry run mode. This will populate an array
        // with all the missing configuration keys, which we can return to the
        // library user.

        $prefilledConfiguration = [
            'paymentRenderingMode' => $paymentRenderingMode,
            'trigram' => $trigram,
            'operationType' => $operationType,
        ];

        // Do not keep key/value pairs with null values
        Utils::removeNestedValues($prefilledConfiguration, null);

        $dryRun = true;
        self::init($prefilledConfiguration, $dryRun);
        self::buildOperation();
        $missingKeys = AxeptaPaygate::getConfiguration()->getMissingKeys();
        self::reset();

        return [$prefilledConfiguration, $missingKeys];
    }

    public static function reset()
    {
        self::$_configuration = null;
    }

    public static function getSupportedPayTypes()
    {
        return [
            'BANCONTACT',
            'CARD',
            // 'giropay',
            'IDEAL',
            // 'Sofort',
            // 'PSCPP', // Paysafecard via Pay Pro
        ];
    }
}
